
/**************************************************************************
 *
 *  $Id: mbgirigcfg.c 1.10 2009/09/29 15:02:15 martin REL_M $
 *
 *  Description:
 *    Main file for the mbgirigcfg program which can be used to configure
 *    the IRIG code frame and the UTC offset of the time contained in the
 *    IRIG code.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgirigcfg.c $
 *  Revision 1.10  2009/09/29 15:02:15  martin
 *  Updated version number to 3.4.0.
 *  Revision 1.9  2009/07/24 09:50:08  martin
 *  Updated version number to 3.3.0.
 *  Revision 1.8  2009/06/19 12:38:51  martin
 *  Updated version number to 3.2.0.
 *  Revision 1.7  2009/03/19 17:07:16  martin
 *  Updated version number to 3.1.0.
 *  Updated copyright year to include 2009.
 *  Include mbgtime.h for some symbolic constants.
 *  Revision 1.6  2008/12/22 12:42:58  martin
 *  Updated description, copyright, revision number and string.
 *  Use unified functions from toolutil module.
 *  Accept device name(s) on the command line.
 *  Don't use printf() without format, which migth produce warnings
 *  with newer gcc versions.
 *  Revision 1.5  2007/07/24 09:34:46  martin
 *  Changes due to renamed library symbols.
 *  Updated copyright to include 2007.
 *  Revision 1.4  2006/08/28 10:08:17  martin
 *  Display TFOM settings only it the selected IRIG code format supports TFOM.
 *  Revision 1.3  2006/07/03 13:27:31  martin
 *  Source code cleanup and fixed a typo.
 *  Revision 1.2  2004/11/08 15:59:10  martin
 *  Support separate config of IRIG RX and TX.
 *  Changes due to renamed symbols.
 *  Revision 1.1  2003/04/25 10:42:10  martin
 *
 **************************************************************************/

// include Meinberg headers
#include <mbgdevio.h>
#include <mbgtime.h>
#include <pcpsmktm.h>
#include <pcpsutil.h>
#include <pcpslstr.h>
#include <myutil.h>
#include <toolutil.h>

// include system headers
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


static const char *pname = "mbgirigcfg";
static const char *pversion = "v3.4.0";
static const char *pcopyright = "(c) Meinberg 2003-2009";

static const char *str_yes = "YES";
static const char *str_no = "NO";

static const char *info_curr = "Current";
static const char *info_new = "New";
static const char *msg_rx = DEFAULT_OPT_NAME_IRIG_RX_EN;
static const char *msg_tx = DEFAULT_OPT_NAME_IRIG_TX_EN;

static IRIG_INFO irig_rx_info;
static IRIG_INFO irig_tx_info;
static MBG_REF_OFFS ref_offs;
static MBG_OPT_INFO opt_info;

static int cfg_err;
static int changed_cfg_rx;
static int changed_cfg_tx;

static const char *icode_rx_names[N_ICODE_RX] = DEFAULT_ICODE_RX_NAMES;
static const char *icode_rx_descr[N_ICODE_RX] = DEFAULT_ICODE_RX_DESCRIPTIONS_ENG;

static const char *icode_tx_names[N_ICODE_TX] = DEFAULT_ICODE_TX_NAMES;
static const char *icode_tx_descr[N_ICODE_TX] = DEFAULT_ICODE_TX_DESCRIPTIONS_ENG;

static int max_ref_offs_h = MBG_REF_OFFS_MAX / MINS_PER_HOUR;


static /*HDR*/
int get_cfg( MBG_DEV_HANDLE dh, PCPS_DEV *pdev )
{
  int rc_rx = MBG_SUCCESS;
  int rc_tx = MBG_SUCCESS;

  if ( _pcps_is_irig_rx( pdev ) )
  {
    rc_rx = mbg_get_irig_rx_info( dh, &irig_rx_info );

    if ( rc_rx == MBG_SUCCESS && _pcps_has_ref_offs( pdev ) )
      rc_rx = mbg_get_ref_offs( dh, &ref_offs );

    if ( rc_rx == MBG_SUCCESS && _pcps_has_opt_flags( pdev ) )
      rc_rx = mbg_get_opt_info( dh, &opt_info );
  }

  if ( _pcps_has_irig_tx( pdev ) )
  {
    rc_tx = mbg_get_irig_tx_info( dh, &irig_tx_info );
  }


  if ( rc_rx != MBG_SUCCESS )
    printf( "** Error reading current IRIG RX configuration.\n" );

  if ( rc_tx != MBG_SUCCESS )
    printf( "** Error reading current IRIG TX configuration.\n" );

  if ( rc_rx != MBG_SUCCESS || rc_tx != MBG_SUCCESS )
    return -1;  //##++

  return MBG_SUCCESS;

}  // get_cfg



static /*HDR*/
int save_cfg( MBG_DEV_HANDLE dh, PCPS_DEV *pdev )
{
  int rc_rx = MBG_SUCCESS;
  int rc_tx = MBG_SUCCESS;

  if ( _pcps_is_irig_rx( pdev ) )
  {
    rc_rx = mbg_set_irig_rx_settings( dh, &irig_rx_info.settings );

    if ( rc_rx == MBG_SUCCESS && _pcps_has_ref_offs( pdev ) )
      rc_rx = mbg_set_ref_offs( dh, &ref_offs );

    if ( rc_rx == MBG_SUCCESS && _pcps_has_opt_flags( pdev ) )
      rc_rx = mbg_set_opt_settings( dh, &opt_info.settings );
  }

  if ( rc_rx == MBG_SUCCESS && _pcps_has_irig_tx( pdev ) )
  {
    rc_tx = mbg_set_irig_tx_settings( dh, &irig_tx_info.settings );
  }

  if ( rc_rx != MBG_SUCCESS )
    printf( "** Error writing IRIG RX configuration.\n" );

  if ( rc_tx != MBG_SUCCESS )
    printf( "** Error writing IRIG TX configuration.\n" );

  if ( rc_rx != MBG_SUCCESS || rc_tx != MBG_SUCCESS )
    return -1;

  return MBG_SUCCESS;

}  // save_cfg



static /*HDR*/
void print_cfg_rx( const char *info, const char *msg )
{
  int idx = irig_rx_info.settings.icode;
  int ref_offs_h = ref_offs / MINS_PER_HOUR;

  printf( "%s %s:\n", info, msg );

  printf( "  " DEFAULT_STR_IRIG_FMT_EN ":   %s, %s\n",
          icode_rx_names[idx],
          icode_rx_descr[idx]
        );


  printf( "  " DEFAULT_STR_IRIG_OFFS_EN ":   " );

  if ( abs( ref_offs_h ) > max_ref_offs_h )
    printf( "** not configured **\n" );
  else
    printf( "%+i h\n", ref_offs_h );

  if ( opt_info.supp_flags & MBG_OPT_FLAG_STR_UTC )
    printf( "  " DEFAULT_STR_IRIG_TIMESTR_UTC_EN ":   %s\n",
            ( opt_info.settings.flags & MBG_OPT_FLAG_STR_UTC ) ?
            str_yes : str_no );

}  // print_cfg_rx



static /*HDR*/
void print_cfg_tx( const char *info, const char *msg )
{
  int idx = irig_tx_info.settings.icode;

  printf( "%s %s:\n", info, msg );

  printf( "  " DEFAULT_STR_IRIG_FMT_EN ":   %s, %s\n",
          icode_tx_names[idx],
          icode_tx_descr[idx]
        );


  if ( _idx_bit( idx ) & MSK_ICODE_TX_HAS_TFOM )
  {
    printf( "  " DEFAULT_STR_TFOM_ALWAYS_SYNC_EN ":   %s\n",
      ( irig_tx_info.settings.flags & IFLAGS_DISABLE_TFOM ) ? str_yes : str_no );
  }

  printf( "  " DEFAULT_STR_IRIG_OUTPUT_LOC_TM_EN ":   %s\n",
    ( irig_tx_info.settings.flags & IFLAGS_TX_GEN_LOCAL_TIME ) ?
    str_yes : str_no
  );

}  // print_cfg_tx



static /*HDR*/
void err_msg( PCPS_DEV *pdev, const char *msg )
{
  printf( "The clock device %s %s.\n", _pcps_type_name( pdev ), msg );

}  // err_msg



static /*HDR*/
void set_new_icode_rx( char *s )
{
  int idx = atoi( s );

  if ( idx >= N_ICODE_RX )
  {
    printf( "** IRIG RX code index %i is out of range (0..%i).\n",
            idx, N_ICODE_RX - 1 );
    cfg_err = 1;
    return;
  }

  if ( _is_supported( idx, irig_rx_info.supp_codes ) )
  {
    irig_rx_info.settings.icode = idx;
    changed_cfg_rx = 1;
  }
  else
  {
    printf( "** IRIG RX code \"%s\" not supported by this device.\n",
            icode_rx_names[idx] );
    cfg_err = 1;
  }

}  // set_new_icode_rx



static /*HDR*/
void set_new_ref_offs( char *s )
{
  int new_ref_offs_h;

  new_ref_offs_h = atoi( s );

  if ( abs( new_ref_offs_h ) > max_ref_offs_h )
  {
    printf( "** New IRIG time offset %ih exceeds range (%+ih..%+ih).\n",
            new_ref_offs_h, -max_ref_offs_h, max_ref_offs_h );
    cfg_err = 1;
  }
  else
  {
    ref_offs = new_ref_offs_h * MINS_PER_HOUR;
    changed_cfg_rx = 1;
  }

}  // set_new_ref_offs



static /*HDR*/
void set_new_str_utc( char *s )
{
  int this_cfg_err;

  if ( !( opt_info.supp_flags & MBG_OPT_FLAG_STR_UTC ) )
    return;  // not supported


  this_cfg_err = 0;

  if ( strcmp( s, "1" ) == 0 )
    opt_info.settings.flags |= MBG_OPT_FLAG_STR_UTC;
  else
    if ( strcmp( s, "0" ) == 0 )
      opt_info.settings.flags &= ~MBG_OPT_FLAG_STR_UTC;
    else
      this_cfg_err = 1;

  if ( this_cfg_err )
    cfg_err = 1;
  else
    changed_cfg_rx = 1;

}  // set_new_str_utc



static /*HDR*/
void set_new_icode_tx( char *s )
{
  int idx = atoi( s );

  if ( idx >= N_ICODE_TX )
  {
    printf( "** IRIG TX code index %i is out of range (0..%i).\n",
            idx, N_ICODE_TX - 1 );
    cfg_err = 1;
    return;
  }

  if ( _is_supported( idx, irig_tx_info.supp_codes ) )
  {
    irig_tx_info.settings.icode = idx;
    changed_cfg_tx = 1;
  }
  else
  {
    printf( "** IRIG TX code \"%s\" not supported by this device.\n",
            icode_tx_names[idx] );
    cfg_err = 1;
  }

}  // set_new_icode_tx



static /*HDR*/
void set_new_irig_tx_local( char *s )
{
  int this_cfg_err = 0;

  if ( strcmp( s, "1" ) == 0 )
    irig_tx_info.settings.flags |= IFLAGS_TX_GEN_LOCAL_TIME;
  else
    if ( strcmp( s, "0" ) == 0 )
      irig_tx_info.settings.flags &= ~IFLAGS_TX_GEN_LOCAL_TIME;
    else
      this_cfg_err = 1;

  if ( this_cfg_err )
    cfg_err = 1;
  else
    changed_cfg_tx = 1;

}  // set_new_irig_tx_local



static /*HDR*/
void set_new_tfom_sync( char *s )
{
  int this_cfg_err;

  if ( !(_idx_bit( irig_tx_info.settings.icode ) & MSK_ICODE_TX_HAS_TFOM ) )
    return;  // not supported


  this_cfg_err = 0;

  if ( strcmp( s, "1" ) == 0 )
    irig_tx_info.settings.flags |= IFLAGS_DISABLE_TFOM;
  else
    if ( strcmp( s, "0" ) == 0 )
      irig_tx_info.settings.flags &= ~IFLAGS_DISABLE_TFOM;
    else
      this_cfg_err = 1;

  if ( this_cfg_err )
    cfg_err = 1;
  else
    changed_cfg_tx = 1;

}  // set_new_tfom_sync



static /*HDR*/
int chk_dev_rx( const PCPS_DEV *pdev )
{
  if ( !_pcps_is_irig_rx( pdev ) )
  {
    printf( "** This device is no IRIG receiver.\n" );
    cfg_err = 1;
    return 0;
  }

  return 1;

}  // chk_dev_rx



static /*HDR*/
int chk_dev_tx( const PCPS_DEV *pdev )
{
  if ( !_pcps_has_irig_tx( pdev ) )
  {
    printf( "** This device has no IRIG transmitter.\n" );
    cfg_err = 1;
    return 0;
  }

  return 1;

}  // chk_dev_tx



static /*HDR*/
void check_cmd_line( int argc, char *argv[], const PCPS_DEV *pdev )
{
  int i;

  for ( i = 1; i < argc; i++ )
  {
    if ( strcmp( argv[i], "-h" ) == 0 )
    {
      must_print_usage = 1;
      continue;
    }

    if ( strcmp( argv[i], "--help" ) == 0 )
    {
      must_print_usage = 1;
      continue;
    }

    if ( strcmp( argv[i], "-r" ) == 0 )  // IRIG RX code frame
    {
      if ( ++i < argc )
        if ( chk_dev_rx( pdev ) )
          set_new_icode_rx( argv[i] );

      continue;
    }

    if ( strcmp( argv[i], "-o" ) == 0 )  // IRIG time offset from UTC
    {
      if ( ++i < argc )
        if ( chk_dev_rx( pdev ) )
          set_new_ref_offs( argv[i] );

      continue;
    }

    if ( strcmp( argv[i], "-u" ) == 0 )  // Option flag: serial output always UTC
    {
      if ( ++i < argc )
        if ( chk_dev_rx( pdev ) )
          set_new_str_utc( argv[i] );

      continue;
    }

    if ( strcmp( argv[i], "-t" ) == 0 )  // IRIG TX code frame
    {
      if ( ++i < argc )
        if ( chk_dev_tx( pdev ) )
          set_new_icode_tx( argv[i] );

      continue;
    }

    if ( strcmp( argv[i], "-l" ) == 0 )  // Option flag: transmit local time, not UTC
    {
      if ( ++i < argc )
        if ( chk_dev_tx( pdev ) )
          set_new_irig_tx_local( argv[i] );

      continue;
    }

    if ( strcmp( argv[i], "-s" ) == 0 )  // Option flag: send TFOM as always "sync"
    {
      if ( ++i < argc )
        if ( chk_dev_tx( pdev ) )
          set_new_tfom_sync( argv[i] );

      continue;
    }

  }

}  // check_cmd_line



static /*HDR*/
void usage( void )
{
  const char *frame_fmt = "           %4i  %s, %s\n";
  int i;

  printf(
    "Usage:  %s [-h]|[option] [option] ...\n"
    "\n",
    pname
  );

  printf(
    "  -h or --help  prints this info\n"
    "\n"
  );


  printf(
    "Options supported by IRIG receivers:\n"
    "\n"
  );

  printf(
    "  -r code   specifies the IRIG receiver code format, where \"code\" \n"
    "            can be one a number according to the table below:\n"
  );

  for ( i = 0; i < N_ICODE_RX; i++ )
    printf( frame_fmt, i, icode_rx_names[i], icode_rx_descr[i] );

  printf( "\n" );

  printf(
    "  -o offs   specifies the IRIG input time offset from UTC, in hours,\n"
    "            where \"offs\" can be a value in the range %+i..%+i\n"
    "\n",
    -max_ref_offs_h, max_ref_offs_h
  );

  printf(
    "  -u flag   determines whether the time string sent via the\n"
    "            board's serial output contains always UTC time\n"
    "            or the same time as received from the IRIG input\n"
    "            signal. \"flag\" can be \"1\" for always UTC,\n"
    "            or \"0\" for IRIG time.\n"
    "\n"
  );


  printf(
    "Options supported by IRIG transmitters:\n"
    "\n"
  );

  printf(
    "  -t code   specifies the IRIG transmitter code format, where \"code\" \n"
    "            can be one a number according to the table below:\n"
  );

  for ( i = 0; i < N_ICODE_TX; i++ )
    printf( frame_fmt, i, icode_tx_names[i], icode_tx_descr[i] );

  printf( "\n" );

  printf(
    "  -l flag   determines whether IRIG output shall contain local\n"
    "            time, or UTC. \"flag\" must be \"1\" for local time,\n"
    "            or \"0\" for UTC.\n"
    "\n"
  );

  printf(
    "  -s flag   If \"flag\" is set to \"1\" then the TFOM qualifier in the\n"
    "            IRIG output is always set to \"synchronized\". If it is \"0\" \n"
    "            then the qualifier reflects the current status of the input signal.\n"
    "            Please note that most IRIG codes do not support a TFOM qualifier.\n"
    "\n"
  );


  printf(
    "If no parameters are given the program reports the current settings.\n"
    "Please note that not all IRIG codes must be supported by all devices.\n"
  );

}  // usage



static /*HDR*/
void help_info( void )
{
  printf( "\nFor help type \"%s -h\"\n", pname );

}  // help_info



int main( int argc, char *argv[] )
{
  const char *no_irig = "is not an IRIG code receiver";
  MBG_DEV_HANDLE dh;
  char *dev_name = NULL;
  PCPS_DEV dev = { { 0 } };
  int exit_code = 0;
  int rc;
  int i;

  mbg_print_program_info( pname, pversion, pcopyright );

  for ( i = 1; i < argc; i++ )
  {
    if ( argv[i][0] == '-' )
    {
      i++;  // skip next argument
      continue;
    }

    dev_name = argv[i];
    break;
  }

  if ( dev_name )
    dh = open( dev_name, 0 );
  else
    dh = mbg_open_device( 0 );

  if ( dh == MBG_INVALID_DEV_HANDLE )
  {
    rc = -1;  // don't report error now, maybe later
  }
  else
  {
    // get information about the device
    rc = mbg_get_device_info( dh, &dev );

    // if success, read the current IRIC configuration
    if ( rc == MBG_SUCCESS )
      rc = get_cfg( dh, &dev );
  }


  check_cmd_line( argc, argv, &dev );

  if ( must_print_usage )
  {
    usage();
    exit_code = 1;
    goto done;
  }

  if ( cfg_err )
  {
    help_info();
    exit_code = 1;
    goto done;
  }


  // At this point we shall either report or modify the current
  // configuration. If there has been an error accessing the
  // device, or the device is not an IRIG receiver, then we must
  // print a message.

  if ( dh == MBG_INVALID_DEV_HANDLE )
  {
    printf( "** Error opening the device.\n" );
    exit_code = 3;
    goto done;
  }

  if ( rc != MBG_SUCCESS )
  {
    exit_code = 3;
    goto done;
  }

  if ( !_pcps_has_irig( &dev ) )
  {
    err_msg( &dev, no_irig );
    exit_code = 2;
    goto done;
  }


  if ( changed_cfg_rx || changed_cfg_tx )
  {

    if ( changed_cfg_rx )
      print_cfg_rx( info_new, msg_rx );

    if ( changed_cfg_tx )
      print_cfg_tx( info_new, msg_tx );

    rc = save_cfg( dh, &dev );

    if ( mbg_ioctl_err( rc, "save IRIG configuration" ) )
      exit_code = 3;
  }
  else
  {
    if ( _pcps_is_irig_rx( &dev ) )
      print_cfg_rx( info_curr, msg_rx );

    if ( _pcps_has_irig_tx( &dev ) )
      print_cfg_tx( info_curr, msg_tx );

    help_info();
  }

done:
  printf( "\n" );

  if ( dh != MBG_INVALID_DEV_HANDLE )
    mbg_close_device( &dh );

  return exit_code;
}
