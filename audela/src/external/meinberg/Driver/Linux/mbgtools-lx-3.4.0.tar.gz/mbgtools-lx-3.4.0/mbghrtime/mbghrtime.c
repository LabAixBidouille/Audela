
/**************************************************************************
 *
 *  $Id: mbghrtime.c 1.10 2009/09/29 15:02:15 martin REL_M $
 *
 *  Description:
 *    Main file for mbghrtime program which demonstrates how to access
 *    a Meinberg device via IOCTL calls to read high resolution
 *    time stamps, if supported by the device.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbghrtime.c $
 *  Revision 1.10  2009/09/29 15:02:15  martin
 *  Updated version number to 3.4.0.
 *  Revision 1.9  2009/07/24 09:50:08  martin
 *  Updated version number to 3.3.0.
 *  Revision 1.8  2009/06/19 14:03:53  martin
 *  Use common mbg_print_hr_timestamp() for unified output format.
 *  Updated version number to 3.2.0.
 *  Revision 1.7  2009/03/20 11:45:16  martin
 *  Updated version number to 3.1.0.
 *  Updated copyright year to include 2009.
 *  Call mbg_get_hr_time_comp() instead of mbg_get_hr_time_cycles().
 *  Revision 1.6  2008/12/22 12:02:00  martin
 *  Updated description, copyright, revision number and string.
 *  Use unified functions from toolutil module.
 *  Accept device name(s) on the command line.
 *  Revision 1.5  2007/07/24 09:32:41  martin
 *  Updated copyright to include 2007.
 *  Revision 1.4  2004/11/08 15:45:22  martin
 *  Modifications to support 64 bit systems in a clean way.
 *  Revision 1.3  2003/04/25 10:28:05  martin
 *  Use new functions from mbgdevio library.
 *  New program version v2.1.
 *  Revision 1.2  2001/11/30 10:01:49  martin
 *  Account for the modified definition of PCPS_HR_TIME which
 *  uses the new structure PCPS_TIME_STAMP now.
 *  Revision 1.1  2001/09/17 15:08:31  martin
 *
 **************************************************************************/

// include Meinberg headers
#include <mbgdevio.h>
#include <pcpsutil.h>
#include <toolutil.h>  // common utility functions

// include system headers
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>  // gettimeofday()



static const char *pname = "mbghrtime";
static const char *pversion = "v3.4.0";
static const char *pcopyright = "(c) Meinberg 2001-2009";

static int loops;



static /*HDR*/
int do_mbghrtime( MBG_DEV_HANDLE dh, const PCPS_DEV *p_dev )
{
  PCPS_HR_TIME_CYCLES hrtc = { 0 };
  PCPS_HR_TIME_CYCLES prv_hrtc = { 0 };
  PCPS_TIME_STAMP *p = NULL;
  int32_t hns_latency = 0;
  int this_loops = loops;

  if ( !_pcps_has_hr_time( p_dev ) )
  {
    printf( "High resolution time not supported by this device.\n" );
    return 0;
  }

  for (;;)
  {
    int rc = mbg_get_hr_time_comp( dh, &hrtc.t, &hns_latency );

    if ( mbg_ioctl_err( rc, "mbg_get_hr_time_comp" ) )
      break;

    mbg_print_hr_timestamp( &hrtc.t.tstamp, hns_latency, p, 0 );

    prv_hrtc = hrtc;
    p = &prv_hrtc.t.tstamp;

    if ( this_loops > 0 )
      this_loops--;

    if ( this_loops == 0 )
      break;

    // if this_loops is < 0 then loop forever
  }

  return 0;

}  // do_mbghrtime



static /*HDR*/
void usage( void )
{
  mbg_print_usage_intro( pname,
    "This example program reads high resolution time stamps (HR time)\n"
    "from a device.\n"
    "This works only for devices which support high resolution time (HR time)."
  );
  mbg_print_help_options();
  mbg_print_opt_info( "-c", "run continuously" );
  mbg_print_opt_info( "-n num", "run num loops" );
  mbg_print_device_options();
  puts( "" );

}  // usage



int main( int argc, char *argv[] )
{
  int rc;
  int c;

  mbg_print_program_info( pname, pversion, pcopyright );

  // check command line parameters
  while ( ( c = getopt( argc, argv, "cn:h?" ) ) != -1 )
  {
    switch ( c )
    {
      case 'c':
        loops = -1;
        break;

      case 'n':
        loops = atoi( optarg );
        break;

      case 'h':
      case '?':
      default:
        must_print_usage = 1;
    }
  }

  if ( must_print_usage )
  {
    usage();
    return 1;
  }

  // The function below checks which devices have been specified
  // on the command, and for each device
  // - tries to open the device
  // - shows basic device info
  // - calls the function passed as last parameter
  rc = mbg_check_devices( argc, argv, optind, do_mbghrtime );

  return abs( rc );
}
