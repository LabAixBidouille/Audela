
/**************************************************************************
 *
 *  $Id: mbggpscap.c 1.10 2009/09/29 15:02:15 martin REL_M $
 *
 *  Description:
 *    Main file for mbggpscap program which demonstrates how to access
 *    a Meinberg device via IOCTL calls and read entries from the time
 *    capture FIFO buffer.
 *
 *    Please note that this may only work with devices which provide
 *    time capture input(s).
 *
 * -----------------------------------------------------------------------
 *  $Log: mbggpscap.c $
 *  Revision 1.10  2009/09/29 15:02:15  martin
 *  Updated version number to 3.4.0.
 *  Revision 1.9  2009/07/24 09:50:08  martin
 *  Updated version number to 3.3.0.
 *  Revision 1.8  2009/06/19 12:38:51  martin
 *  Updated version number to 3.2.0.
 *  Revision 1.7  2009/03/19 17:04:26  martin
 *  Updated version number to 3.1.0.
 *  Updated copyright year to include 2009.
 *  Revision 1.6  2008/12/22 12:00:55  martin
 *  Updated description, copyright, revision number and string.
 *  Use unified functions from toolutil module.
 *  Accept device name(s) on the command line.
 *  Don't use printf() without format, which migth produce warnings
 *  with newer gcc versions.
 *  Revision 1.5  2007/07/24 09:32:26  martin
 *  Updated copyright to include 2007.
 *  Revision 1.4  2006/02/22 15:29:17  martin
 *  Support new ucap API.
 *  Print an error message if device can't be opened.
 *  Revision 1.3  2004/11/08 15:47:10  martin
 *  Using type cast to avoid compiler warning.
 *  Revision 1.2  2003/04/25 10:28:05  martin
 *  Use new functions from mbgdevio library.
 *  New program version v2.1.
 *  Revision 1.1  2001/09/17 15:08:22  martin
 *
 **************************************************************************/

// include Meinberg headers
#include <mbgdevio.h>
#include <pcpsutil.h>
#include <toolutil.h>  // common utility functions

// include system headers
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>


static const char *pname = "mbggpscap";
static const char *pversion = "v3.4.0";
static const char *pcopyright = "(c) Meinberg 2001-2009";


static int continuous;


static /*HDR*/
void show_ucap_status( ulong status )
{
  // status bit definitions can be found in pcpsdefs.h.

  if ( status & PCPS_UCAP_OVERRUN )     // capture events have occurred too fast
    printf( " << CAP OVR" );

  if ( status & PCPS_UCAP_BUFFER_FULL ) // capture buffer has been full, events lost
    printf( " << BUF OVR" );

}  // show_ucap_status



static /*HDR*/
void show_ucap_event( const PCPS_HR_TIME *ucap )
{
  char ws[80];

  // Print converted date and time to a string:
  mbg_snprint_hr_time( ws, sizeof( ws ), ucap );

  // Print the time stamp, ucap->signal contains the channel number:
  printf( "New capture: CH%i: %s", ucap->signal, ws );

  show_ucap_status( ucap->status );

  printf( "\n" );

}  // show_ucap_event



// The function below is normally outdated, and show_ucap_event()
// above should be used if possible, together with the associated
// API calls.

static /*HDR*/
void show_gps_ucap( const TTM *ucap )
{
  printf( "New capture: CH%i: %04i-%02i-%02i  %2i:%02i:%02i.%07li",
          ucap->channel,
          ucap->tm.year,
          ucap->tm.month,
          ucap->tm.mday,
          ucap->tm.hour,
          ucap->tm.min,
          ucap->tm.sec,
          (ulong) ucap->tm.frac
        );

  show_ucap_status( ucap->tm.status );

  printf( "\n" );

}  // show_gps_ucap



static /*HDR*/
void check_serial_mode( MBG_DEV_HANDLE dh )
{
  PORT_PARM port_parm;
  int i;
  int must_modify = 0;

  // read the clock's current port settings
  int rc = mbg_get_gps_port_parm( dh, &port_parm );

  if ( mbg_ioctl_err( rc, "mbg_get_gps_port_parm" ) )
    return;


  // If one of the ports has been set to send user captures
  // then the user capture buffer will most often be empty
  // if we check for captures, so modify the port mode.
  for ( i = 0; i < N_COM; i++ )
  {
    if ( port_parm.mode[i] == STR_UCAP )
    {
      port_parm.mode[i] = STR_UCAP_REQ;
      must_modify = 1;
    }
  }

  if ( !must_modify )
    return;


  rc = mbg_set_gps_port_parm( dh, &port_parm );

  if ( mbg_ioctl_err( rc, "mbg_set_gps_port_parm" ) )
    return;

  printf( "NOTE: the clock's serial port mode has been changed.\n" );

}  // check_serial_mode



static /*HDR*/
int do_mbggpscap( MBG_DEV_HANDLE dh, const PCPS_DEV *p_dev )
{
  int rc;

  if ( !_pcps_has_ucap( p_dev ) && !_pcps_is_gps( p_dev ) )
  {
    printf( "This device type does not provide time capture inputs.\n" );
    return 0;
  }

  check_serial_mode( dh );

  printf( "Be sure the card has been properly configured to enable capture inputs.\n" );

  // There's an older API which has been introduced with the first GPS boards
  // and uses the TTM structure to return the capture events. However, that
  // API call is slow and not very flexible, so a new set of API calls has been
  // introduced to handle capture events.
  // The new API calls are supported by all supported by all newer boards which
  // provide user capture inputs, and also for older boards with a firmware update.

  if ( _pcps_has_ucap( p_dev ) )  // check if the new API is supported
  {
    // The new API provides the following functions:
    //   mbg_clr_ucap_buff()     clear the on-board FIFO buffer
    //   mbg_get_ucap_entries()  get the max number of FIFO entries, and the current number of entries
    //   mbg_get_ucap_event()    read one entry from the FIFO

    PCPS_UCAP_ENTRIES ucap_entries;

    // retrieve and print information of the maximum number of events that can
    // be stored in the on-board FIFO, and the number of events that are currently
    // stored
    rc = mbg_get_ucap_entries( dh, &ucap_entries );

    if ( rc == MBG_SUCCESS )
    {
      // Cards report they could save one more capture event
      // than they actually do save, so adjust the reported value
      // for a proper display.
      if ( ucap_entries.max )
        ucap_entries.max--;

      printf( "\nOn-board FIFO: %u of %u entries used\n\n",
              ucap_entries.used, ucap_entries.max );
    }

    printf( ( ucap_entries.used == 0 ) ?
            "Waiting for capture events:\n" :
            "Reading capture events:\n"
          );

    // Now read out all events from the FIFO and wait
    // for new events if the FIFO is empty.
    for (;;)
    {
      PCPS_HR_TIME ucap_event;

      rc = mbg_get_ucap_event( dh, &ucap_event );

      if ( mbg_ioctl_err( rc, "mbg_get_ucap_event" ) )
        break;  // an error has occurred

      // if a user capture event has been read
      // it it removed from the clock's buffer

      // if no new capture event is available, the seconds field
      // of the time stamp is set to 0
      if ( ucap_event.tstamp.sec == 0 )
      {
        if ( !continuous )
          break;

        sleep( 1 );   // sleep, then try again
      }

      show_ucap_event( &ucap_event );
    }
  }
  else    // use the old API
  {
    printf( "Waiting for capture events:\n" );

    for (;;)
    {
      TTM ucap_ttm;

      rc = mbg_get_gps_ucap( dh, &ucap_ttm );

      if ( mbg_ioctl_err( rc, "mbg_get_gps_ucap" ) )
        break;  // an error has occurred


      // if a user capture event has been read
      // it it removed from the clock's buffer

      // if no new capture event is available, the ucap.tm structure
      // is set to "unread".
      if ( !_pcps_time_is_read( &ucap_ttm.tm ) )
      {
        if ( !continuous )
          break;

        sleep( 1 );   // sleep, then try again
      }

      show_gps_ucap( &ucap_ttm );
    }
  }

  return 0;

}  // do_mbggpscap



static /*HDR*/
void usage( void )
{
  mbg_print_usage_intro( pname,
    "This example program reads time capture events from a card.\n"
    "This works only with cards which provide time capture inputs."
  );
  mbg_print_help_options();
  mbg_print_opt_info( "-c", "run continuously" );
  mbg_print_opt_info( "-p", "use polling mode (select/non-blocking read)" );
  mbg_print_device_options();
  puts( "" );

}  // usage



int main( int argc, char *argv[] )
{
  int rc;
  int c;

  mbg_print_program_info( pname, pversion, pcopyright );

  // check command line parameters
  while ( ( c = getopt( argc, argv, "ch?" ) ) != -1 )
  {
    switch ( c )
    {
      case 'c':
        continuous = 1;
        break;

      case 'h':
      case '?':
      default:
        must_print_usage = 1;
    }
  }

  if ( must_print_usage )
  {
    usage();
    return 1;
  }

  // The function below checks which devices have been specified
  // on the command, and for each device
  // - tries to open the device
  // - shows basic device info
  // - calls the function passed as last parameter
  rc = mbg_check_devices( argc, argv, optind, do_mbggpscap );

  return abs( rc );
}
