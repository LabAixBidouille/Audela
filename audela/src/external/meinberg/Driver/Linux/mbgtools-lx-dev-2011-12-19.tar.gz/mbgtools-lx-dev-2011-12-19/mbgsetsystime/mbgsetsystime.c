
/**************************************************************************
 *
 *  $Id: mbgsetsystime.c 1.8.1.2 2011/07/05 15:35:55 martin TEST $
 *
 *  Description:
 *    Main file for mbgsetsystime program which reads the current date
 *    and time from a Meinberg device and sets the system time accordingly.
 *    The program returns 0 if successfull, otherwise a value greater
 *    than 0.
 *
 *  Be careful if using this program while (x)ntpd is running because
 *  (x)ntpd does not like time steps and may react unexpectedly.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgsetsystime.c $
 *  Revision 1.8.1.2  2011/07/05 15:35:55  martin
 *  Modified version handling.
 *  Revision 1.8.1.1  2011/07/05 14:36:01  martin
 *  New way to maintain version information.
 *  Revision 1.8  2009/09/29 15:02:15  martin
 *  Updated version number to 3.4.0.
 *  Revision 1.7  2009/07/24 09:50:09  martin
 *  Updated version number to 3.3.0.
 *  Revision 1.6  2009/06/19 12:38:52  martin
 *  Updated version number to 3.2.0.
 *  Revision 1.5  2009/03/19 17:04:26  martin
 *  Updated version number to 3.1.0.
 *  Updated copyright year to include 2009.
 *  Revision 1.4  2008/12/22 12:43:31  martin
 *  Updated description, copyright, revision number and string.
 *  Use unified functions from toolutil module.
 *  Accept device name(s) on the command line.
 *  Don't use printf() without format, which migth produce warnings
 *  with newer gcc versions.
 *  Revision 1.3  2007/07/24 09:33:01  martin
 *  Updated copyright to include 2007.
 *  Revision 1.2  2003/04/25 10:28:05  martin
 *  Use new functions from mbgdevio library.
 *  New program version v2.1.
 *  Revision 1.1  2001/09/17 15:08:46  martin
 *
 **************************************************************************/

// include Meinberg headers
#include <mbgdevio.h>
#include <pcpsmktm.h>
#include <toolutil.h>

// include system headers
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/time.h>
#include <sys/types.h>


#define MBG_MICRO_VERSION          0
#define MBG_FIRST_COPYRIGHT_YEAR   2001
#define MBG_LAST_COPYRIGHT_YEAR    0     // use default

static const char *pname = "mbgsetsystime";



static /*HDR*/
void set_system_time( PCPS_TIME *tp )
{
  struct timeval tv_set;


  tv_set.tv_sec = pcps_mktime( tp );
  tv_set.tv_usec = (ulong) tp->sec100 * 10000;
  settimeofday( &tv_set, NULL );

  printf( "Date/time set to  %02u.%02u.%02u %02u:%02u:%02u.%02u (UTC %+02ih)\n",
          tp->mday, tp->month, tp->year,
          tp->hour, tp->min, tp->sec, tp->sec100,
          tp->offs_utc
        );

}  // set_system_time



static /*HDR*/
int do_mbgsetsystime( MBG_DEV_HANDLE dh, const PCPS_DEV *p_dev )
{
  static int system_time_has_been_set;

  PCPS_TIME t;
  int ret_val = 0;
  int rc;

  if ( system_time_has_been_set )
    goto done;

  rc = mbg_get_time( dh, &t );

  if ( mbg_ioctl_err( rc, "mbg_get_time" ) )
  {
    ret_val = -2;
    goto done;
  }

  if ( t.status & PCPS_INVT )
  {
    // This may happen if the radio clock's battery
    // was low or disconnected.
    printf( "Radio clock has no valid date/time.\n" );
    ret_val = -1;
    goto done;
  }

  set_system_time( &t );
  system_time_has_been_set = 1;

  puts( "" );

done:
  mbg_close_device( &dh );

  return 0;

}  // do_mbgsetsystime



static /*HDR*/
void usage( void )
{
  mbg_print_usage_intro( pname,
    "This program can be used to set the system time to the card's time.\n"
    "This should be done only at boot time, before the NTP daemon is started."
  );
  mbg_print_help_options();
  mbg_print_device_options();
  puts( "" );

}  // usage



int main( int argc, char *argv[] )
{
  int c;
  int rc;

  mbg_print_program_info( pname, MBG_MICRO_VERSION, MBG_FIRST_COPYRIGHT_YEAR, MBG_LAST_COPYRIGHT_YEAR );

  // check command line parameters
  while ( ( c = getopt( argc, argv, "h?" ) ) != -1 )
  {
    switch ( c )
    {
      case 'h':
      case '?':
      default:
        must_print_usage = 1;
    }
  }

  if ( must_print_usage )
  {
    usage();
    return 1;
  }

  // The function below checks which devices have been specified
  // on the command, and for each device
  // - tries to open the device
  // - shows basic device info
  // - calls the function passed as last parameter
  rc = mbg_check_devices( argc, argv, optind, do_mbgsetsystime );

  return abs( rc );
}
