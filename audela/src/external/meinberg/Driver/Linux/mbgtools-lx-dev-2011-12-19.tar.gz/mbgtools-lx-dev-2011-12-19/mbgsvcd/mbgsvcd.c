
/**************************************************************************
 *
 *  $Id: mbgsvcd.c 1.3.1.14 2011/11/17 10:07:08 martin TEST daniel $
 *
 *  Description:
 *    Main file for mbgsvcd which compares the system time to a PCI card's 
 *    time and transfers this data pair to the SHM driver of the ntpd.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgsvcd.c $
 *  Revision 1.3.1.14  2011/11/17 10:07:08  martin
 *  Added leap second support.
 *  Revision 1.3.1.13  2011/10/06 13:03:46  martin
 *  Combined printf() and syslog() to mbg_log().
 *  Cleanup.
 *  Revision 1.3.1.12  2011/10/05 15:11:50  martin
 *  Log reasons for error if function calls fail.
 *  Revision 1.3.1.11  2011/09/07 15:08:56  martin
 *  Account for modified library functions which can now
 *  optionally print the raw (hex) HR time stamp.
 *  Revision 1.3.1.10  2011/07/14 13:30:57  martin
 *  Code cleanup.
 *  Eliminated some potential warnings due to ignored function return values.
 *  Revision 1.3.1.9  2011/07/05 15:35:55  martin
 *  Modified version handling.
 *  Revision 1.3.1.8  2011/07/05 14:35:19  martin
 *  New way to maintain version information.
 *  Revision 1.3.1.7  2011/06/23 15:35:40  martin
 *  Skip devices which don't support HR time immediately at startup.
 *  Revision 1.3.1.6  2011/06/23 15:02:55  martin
 *  Compute execution time limit in cycles instead of us so this can also
 *  be done if the cycle counter clock rate can not be determined.
 *  Revision 1.3.1.5  2011/06/23 12:45:37  martin
 *  Workaround in case cycle frequency can not be determined.
 *  Revision 1.3.1.4  2011/06/20 15:10:22  martin
 *  Using generic MBG_SYS_TIME with nanosecond resolution.
 *  Revision 1.3.1.3  2011/03/25 11:05:24  martin
 *  Optionally support timespec for sys time.
 *  Cleanup.
 *  Revision 1.3.1.2  2011/03/23 16:30:40  martin
 *  Use /var/run as directory for the lockfile.
 *  Revision 1.3.1.1  2010/04/26 14:37:41  martin
 *  Print PC cycles counter frequency at program start.
 *  Revision 1.3  2010/03/03 14:59:36  martin
 *  Support -p parameter to pretend sync.
 *  Revision 1.2  2010/02/03 16:15:09  daniel
 *  Revision 1.1  2010/02/03 16:07:18  daniel
 *
 **************************************************************************/

// include Meinberg headers
#include <mbgdevio.h>
#include <pcpsutil.h>
#include <toolutil.h>  // common utility functions
#include <pcpsmktm.h>

// include system headers
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h> 
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <syslog.h>
#include <stdarg.h>


#include <sys/ipc.h>
#include <sys/shm.h>

#define RUNNING_DIR                "/var/run"
#define LOCK_FILE                  "mbgsvcd.pid"

#define MBG_MICRO_VERSION          0
#define MBG_FIRST_COPYRIGHT_YEAR   2010
#define MBG_LAST_COPYRIGHT_YEAR    0      // use default

static const char *pname = "mbgsvcd";

static int sleep_intv = 1;
static int pretend_sync;


/**
 * @defgroup group_ntp_defs NTP interface definitions
 *
 * @Note These definitions have been copied from the NTP source code (http://www.ntp.org)
 *
 * @{ */

/** @brief Structure of NTP's shared memory segment */
struct shmTime {
  int    mode; /* 0 - if valid set
                *       use values,
                *       clear valid
                * 1 - if valid set
                *       if count before and after read of
                *       values is equal,
                *         use values
                *       clear valid
                */
  int    count;
  time_t clockTimeStampSec;      /* external clock */
  int    clockTimeStampUSec;     /* external clock */
  time_t receiveTimeStampSec;    /* internal clock, when external value was received */
  int    receiveTimeStampUSec;   /* internal clock, when external value was received */
  int    leap;
  int    precision;
  int    nsamples;
  int    valid;
  int    dummy[10];
};

/** @brief codes used with struct shmTime::leap */
#define LEAP_NOWARNING  0x0 /**< normal, no leap second warning */
#define LEAP_ADDSECOND  0x1 /**< last minute of day has 61 seconds */
#define LEAP_DELSECOND  0x2 /**< last minute of day has 59 seconds */
#define LEAP_NOTINSYNC  0x3 /**< overload, clock is free running */

#define NTPD_BASE                  0x4e545030    /* "NTP0" */

#define MAX_SHM_REFCLOCKS          4

/** @} group_ntp_defs */

static struct shmTime *shmTime[MAX_SHM_REFCLOCKS];



#define MAX_FILTER_ENTRIES    32

typedef struct
{
  MBG_PC_CYCLES cyc[MAX_FILTER_ENTRIES];
  MBG_PC_CYCLES sum;
  int entries;
  int index;
} FILTER;

static FILTER filter;



static /*HDR*/
void mbg_log( int lvl, const char *fmt, ... )
{
  char ws[256];
  va_list ap;

  va_start( ap, fmt );
  vsnprintf( ws, sizeof( ws ), fmt, ap );
  va_end( ap );

  syslog( lvl, ws );
  fprintf( stdout, "%s\n", ws );

}  // mbg_log



static /*HDR*/
MBG_PC_CYCLES do_filter( FILTER *p, MBG_PC_CYCLES cyc )
{
  if ( p->entries < MAX_FILTER_ENTRIES )
    p->entries++;

  if ( ++( p->index ) >= MAX_FILTER_ENTRIES )
    p->index = 0;

  // update the sum of filter entries
  p->sum -= p->cyc[p->index];   // subtract oldest sample
  p->cyc[p->index] = cyc;       // save new sample
  p->sum += cyc;                // add new sample

  return p->sum / p->entries;   // return mean value

}  /* do_filter */



static
struct shmTime *getShmTime( int unit )
{
  struct shmTime *p;

  int shmid = shmget( (key_t) ( NTPD_BASE + unit ),
                      sizeof( struct shmTime ), IPC_CREAT | 0644 );

  if ( shmid == -1 )
  {
    mbg_log( LOG_ERR, "shmget %i failed: %s", unit, strerror( errno ) );
    return NULL;
  }


  p = (struct shmTime *) shmat( shmid, 0, 0 );

  if ( (long) p == -1L )
  {
    mbg_log( LOG_ERR, "shmat %i failed: %s", unit, strerror( errno ) );
    return NULL;
  }

  return p;

}  // getShmTime



static /*HDR*/
int ntpshm_init( int n_units )
{
  int i;
  int ret_val = 0;

  for ( i = 0; i < n_units; i++ )
  {
    struct shmTime *p = getShmTime( i );
    shmTime[i] = p;

    if ( p == NULL )
    {
      mbg_log( LOG_WARNING, "** Failed to initialize NTP SHM unit %i", i );
      ret_val = -1;
      continue;
    }

    memset( p, 0, sizeof( *p ) );

    p->mode = 1;
    p->precision = -5;  /* initially 0.5 sec */
    p->nsamples = 3;    /* stages of median filter */

    mbg_log( LOG_INFO, "NTP SHM unit %i initialized successfully", i );
  }

  return ret_val;

}  // ntpshm_init



static /*HDR*/
int do_mbgsvctasks( void )
{
  MBG_PC_CYCLES_FREQUENCY cyc_freq;
  MBG_TIME_INFO_HRT hrti;
  PCPS_TIME_STAMP *p_ref_ts;
  MBG_PC_CYCLES *p_ref_cyc;
  MBG_SYS_TIME_CYCLES *p_sys_tic;
  char ws[256];
  double d_ref;
  double d_sys;
  int rc = 0;
  int n_devices_found;
  int n_devices;
  MBG_DEV_HANDLE dhs[MAX_SHM_REFCLOCKS];
  PCPS_DEV devs[MAX_SHM_REFCLOCKS];
  int i;

  n_devices_found = mbg_find_devices();

  for ( i = 0, n_devices = 0; i < n_devices_found; i++ )
  {
    MBG_DEV_HANDLE dh = mbg_open_device( i );
    PCPS_DEV dev_info;

    rc = mbg_get_device_info( dh, &dev_info );

    if ( rc < 0 )
    {
      mbg_log( LOG_WARNING, "Failed to read device info from device #%i.", i );
      mbg_close_device( &dh );
      continue;
    }

    if ( !_pcps_has_hr_time( &dev_info ) )
    {
      mbg_log( LOG_WARNING, "Device %s does not support HR time stamps.",
               _pcps_type_name( &dev_info ) );
      mbg_close_device( &dh );
      continue;
    }

    dhs[n_devices] = dh;
    devs[n_devices] = dev_info;

    if ( ++n_devices >= MAX_SHM_REFCLOCKS )
      break;
  }

  if ( n_devices == 0 )
  {
    mbg_log( LOG_WARNING, "No usable device found!" );
    goto done;
  }


  // Search for devices up to the maximum of supported NTP SHM refclocks
  if ( n_devices > MAX_SHM_REFCLOCKS )
    n_devices = MAX_SHM_REFCLOCKS;

  mbg_log( LOG_INFO, "Found %d devices usable for the NTP daemon", n_devices );  //##++++

  rc = mbg_get_default_cycles_frequency_from_dev( dhs[0], &cyc_freq );

  if ( mbg_ioctl_err( rc, "mbg_get_default_cycles_frequency_from_dev" ) )
    goto done;


  mbg_log( LOG_INFO, "%sPC cycles counter clock frequency: %Lu Hz",
           ( cyc_freq == 0 ) ? "*** Warning: " : "",
           (unsigned long long) cyc_freq );

  // Initialize NTP shared memory area
  ntpshm_init( n_devices );

  for (;;)
  {
    for ( i = 0; i < n_devices; i++ )
    {
      double ltcy_sec;
      double d_ref_comp;
      MBG_PC_CYCLES ltcy_cyc;
      MBG_PC_CYCLES exec_cyc;
      MBG_PC_CYCLES exec_cyc_limit;
      MBG_PC_CYCLES tmp;
      const char *cp;

      rc = mbg_get_time_info_hrt( dhs[i], &hrti );

      if ( mbg_ioctl_err( rc, "mbg_get_time_info_hrt" ) )
        continue;


      p_ref_ts = &hrti.ref_hr_time_cycles.t.tstamp;
      p_ref_cyc = &hrti.ref_hr_time_cycles.cycles;
      p_sys_tic = &hrti.sys_time_cycles;

      d_ref = (double) p_ref_ts->sec + ( (double) p_ref_ts->frac ) / (double) PCPS_HRT_BIN_FRAC_SCALE;
      d_sys = (double) p_sys_tic->sys_time.sec + (double) p_sys_tic->sys_time.nsec / 1e9;

      ltcy_cyc = mbg_delta_pc_cycles( p_ref_cyc, &p_sys_tic->cyc_after );
      exec_cyc = mbg_delta_pc_cycles( &p_sys_tic->cyc_after, &p_sys_tic->cyc_before );

      ltcy_sec = cyc_freq ? ( ( (double) ltcy_cyc ) / (double) cyc_freq ) : 0.0;

      // Compensate latencies between time stamps ->
      // normalize ref time to system time stamp
      d_ref_comp = d_ref - ltcy_sec;

      exec_cyc_limit = do_filter( &filter, exec_cyc );

      // Try to set the limit to 1.7 of the mean execution cycles.
      tmp = ( 7 * exec_cyc_limit ) / 10;

      // If execution takes only a few cycles make sure the limit
      // is above the mean number of cycles.
      if ( tmp == 0 )
        tmp++;

      exec_cyc_limit += tmp;

      cp = "";

      // check if refclock is sync and if exec time of the system time call was fast enough
      if ( ( exec_cyc <= exec_cyc_limit ) && ( pretend_sync || (
           ( ( hrti.ref_hr_time_cycles.t.status & PCPS_FREER ) == 0 ) &&
           ( ( hrti.ref_hr_time_cycles.t.status & PCPS_SYNCD ) != 0 ) ) ) ) 
      {
        struct shmTime *p = shmTime[i];

        if ( p )
        {
          cp = " *";

          // fill SHM structure
          p->count++;
          p->clockTimeStampSec = (time_t) d_ref_comp;
          p->clockTimeStampUSec = (int) ( ( d_ref_comp - p->clockTimeStampSec ) * 1e6 ); // get µs from d_ref
          p->receiveTimeStampSec = (time_t) p_sys_tic->sys_time.sec;
          p->receiveTimeStampUSec = (int) ( p_sys_tic->sys_time.nsec / 1000 );

          // patch precision value according to the ref time accuracy
          if ( _pcps_is_lwr( &devs[i] ) )
            p->precision = -8;
          else
          {
            if ( _pcps_is_irig_rx( &devs[i] ) )
            {
              if ( _pcps_is_usb( &devs[i] ) )
                p->precision = -10;
              else
                p->precision = -18;
            }
            else
              p->precision = -20;
          }

          if ( hrti.ref_hr_time_cycles.t.status & PCPS_LS_ANN_NEG )
            p->leap = LEAP_DELSECOND;
          else
            if ( hrti.ref_hr_time_cycles.t.status & PCPS_LS_ANN )
              p->leap = LEAP_ADDSECOND;
            else
              p->leap = LEAP_NOWARNING;

          p->count++;
          p->valid = 1;
        }
      }

      mbg_snprint_hr_tstamp( ws, sizeof( ws ), p_ref_ts, 0 );  // raw timestamp?

      printf( "%-9s: %s: %.7f-%.7f: %+.7f %+.7f, ltcy: ",
              _pcps_type_name( &devs[i] ), ws, d_ref, d_sys,
              d_ref - d_sys, d_ref_comp - d_sys );

      if ( cyc_freq != 0 )  // print latency and execution time in microseconds
      {
        double exec_sec = (double) exec_cyc / (double) cyc_freq;
        double exec_sec_limit = (double) exec_cyc_limit / (double) cyc_freq;

        printf( "%.2f us, exec: %.2f us, limit: %.2f us",
                ltcy_sec * 1e6, exec_sec * 1e6, exec_sec_limit * 1e6 );
      }
      else  // print latency and execution time in cycles only
      {
        printf( "%lli cyc, exec: %lli cyc, limit: %lli cyc",
                (long long) ltcy_cyc, (long long) exec_cyc,
                (long long) exec_cyc_limit );
      }

      printf( "%s\n", cp );

      usleep( 10 );
    }

    if ( n_devices > 1 )
      printf( "\n" );

    if ( sleep_intv )
      sleep( sleep_intv );
  }

done:
  for ( i = 0; i < n_devices; i++ )
    mbg_close_device( &dhs[i] );

  return rc;

}  // do_mbgsvctasks



static /*HDR*/
void usage( void )
{
  mbg_print_usage_intro( pname,
    "This program periodically reads a reference time stamp and an associated\n"
    "system time stamp from every mbgclock device, and feeds the time stamp pairs\n"
    "to the NTP daemon's shared memory refclock driver.\n"
    "It usually runs as daemon but can also be run in the foreground to monitor the\n"
    "time stamps and offsets.\n"
    "This works only for cards supporting high resolution time stamps.\n"
  );
  mbg_print_help_options();
  mbg_print_opt_info( "-f", "run program in foreground" );
  mbg_print_opt_info( "-s num", "sleep num seconds between calls" );
  mbg_print_opt_info( "-p", "pretend device is always synchronized" );
  mbg_print_device_options();
  puts( "" );

}  // usage



static /*HDR*/
void startup_daemon( void )
{
  int i;
  int lfp;
  int rc;
  char str[1024];

  if ( getppid() == 1 )
    return; /* already a daemon */

  mbg_log( LOG_INFO, "Daemon mode, backgrounding" );
  i = fork();

  if ( i < 0 )
    exit( 1 );  /* fork error */

  if ( i > 0 )
    exit( 0 );  /* parent exits */


  /* child (daemon) continues */
  setsid(); /* obtain a new process group */

  for ( i = getdtablesize(); i >= 0; --i )
    close( i ); /* close all descriptors */

  /* handle standard I/O */
  i = open( "/dev/null", O_RDWR );
  rc = dup( i );
  rc = dup( i );

  umask( 027 );  /* set newly created file permissions */
  rc = chdir( RUNNING_DIR ); /* change running directory */

  lfp = open( LOCK_FILE, O_RDWR | O_CREAT, 0640 );

  if ( lfp < 0 )
    exit( 1 );  /* unable to open lock file */

  if ( lockf( lfp, F_TLOCK, 0 ) < 0 ) 
  {
    mbg_log( LOG_ERR, "Lock file already exists, another instance of this daemon seems to be running" );
    closelog();
    exit( 0 );  /* can not lock */
  }

  /* first instance continues */
  snprintf( str, sizeof( str ), "%d\n", getpid() );
  rc = write( lfp, str, strlen( str ) );  /* record pid to lockfile */

  signal( SIGCHLD, SIG_IGN ); /* ignore child */
  signal( SIGTSTP, SIG_IGN ); /* ignore tty signals */
  signal( SIGTTOU, SIG_IGN );
  signal( SIGTTIN, SIG_IGN );

}  // startup_daemon



int main( int argc, char *argv[] )
{
  int rc;
  int c;
  int foreground = 0;

  mbg_print_program_info( pname, MBG_MICRO_VERSION, MBG_FIRST_COPYRIGHT_YEAR, MBG_LAST_COPYRIGHT_YEAR );

  // check command line parameters
  while ( ( c = getopt( argc, argv, "fps:h?" ) ) != -1 )
  {
    switch ( c )
    {
      case 'f':
        foreground = 1;
        break;

      case 'p':
        pretend_sync = 1;
        break;

      case 's':
        sleep_intv = atoi( optarg );
        break;

      case 'h':
      case '?':
      default:
        must_print_usage = 1;
    }
  }

  if ( must_print_usage )
  {
    usage();
    return 1;
  }

  if ( foreground == 0 )
  {
    char ws[256];

    mbg_program_info_str( ws, sizeof( ws ), pname, MBG_MICRO_VERSION,
                          MBG_FIRST_COPYRIGHT_YEAR, MBG_LAST_COPYRIGHT_YEAR );

    mbg_log( LOG_INFO, "Starting Meinberg Service Daemon %s", ws );

    startup_daemon();
  }

  rc = do_mbgsvctasks();

  return abs( rc );
}
