
/**************************************************************************
 *
 *  $Id: rsrc_lx.c 1.6 2011/07/20 15:02:44 martin TEST $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Interface functions for the Linux resource manager.
 *
 * -----------------------------------------------------------------------
 *  $Log: rsrc_lx.c $
 *  Revision 1.6  2011/07/20 15:02:44  martin
 *  Account for modified type of symbol pcps_driver_name.
 *  Revision 1.5  2009/07/22 12:31:31  martin
 *  Cleaned up region handling across kernel versions.
 *  Revision 1.4  2008/12/05 12:02:06  martin
 *  Expect port addr as ulong.
 *  Revision 1.3  2004/11/09 14:49:56  martin
 *  Modified resource allocation code to match latest requirements.
 *  Included some macros to support calls used with older kernels.
 *  Revision 1.2  2001/03/05 16:26:59  MARTIN
 *  Removed obsolete/unused functions.
 *
 **************************************************************************/

#define _RSRC_LX
 #include <rsrc_lx.h>
#undef _RSRC_LX

#include <linux/ioport.h>
#include <linux/version.h>

extern const char pcps_driver_name[];



/*HDR*/
int rsrc_alloc_ports( ulong port, ulong n, ushort decode_width )
{
#if defined( KERNEL_VERSION ) && ( LINUX_VERSION_CODE >= KERNEL_VERSION( 2, 4, 0 ) )

  // In kernel versions 2.4.0 and later we can simply call request_region()
  // which returns a NULL pointer if the call fails.

  return request_region( port, n, pcps_driver_name ) ? 0 : -1;

#else

  // In kernel versions older than 2.4.0 request_region() may not return a result.
  // We need to call check_region() first, and if that call doesn't fail then 
  // the subsequent call to request_region won't fail, either.

  int rc = check_region( port, n );

  if ( rc < 0 )
    return rc;

  request_region( port, n, pcps_driver_name );

  return 0;

#endif

}  // rsrc_alloc_ports



/*HDR*/
void rsrc_dealloc_ports( ulong port, ulong n )
{
  release_region( port, n );

}  // rsrc_dealloc_ports



