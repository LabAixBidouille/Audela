
/**************************************************************************
 *
 *  $Id: mbgirigcfg.c 1.10.1.12 2011/07/19 12:59:06 martin TEST $
 *
 *  Description:
 *    Main file for the mbgirigcfg program which can be used to configure
 *    the IRIG code frame and the UTC offset of the time contained in the
 *    IRIG code.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgirigcfg.c $
 *  Revision 1.10.1.12  2011/07/19 12:59:06  martin
 *  Revision 1.10.1.11  2011/07/07 15:08:35  martin
 *  Removed obsolete code.
 *  Revision 1.10.1.10  2011/07/06 14:53:50  martin
 *  Revision 1.10.1.9  2011/07/05 15:35:54  martin
 *  Modified version handling.
 *  Revision 1.10.1.8  2011/07/05 14:35:18  martin
 *  New way to maintain version information.
 *  Revision 1.10.1.7  2011/07/05 12:24:58  martin
 *  Revision 1.10.1.6  2011/07/04 10:30:29  martin
 *  Use getopt() for option processing.
 *  Support multiple devices.
 *  Revision 1.10.1.5  2011/07/01 13:49:47  martin
 *  bug fixes.
 *  Revision 1.10.1.4  2011/02/02 12:28:44  martin
 *  Revision 1.10.1.3  2010/08/30 08:22:24  martin
 *  Revision 1.10.1.2  2010/08/19 13:57:42  martin
 *  Revision 1.10.1.1  2010/08/19 11:26:12  martin
 *  Accept parameter -? to print usage.
 *  New parameter -i to let incoming TFOM flag be ignored.
 *  Revision 1.10  2009/09/29 15:02:15  martin
 *  Updated version number to 3.4.0.
 *  Revision 1.9  2009/07/24 09:50:08  martin
 *  Updated version number to 3.3.0.
 *  Revision 1.8  2009/06/19 12:38:51  martin
 *  Updated version number to 3.2.0.
 *  Revision 1.7  2009/03/19 17:07:16  martin
 *  Updated version number to 3.1.0.
 *  Updated copyright year to include 2009.
 *  Include mbgtime.h for some symbolic constants.
 *  Revision 1.6  2008/12/22 12:42:58  martin
 *  Updated description, copyright, revision number and string.
 *  Use unified functions from toolutil module.
 *  Accept device name(s) on the command line.
 *  Don't use printf() without format, which migth produce warnings
 *  with newer gcc versions.
 *  Revision 1.5  2007/07/24 09:34:46  martin
 *  Changes due to renamed library symbols.
 *  Updated copyright to include 2007.
 *  Revision 1.4  2006/08/28 10:08:17  martin
 *  Display TFOM settings only it the selected IRIG code format supports TFOM.
 *  Revision 1.3  2006/07/03 13:27:31  martin
 *  Source code cleanup and fixed a typo.
 *  Revision 1.2  2004/11/08 15:59:10  martin
 *  Support separate config of IRIG RX and TX.
 *  Changes due to renamed symbols.
 *  Revision 1.1  2003/04/25 10:42:10  martin
 *
 **************************************************************************/

// include Meinberg headers
#include <mbgdevio.h>
#include <mbgtime.h>
#include <pcpsmktm.h>
#include <pcpsutil.h>
#include <pcpslstr.h>
#include <myutil.h>
#include <toolutil.h>

// include system headers
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>


#define MBG_MICRO_VERSION          0
#define MBG_FIRST_COPYRIGHT_YEAR   2003
#define MBG_LAST_COPYRIGHT_YEAR    0     // use default

static const char pname[] = "mbgirigcfg";


static int glb_argc;
static char **glb_argv;

static const char str_yes[] = "YES";
static const char str_no[] = "NO";
static const char str_not_supp[] = "  (not supp. by this frame type)";

static const char info_curr[] = "Current";
static const char info_new[] = "New";
static const char msg_rx[] = DEFAULT_OPT_NAME_IRIG_RX_EN;
static const char msg_tx[] = DEFAULT_OPT_NAME_IRIG_TX_EN;

static IRIG_INFO irig_rx_info;
static IRIG_INFO irig_tx_info;
static MBG_REF_OFFS ref_offs;
static MBG_OPT_INFO opt_info;

static int cfg_err_rx;
static int cfg_err_tx;
static int changed_cfg_rx;
static int changed_cfg_tx;
static int warned_no_rx;
static int warned_no_tx;

static int must_print_help_info;

static const char *icode_rx_names[N_ICODE_RX] = DEFAULT_ICODE_RX_NAMES;
static const char *icode_rx_descr[N_ICODE_RX] = DEFAULT_ICODE_RX_DESCRIPTIONS_ENG;

static const char *icode_tx_names[N_ICODE_TX] = DEFAULT_ICODE_TX_NAMES;
static const char *icode_tx_descr[N_ICODE_TX] = DEFAULT_ICODE_TX_DESCRIPTIONS_ENG;

static int max_ref_offs_h = MBG_REF_OFFS_MAX / MINS_PER_HOUR;


static /*HDR*/
int get_cfg( MBG_DEV_HANDLE dh, const PCPS_DEV *pdev )
{
  int rc_rx = MBG_SUCCESS;
  int rc_tx = MBG_SUCCESS;

  if ( _pcps_is_irig_rx( pdev ) )
  {
    rc_rx = mbg_get_irig_rx_info( dh, &irig_rx_info );

    if ( rc_rx == MBG_SUCCESS && _pcps_has_ref_offs( pdev ) )
      rc_rx = mbg_get_ref_offs( dh, &ref_offs );

    if ( rc_rx == MBG_SUCCESS && _pcps_has_opt_flags( pdev ) )
      rc_rx = mbg_get_opt_info( dh, &opt_info );
  }

  if ( _pcps_has_irig_tx( pdev ) )
  {
    rc_tx = mbg_get_irig_tx_info( dh, &irig_tx_info );
  }


  if ( rc_rx != MBG_SUCCESS )
    printf( "** Error reading current IRIG RX configuration.\n" );

  if ( rc_tx != MBG_SUCCESS )
    printf( "** Error reading current IRIG TX configuration.\n" );

  if ( rc_rx != MBG_SUCCESS || rc_tx != MBG_SUCCESS )
    return -1;  //##++

  return MBG_SUCCESS;

}  // get_cfg



static /*HDR*/
int save_cfg( MBG_DEV_HANDLE dh, const PCPS_DEV *pdev )
{
  int rc_rx = MBG_SUCCESS;
  int rc_tx = MBG_SUCCESS;

  if ( _pcps_is_irig_rx( pdev ) )
  {
    rc_rx = mbg_set_irig_rx_settings( dh, &irig_rx_info.settings );

    if ( rc_rx == MBG_SUCCESS && _pcps_has_ref_offs( pdev ) )
      rc_rx = mbg_set_ref_offs( dh, &ref_offs );

    if ( rc_rx == MBG_SUCCESS && _pcps_has_opt_flags( pdev ) )
      rc_rx = mbg_set_opt_settings( dh, &opt_info.settings );
  }

  if ( rc_rx == MBG_SUCCESS && _pcps_has_irig_tx( pdev ) )
  {
    rc_tx = mbg_set_irig_tx_settings( dh, &irig_tx_info.settings );
  }

  if ( rc_rx != MBG_SUCCESS )
    printf( "** Error writing IRIG RX configuration.\n" );

  if ( rc_tx != MBG_SUCCESS )
    printf( "** Error writing IRIG TX configuration.\n" );

  if ( rc_rx != MBG_SUCCESS || rc_tx != MBG_SUCCESS )
    return -1;

  return MBG_SUCCESS;

}  // save_cfg



static /*HDR*/
void print_cfg_rx( const char *info, const char *msg )
{
  int idx = irig_rx_info.settings.icode;
  int ref_offs_h = ref_offs / MINS_PER_HOUR;

  printf( "%s %s configuration:\n", info, msg );

  printf( "  " DEFAULT_STR_IRIG_FMT_EN ":   %s, %s\n",
          icode_rx_names[idx],
          icode_rx_descr[idx]
        );

  printf( "  " DEFAULT_IGNORE_RX_TFOM_EN ":   %s%s\n",
          ( irig_rx_info.settings.flags & IFLAGS_DISABLE_TFOM ) ? str_yes : str_no,
          ( _idx_bit( idx ) & MSK_ICODE_RX_HAS_TFOM ) ? "" : str_not_supp );

  printf( "  " DEFAULT_STR_IRIG_OFFS_EN ":   " );

  if ( abs( ref_offs_h ) > max_ref_offs_h )
    printf( "** not configured **\n" );
  else
    printf( "%+i h\n", ref_offs_h );

  if ( opt_info.supp_flags & MBG_OPT_FLAG_STR_UTC )
    printf( "  " DEFAULT_STR_IRIG_TIMESTR_UTC_EN ":   %s\n",
            ( opt_info.settings.flags & MBG_OPT_FLAG_STR_UTC ) ?
            str_yes : str_no );

}  // print_cfg_rx



static /*HDR*/
void print_cfg_tx( const char *info, const char *msg )
{
  int idx = irig_tx_info.settings.icode;

  printf( "%s %s configuration:\n", info, msg );

  printf( "  " DEFAULT_STR_IRIG_FMT_EN ":   %s, %s\n",
          icode_tx_names[idx],
          icode_tx_descr[idx]
        );

  printf( "  " DEFAULT_STR_TFOM_ALWAYS_SYNC_EN ":   %s%s\n",
          ( irig_tx_info.settings.flags & IFLAGS_DISABLE_TFOM ) ? str_yes : str_no,
          ( _idx_bit( idx ) & MSK_ICODE_TX_HAS_TFOM ) ? "" : str_not_supp );

  printf( "  " DEFAULT_STR_IRIG_OUTPUT_LOC_TM_EN ":   %s\n",
    ( irig_tx_info.settings.flags & IFLAGS_TX_GEN_LOCAL_TIME ) ?
    str_yes : str_no
  );

}  // print_cfg_tx



static /*HDR*/
void set_new_icode_rx( char *s )
{
  int idx = atoi( s );

  if ( idx >= N_ICODE_RX )
  {
    printf( "** IRIG RX code index %i is out of range (0..%i).\n",
            idx, N_ICODE_RX - 1 );
    cfg_err_rx = 1;
    return;
  }

  if ( _is_supported( idx, irig_rx_info.supp_codes ) )
  {
    irig_rx_info.settings.icode = idx;
    changed_cfg_rx = 1;
  }
  else
  {
    printf( "** IRIG RX code \"%s\" not supported by this device.\n",
            icode_rx_names[idx] );
    cfg_err_rx = 1;
  }

}  // set_new_icode_rx



static /*HDR*/
void set_new_ref_offs( char *s )
{
  int new_ref_offs_h;

  new_ref_offs_h = atoi( s );

  if ( abs( new_ref_offs_h ) > max_ref_offs_h )
  {
    printf( "** New IRIG time offset %ih exceeds range (%+ih..%+ih).\n",
            new_ref_offs_h, -max_ref_offs_h, max_ref_offs_h );
    cfg_err_rx = 1;
  }
  else
  {
    ref_offs = new_ref_offs_h * MINS_PER_HOUR;
    changed_cfg_rx = 1;
  }

}  // set_new_ref_offs



static /*HDR*/
void set_new_str_utc( char *s )
{
  int this_cfg_err;

  if ( !( opt_info.supp_flags & MBG_OPT_FLAG_STR_UTC ) )
    return;  // not supported


  this_cfg_err = 0;

  if ( strcmp( s, "1" ) == 0 )
    opt_info.settings.flags |= MBG_OPT_FLAG_STR_UTC;
  else
    if ( strcmp( s, "0" ) == 0 )
      opt_info.settings.flags &= ~MBG_OPT_FLAG_STR_UTC;
    else
      this_cfg_err = 1;

  if ( this_cfg_err )
    cfg_err_rx = 1;
  else
    changed_cfg_rx = 1;

}  // set_new_str_utc



static /*HDR*/
void set_new_icode_tx( char *s )
{
  int idx = atoi( s );

  if ( idx >= N_ICODE_TX )
  {
    printf( "** IRIG TX code index %i is out of range (0..%i).\n",
            idx, N_ICODE_TX - 1 );
    cfg_err_tx = 1;
    return;
  }

  if ( _is_supported( idx, irig_tx_info.supp_codes ) )
  {
    irig_tx_info.settings.icode = idx;
    changed_cfg_tx = 1;
  }
  else
  {
    printf( "** IRIG TX code \"%s\" not supported by this device.\n",
            icode_tx_names[idx] );
    cfg_err_tx = 1;
  }

}  // set_new_icode_tx



static /*HDR*/
void set_new_irig_tx_local( char *s )
{
  int this_cfg_err = 0;

  if ( strcmp( s, "1" ) == 0 )
    irig_tx_info.settings.flags |= IFLAGS_TX_GEN_LOCAL_TIME;
  else
    if ( strcmp( s, "0" ) == 0 )
      irig_tx_info.settings.flags &= ~IFLAGS_TX_GEN_LOCAL_TIME;
    else
      this_cfg_err = 1;

  if ( this_cfg_err )
    cfg_err_tx = 1;
  else
    changed_cfg_tx = 1;

}  // set_new_irig_tx_local



static /*HDR*/
void set_new_tfom_flag( char *s, IRIG_SETTINGS *p, int *changed_flag, int *err_flag )
{
  if ( !(_idx_bit( p->icode ) & MSK_ICODE_TX_HAS_TFOM ) )
    return;  // not supported


  if ( strcmp( s, "1" ) == 0 )
    p->flags |= IFLAGS_DISABLE_TFOM;
  else
    if ( strcmp( s, "0" ) == 0 )
      p->flags &= ~IFLAGS_DISABLE_TFOM;
    else
    {
      *err_flag = 1;
      return;
    }

  *changed_flag = 1;

}  // set_new_tfom_flag



static /*HDR*/
int chk_dev_rx( const PCPS_DEV *pdev )
{
  if ( pdev )
  {
    if ( _pcps_is_irig_rx( pdev ) )
      return 1;

    if ( !warned_no_rx )
    {
      printf( "** This device does not provide an IRIG input.\n" );
      warned_no_rx = 1;
    }

    cfg_err_rx = 1;
  }

  return 0;

}  // chk_dev_rx



static /*HDR*/
int chk_dev_tx( const PCPS_DEV *pdev )
{
  if ( pdev )
  {
    if ( _pcps_has_irig_tx( pdev ) )
      return 1;

    if ( !warned_no_tx )
    {
      printf( "** This device does not provide an IRIG output.\n" );
      warned_no_tx = 1;
    }

    cfg_err_tx = 1;
  }

  return 0;

}  // chk_dev_tx



static /*HDR*/
void check_cmd_line( int argc, char *argv[], const PCPS_DEV *pdev )
{
  int c;

  // force checking all parameters since this may be called several times
  optind = 1;

  while ( ( c = getopt( argc, argv, "h?" "r:o:u:i:" "t:l:s:"  ) ) != -1 )
  {
    switch ( c )
    {
      case '?':
      case 'h':
        must_print_usage = 1;
        break;


      // IRIG receiver options

      case 'r':    // IRIG RX code frame
        if ( chk_dev_rx( pdev ) )
          set_new_icode_rx( optarg );
        break;

      case 'o':    // incoming time offset from UTC
        if ( chk_dev_rx( pdev ) )
          set_new_ref_offs( optarg );
        break;

      case 'u':    // option flag: serial output is always UTC
        if ( chk_dev_rx( pdev ) )
          set_new_str_utc( optarg );
        break;

      case 'i':    // option flag: ignore incoming TFOM flag, alway sync
        if ( chk_dev_rx( pdev ) )
          set_new_tfom_flag( optarg, &irig_rx_info.settings, &changed_cfg_rx, &cfg_err_rx );
        break;


      // IRIG output options

      case 't':    // IRIG TX code frame
        if ( chk_dev_tx( pdev ) )
          set_new_icode_tx( optarg );
        break;

      case 'l':    // option flag: transmit local time, not UTC
        if ( chk_dev_tx( pdev ) )
          set_new_irig_tx_local( optarg );
        break;

      case 's':    // option flag: send TFOM as always "sync"
        if ( chk_dev_tx( pdev ) )
          set_new_tfom_flag( optarg, &irig_tx_info.settings, &changed_cfg_tx, &cfg_err_tx );
        break;

    }  // switch

  }

}  // check_cmd_line



static /*HDR*/
void usage( void )
{
  const char *frame_fmt = "           %4i  %s, %s\n";
  int i;

  printf(
    "Usage:  %s [-h]|[option] [option] ...\n"
    "\n",
    pname
  );

  printf(
    "  -h or -?  prints this info\n"
    "\n"
  );


  printf(
    "Options supported by IRIG receivers:\n"
    "\n"
  );

  printf(
    "  -r code   specifies the IRIG receiver code format, where \"code\" \n"
    "            can be one a number according to the table below:\n"
  );

  for ( i = 0; i < N_ICODE_RX; i++ )
    printf( frame_fmt, i, icode_rx_names[i], icode_rx_descr[i] );

  printf( "\n" );

  printf(
    "  -o offs   specifies the IRIG input time offset from UTC, in hours,\n"
    "            where \"offs\" can be a value in the range %+i..%+i\n"
    "\n",
    -max_ref_offs_h, max_ref_offs_h
  );

  printf(
    "  -u flag   determines whether the time string sent via the\n"
    "            board's serial output contains always UTC time\n"
    "            or the same time as received from the IRIG input\n"
    "            signal. \"flag\" can be \"1\" for always UTC,\n"
    "            or \"0\" for IRIG time.\n"
    "\n"
  );

  printf(
    "  -i flag   If \"flag\" is set to \"1\" then the TFOM qualifier in the\n"
    "            incoming IRIG signal is ignored, i.e. the receiver even synchronizes\n"
    "            to an input signal if the TFOM codes says the generator is freewheeling.\n"
    "            Please note that most IRIG codes do not support a TFOM qualifier.\n"
    "\n"
  );

  printf(
    "Options supported by IRIG transmitters:\n"
    "\n"
  );

  printf(
    "  -t code   specifies the IRIG transmitter code format, where \"code\" \n"
    "            can be one a number according to the table below:\n"
  );

  for ( i = 0; i < N_ICODE_TX; i++ )
    printf( frame_fmt, i, icode_tx_names[i], icode_tx_descr[i] );

  printf( "\n" );

  printf(
    "  -l flag   determines whether IRIG output shall contain local\n"
    "            time, or UTC. \"flag\" must be \"1\" for local time,\n"
    "            or \"0\" for UTC.\n"
    "\n"
  );

  printf(
    "  -s flag   If \"flag\" is set to \"1\" then the TFOM qualifier in the\n"
    "            IRIG output is always set to \"synchronized\". If it is \"0\" \n"
    "            then the qualifier reflects the current status of the input signal.\n"
    "            Please note that most IRIG codes do not support a TFOM qualifier.\n"
    "\n"
  );


  printf(
    "If no parameters are given the program reports the current settings.\n"
    "Please note that not all IRIG codes must be supported by all devices.\n"
  );

}  // usage



static /*HDR*/
int do_mbgirigcfg( MBG_DEV_HANDLE dh, const PCPS_DEV *p_dev )
{
  int rc = MBG_SUCCESS;

  cfg_err_rx = 0;
  cfg_err_tx = 0;
  changed_cfg_rx = 0;
  changed_cfg_tx = 0;
  warned_no_rx = 0;
  warned_no_tx = 0;

  rc = get_cfg( dh, p_dev );

  if ( !_pcps_has_irig( p_dev ) )
  {
    printf( "** This device does not provide an IRIG input or output.\n" );
    must_print_help_info = 1;
    return rc;
  }

  check_cmd_line( glb_argc, glb_argv, p_dev );

  if ( cfg_err_rx || cfg_err_tx )
    must_print_help_info = 1;

  if ( changed_cfg_rx || changed_cfg_tx )
  {

    if ( changed_cfg_rx )
      print_cfg_rx( info_new, msg_rx );

    if ( changed_cfg_tx )
      print_cfg_tx( info_new, msg_tx );

    rc = save_cfg( dh, p_dev );

    if ( mbg_ioctl_err( rc, "save IRIG configuration" ) )
      goto done;
  }
  else
  {
    if ( _pcps_is_irig_rx( p_dev ) )
      print_cfg_rx( info_curr, msg_rx );

    if ( _pcps_has_irig_tx( p_dev ) )
      print_cfg_tx( info_curr, msg_tx );

    must_print_help_info = 1;
  }

done:
  return rc;

}  // do_mbgirigcfg



int main( int argc, char *argv[] )
{
  int rc;

  mbg_print_program_info( pname, MBG_MICRO_VERSION, MBG_FIRST_COPYRIGHT_YEAR, MBG_LAST_COPYRIGHT_YEAR );

  check_cmd_line( argc, argv, NULL );

  if ( must_print_usage )
  {
    usage();
    return 1;
  }


  glb_argc = argc;
  glb_argv = argv;


  // The function below checks which devices have been specified
  // on the command, and for each device
  // - tries to open the device
  // - shows basic device info
  // - calls the function passed as last parameter
  rc = mbg_check_devices( glb_argc, glb_argv, optind, do_mbgirigcfg );

  if ( must_print_help_info )
    printf( "For help type \"%s -h\"\n\n", pname );

  return abs( rc );
}
