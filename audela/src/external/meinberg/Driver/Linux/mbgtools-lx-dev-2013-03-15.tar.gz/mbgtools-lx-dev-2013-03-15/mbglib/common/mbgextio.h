
/**************************************************************************
 *
 *  $Id: mbgextio.h 1.11 2013/02/06 15:44:57 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Definitions and prototypes for mbgextio.c.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgextio.h $
 *  Revision 1.11  2013/02/06 15:44:57  martin
 *  Updated function prototypes.
 *  Revision 1.10  2013/02/01 15:59:42  martin
 *  Updated function prototypes.
 *  Revision 1.9  2012/10/30 16:19:19  martin
 *  Support USB I/O.
 *  Started to migrate to opaque stuctures.
 *  Updated function prototypes.
 *  Revision 1.8  2011/04/08 11:26:09  martin
 *  New macros _ttm_time_set_unavail() and _ttm_time_is_avail().
 *  Revision 1.7  2009/10/02 14:21:08  martin
 *  Updated function prototypes.
 *  Revision 1.6  2009/10/01 11:13:42Z  martin
 *  Updated function prototypes.
 *  Revision 1.5  2009/03/10 17:03:09Z  martin
 *  Updated function prototypes.
 *  Revision 1.4  2008/09/04 14:13:19Z  martin
 *  Added macro _mbgextio_xmt_msg().
 *  Updated function prototypes.
 *  Removed obsolete code.
 *  Revision 1.3  2007/02/27 10:30:06Z  martin
 *  Added some global variables.
 *  Updated function prototypes.
 *  Revision 1.2  2006/12/21 10:56:35  martin
 *  Updated function prototypes.
 *  Revision 1.1  2006/08/24 12:40:37  martin
 *  Initial revision.
 *
 **************************************************************************/

#ifndef _MBGEXTIO_H
#define _MBGEXTIO_H


/* Other headers to be included */

#include <gpsserio.h>
#include <time.h>

#ifdef _MBGEXTIO
 #define _ext
 #define _DO_INIT
#else
 #define _ext extern
#endif


/* Start of header body */


// The macros below can be used to set a TTM variable to a state
// indicating "time not available", and to check this state.
// This can be used for example to indicate if a capture event
// could have been read from a device, or not.
#define _ttm_time_set_unavail( _t )       do { (_t)->tm.sec = (uint8_t) 0xFF; } while ( 0 )
#define _ttm_time_is_avail( _t )          ( (uint8_t) (_t)->tm.sec != (uint8_t) 0xFF )


#if _USE_SERIAL_IO
  #if !defined( DEFAULT_DEV_NAME )
    #if defined( MBG_TGT_WIN32 ) || defined( MBG_TGT_DOS )
      #define DEFAULT_DEV_NAME   "COM1"
    #elif defined( MBG_TGT_LINUX )
      #define DEFAULT_DEV_NAME   "/dev/ttyS0"
    #endif
  #endif
#endif  // _USE_SERIAL_IO


#if !_USE_USB_IO
  // just to avoid build errors if USB not supported
  struct usb_device
  {
    int dummy;
  };
#endif


#if !defined MBGEXTIO_READ_BUFFER_SIZE
  #if _USE_SOCKET_IO || _USE_USB_IO
    #define MBGEXTIO_READ_BUFFER_SIZE  1000
  #else
    #define MBGEXTIO_READ_BUFFER_SIZE  10
  #endif
#endif


_ext uint32_t mbg_baud_rates[N_MBG_BAUD_RATES]
#ifdef _DO_INIT
  = MBG_BAUD_RATES
#endif
;

_ext const char *mbg_baud_rate_strs[N_MBG_BAUD_RATES]
#ifdef _DO_INIT
  = MBG_BAUD_STRS
#endif
;

_ext const char *mbg_framing_strs[N_MBG_FRAMINGS]
#ifdef _DO_INIT
  = MBG_FRAMING_STRS
#endif
;



/* function prototypes: */

#ifdef __cplusplus
extern "C" {
#endif

/* ----- function prototypes begin ----- */

/* This section was generated automatically */
/* by MAKEHDR, do not remove the comments. */

 /**
 * @brief Open a binary communication channel using LAN/socket connection
 *
 * See the common notes at the top of this file for details.
 *
 * @param host DNS name or IP address of the target device
 * @param passwd Password string for the encrypted communication
 *
 * @return A ::MBG_MSG_CTL control structure to be used with further API calls, or NULL on error
 *
 * @see mbgextio_open_serial
 * @see mbgextio_open_usb
 * @see mbgextio_close_connection
 */
 _NO_MBG_API_ATTR MBG_MSG_CTL * _MBG_API mbgextio_open_socket( const char *host, const char *passwd ) ;

 /**
 * @brief Open a binary communication channel using direct serial I/O
 *
 * See the common notes at the top of this file for details.
 *
 * @param dev       Name of the serial port to which the device is connected,
 *                  depending on the naming conventions of the target system
 * @param baud_rate Baud rate used for serial communication. Usually 19200
 * @param framing   Framing used for serial communication. Usually "8N1"
 *
 * @return A ::MBG_MSG_CTL control structure to be used with further API calls, or NULL on error
 *
 * @see mbgextio_open_socket
 * @see mbgextio_open_usb
 * @see mbgextio_close_connection
 */
 _NO_MBG_API_ATTR MBG_MSG_CTL * _MBG_API mbgextio_open_serial( const char *dev, uint32_t baud_rate, const char *framing ) ;

 /**
 * @brief Open a binary communication channel using direct USB I/O
 *
 * See the common notes at the top of this file for details.
 *
 * @param usbdev The internal USB device to communicate with
 *
 * @return A ::MBG_MSG_CTL control structure to be used with further API calls, or NULL on error
 *
 * @see mbgextio_open_socket
 * @see mbgextio_open_serial
 * @see mbgextio_close_connection
 */
 _NO_MBG_API_ATTR MBG_MSG_CTL * _MBG_API mbgextio_open_usb( const struct usb_device *usbdev ) ;

 /**
 * @brief Close a binary communication channel and release resources
 *
 * Closes a binary communication channel which has been opened by one
 * of the mbgextio_open_...() functions and releases the buffers which
 * have been allocated when the channel was opened.
 *
 * The address pointer the address of which is passed to this function
 * is set to NULL after the channel has been closed and the resources
 * have been released.
 *
 * @param ppmctl Address of a variable holding a ::MBG_MSG_CTL pointer
 *               returned when the channel was opened
 *
 * @see mbgextio_open_socket
 * @see mbgextio_open_serial
 * @see mbgextio_open_usb
 */
 _NO_MBG_API_ATTR void _MBG_API mbgextio_close_connection( MBG_MSG_CTL **ppmctl ) ;

 /**
 * @brief Try to force a serial connection to a device
 *
 * A device's serial port may have been configured to work by default
 * in a way which is not appropriate for binary communication, e.g. using
 * a low communication speed, or some framing like "7E2" which messes up
 * binary data since the parity bit overrides a data bit.
 *
 * This function sends a special command to a device which lets the device
 * temporarily switch to 19200/8N1 which is usually used for binary communication.
 * Since the current settings of the device's serial port are unknown this
 * this command is sent in all common combinations of baud rates and
 * framings.
 *
 * After this function has finished it should be possible to open the
 * communication channel using mbgextio_open_serial() eith the default
 * parameters 19200/8N1.
 *
 * @param dev  Name of the serial port to which the device is connected,
 *             depending on the naming conventions of the target system
 *
 * @return  0 on success, -1 if the serial port could not be opened
 *
 * @see mbgextio_open_serial
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_force_connection( const char *dev ) ;

 /**
 * @brief Retrieve address of the allocated receive buffer
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return Address of the allocated receive buffer
 *
 * @see mbgextio_get_rcv_buffer_size
 * @see mbgextio_get_xmt_buffer_addr
 * @see mbgextio_get_xmt_buffer_size
 */
 _NO_MBG_API_ATTR MBG_MSG_BUFF * _MBG_API mbgextio_get_rcv_buffer_addr( MBG_MSG_CTL *pmctl ) ;

 /**
 * @brief Retrieve size of the allocated receive buffer
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return Size of the allocated receive buffer
 *
 * @see mbgextio_get_rcv_buffer_addr
 * @see mbgextio_get_xmt_buffer_addr
 * @see mbgextio_get_xmt_buffer_size
 */
 _NO_MBG_API_ATTR size_t _MBG_API mbgextio_get_rcv_buffer_size( MBG_MSG_CTL *pmctl ) ;

 /**
 * @brief Retrieve address of the allocated transmit buffer
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return Address of the allocated transmit buffer
 *
 * @see mbgextio_get_rcv_buffer_addr
 * @see mbgextio_get_rcv_buffer_size
 * @see mbgextio_get_xmt_buffer_size
 */
 _NO_MBG_API_ATTR MBG_MSG_BUFF * _MBG_API mbgextio_get_xmt_buffer_addr( MBG_MSG_CTL *pmctl ) ;

 /**
 * @brief Retrieve size of the allocated transmit buffer
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return Size of the allocated transmit buffer
 *
 * @see mbgextio_get_rcv_buffer_addr
 * @see mbgextio_get_rcv_buffer_size
 * @see mbgextio_get_xmt_buffer_addr
 */
 _NO_MBG_API_ATTR size_t _MBG_API mbgextio_get_xmt_buffer_size( MBG_MSG_CTL *pmctl ) ;

 /**
 * @brief Set character receive timeout value
 *
 * @param pmctl        Pointer to a valid message control structure
 * @param new_timeout  New timeout value [ms]
 *
 * @see mbgextio_get_char_rcv_timeout
 * @see mbgextio_set_msg_rcv_timeout
 * @see mbgextio_get_msg_rcv_timeout
 */
 _NO_MBG_API_ATTR void _MBG_API mbgextio_set_char_rcv_timeout( MBG_MSG_CTL *pmctl, ulong new_timeout ) ;

 /**
 * @brief Get character receive timeout value
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return  Current timeout value [ms]
 *
 * @see mbgextio_set_char_rcv_timeout
 * @see mbgextio_set_msg_rcv_timeout
 * @see mbgextio_get_msg_rcv_timeout
 */
 _NO_MBG_API_ATTR ulong _MBG_API mbgextio_get_char_rcv_timeout( const MBG_MSG_CTL *pmctl ) ;

 /**
 * @brief Set message receive timeout value
 *
 * @param pmctl        Pointer to a valid message control structure
 * @param new_timeout  New timeout value [ms]
 *
 * @see mbgextio_set_char_rcv_timeout
 * @see mbgextio_get_char_rcv_timeout
 * @see mbgextio_get_msg_rcv_timeout
 */
 _NO_MBG_API_ATTR void _MBG_API mbgextio_set_msg_rcv_timeout( MBG_MSG_CTL *pmctl, ulong new_timeout ) ;

 /**
 * @brief Get message receive timeout value
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return  Current timeout value [ms]
 *
 * @see mbgextio_set_char_rcv_timeout
 * @see mbgextio_get_char_rcv_timeout
 * @see mbgextio_set_msg_rcv_timeout
 */
 _NO_MBG_API_ATTR ulong _MBG_API mbgextio_get_msg_rcv_timeout( const MBG_MSG_CTL *pmctl ) ;

 /**
 * @brief Set up and send a generic binary message
 *
 * @note This function should preferably be used only as low level function
 * called from within more specific functions used to send specific data.
 * If this function is called directly with a buffer to be sent then the
 * transmit mutex is acquired by this function. However, other (higher level)
 * API functions which set up the transmit buffer directly have to acquire
 * the transmit mutex by themselves before they set up the transmit buffer,
 * and pass a NULL pointer to indicate the transmit buffer has already been
 * set up. The correct number of bytes to send (n_bytes) has to be specified
 * anyway, though.
 *
 * @param pmctl    Pointer to a valid message control structure
 * @param cmd      One of the command codes enumerated in ::GPS_CMD_CODES
 * @param p        Address of a data structure according to the specified cmd parameter, or NULL
 * @param n_bytes  Size of the data structure addressed by parameter p
 *
 * @return  0 on success, < 0 on error //##++ @todo specify return codes
 *
 * @see mbgextio_rcv_msg
 * @see mbgextio_xmt_cmd
 * @see mbgextio_req_data
 * @see mbgextio_xmt_cmd_us
 * @see mbgextio_req_data_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_xmt_msg( MBG_MSG_CTL *pmctl, GPS_CMD cmd, const void *p, size_t n_bytes ) ;

 /**
 * @brief Generic reception of a binary message
 *
 * @note A certain message type to be waited for can be specified by
 * passing one of the command codes enumerated in ::GPS_CMD_CODES.
 * If the special cmd code GPS_WILDCARD is specified the function returns
 * successfully after *any* type of binary message has been received.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param cmd    One of the command codes enumerated in ::GPS_CMD_CODES, or ::GPS_WILDCARD
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_xmt_msg
 * @see mbgextio_xmt_cmd
 * @see mbgextio_req_data
 * @see mbgextio_xmt_cmd_us
 * @see mbgextio_req_data_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_rcv_msg( MBG_MSG_CTL *pmctl, GPS_CMD cmd ) ;

 /**
 * @brief Transmit a command-only message without additional data.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param cmd    One of the command codes enumerated in ::GPS_CMD_CODES
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_xmt_msg
 * @see mbgextio_rcv_msg
 * @see mbgextio_req_data
 * @see mbgextio_xmt_cmd_us
 * @see mbgextio_req_data_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_xmt_cmd( MBG_MSG_CTL *pmctl, GPS_CMD cmd ) ;

 /**
 * @brief Transmit a message without a single ushort (16 bit) parameter
 *
 * The ushort parameter is often used to send an index value when requesting
 * a certain element of an array of same data structures.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param cmd    One of the command codes enumerated in ::GPS_CMD_CODES
 * @param us     The parameter for the command code
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_xmt_msg
 * @see mbgextio_rcv_msg
 * @see mbgextio_xmt_cmd
 * @see mbgextio_req_data
 * @see mbgextio_req_data_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_xmt_cmd_us( MBG_MSG_CTL *pmctl, GPS_CMD cmd, uint16_t us ) ;

 /**
 * @brief Transmit a message without a single ushort (16 bit) parameter
 *
 * The ushort parameter is often used to send an index value when requesting
 * a specific element of an array of data structures.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param cmd    One of the command codes enumerated in ::GPS_CMD_CODES
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_xmt_msg
 * @see mbgextio_rcv_msg
 * @see mbgextio_xmt_cmd
 * @see mbgextio_xmt_cmd_us
 * @see mbgextio_req_data_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_req_data( MBG_MSG_CTL *pmctl, GPS_CMD cmd ) ;

 /**
 * @brief Read a specific element of an array of data structures
 *
 * The type of data is implicitely associated to the cmd parameter.
 * Usually the number of supported array elements has to be determined
 * by some other means, e.g. from a field in the ::RECEIVER_INFO structure.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param cmd    One of the command codes enumerated in ::GPS_CMD_CODES
 * @param idx    The index of the array element to read
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_xmt_msg
 * @see mbgextio_rcv_msg
 * @see mbgextio_xmt_cmd
 * @see mbgextio_req_data
 * @see mbgextio_xmt_cmd_us
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_req_data_idx( MBG_MSG_CTL *pmctl, GPS_CMD cmd, uint16_t idx ) ;

 /**
 * @brief Read a receiver info structure
 *
 * The ::RECEIVER_INFO should be read at first to identify the connected
 * device and determine the basic features supported by thr device.
 *
 * @note Some very old devices may not provide a ::RECEIVER_INFO,
 * so mbgextio_setup_receiver_info() should be called preferably
 * to read the receiver info usin this function, if supported,
 * or set up a default structure for devices which don't provide
 * a receiver info.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_setup_receiver_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_receiver_info( MBG_MSG_CTL *pmctl, RECEIVER_INFO *p ) ;

 /**
 * @brief Read a receiver info structure
 *
 * The ::RECEIVER_INFO should be read at first to identify the connected
 * device and determine the basic features supported by thr device.
 *
 * @note Some very old devices may not provide a ::RECEIVER_INFO.
 * This function tries to read the ::RECEIVER_INFO from the device,
 * and sets up a default structure if the device doesn't support this.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_receiver_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_setup_receiver_info( MBG_MSG_CTL *pmctl, RECEIVER_INFO *p ) ;

 /**
 * @brief Read the software revision (obsolete)
 *
 * @note This function is obsolete since the ::SW_REV structure is also
 * a field included in the ::RECEIVER_INFO. This call may be required,
 * though, for very old devices which don't support the ::RECEIVER_INFO.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_setup_receiver_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_sw_rev( MBG_MSG_CTL *pmctl, SW_REV *p ) ;

 /**
 * @brief Read the status of buffered variables
 *
 * @note This function is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_bvar_stat( MBG_MSG_CTL *pmctl, BVAR_STAT *p ) ;

 /**
 * @brief Read the current time as ::TTM strucure
 *
 * @note This function is only supported by GPS receivers.
 *
 * The returned time is not very accurate since the response time
 * transmission delay can't be determmined.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_time( MBG_MSG_CTL *pmctl, TTM *p ) ;

 /**
 * @brief Set the device's time by sending a ::TTM strucure
 *
 * @note The function is not supported by all devices. Time has to be
 * passed as local time according to the device's ::TZDL settings.
 * New time is only set with some tens of ms accuracy.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_time( MBG_MSG_CTL *pmctl, const TTM *p ) ;

 /**
 * @brief Read the current receiver position as ::LLA strucure
 *
 * @note This function is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param lla    Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_pos_lla( MBG_MSG_CTL *pmctl, LLA lla ) ;

 /**
 * @brief Set the device's position by sending an ::LLA strucure
 *
 * @note This function is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param lla    Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_pos_lla( MBG_MSG_CTL *pmctl, const LLA lla ) ;

 /**
 * @brief Read the local time conversion parameters in ::TZDL format
 *
 * @note Some devices may not support ::TZDL settings
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_tzdl( MBG_MSG_CTL *pmctl, TZDL *p ) ;

 /**
 * @brief Set the local time conversion parameters in ::TZDL format
 *
 * @note Some devices may not support ::TZDL settings
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_tzdl( MBG_MSG_CTL *pmctl, const TZDL *p ) ;

 /**
 * @brief Read serial port parameters in ::PORT_PARM format
 *
 * @deprecated This function is deprecated since the ::PORT_PARM structure
 * supports only 2 serial ports, does not not support configuration
 * of a string type. The function mbgextio_get_serial_settings() should
 * be used instead.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_serial_settings
 * @see mbgextio_save_serial_settings
 * @see mbgextio_set_port_parm
 * @see mbgextio_setup_receiver_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_port_parm( MBG_MSG_CTL *pmctl, PORT_PARM *p ) ;

 /**
 * @brief Read the frequency synthesizer settings
 *
 * @note Some devices may not provide a frequency synthesizer
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_synth
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_synth( MBG_MSG_CTL *pmctl, SYNTH *p ) ;

 /**
 * @brief Write the frequency synthesizer settings
 *
 * @note Some devices may not provide a frequency synthesizer
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_synth
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_synth( MBG_MSG_CTL *pmctl, const SYNTH *p ) ;

 /**
 * @brief Read the GPS antenna info structure
 *
 * @note This is only supported by GPS receivers.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_ant_info( MBG_MSG_CTL *pmctl, ANT_INFO *p ) ;

 /**
 * @brief Read a user capture event in ::TTM format
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_clr_ucap_buff
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_ucap( MBG_MSG_CTL *pmctl, TTM *p ) ;

 /**
 * @brief Read the enable flags controlling when output signals are enabled
 *
 * @note Some devices may not support ::ENABLE_FLAGS
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_enable_flags
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_enable_flags( MBG_MSG_CTL *pmctl, ENABLE_FLAGS *p ) ;

 /**
 * @brief Send the enable flags controlling when output signals are enabled
 *
 * @note Some devices may not support ::ENABLE_FLAGS
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_enable_flags
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_enable_flags( MBG_MSG_CTL *pmctl, const ENABLE_FLAGS *p ) ;

 /**
 * @brief Read GPS status info
 *
 * @note This is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_stat_info( MBG_MSG_CTL *pmctl, STAT_INFO *p ) ;

 /**
 * @brief Read the configured length of the GPS antenna cable
 *
 * @note This is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_ant_cable_len
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_ant_cable_len( MBG_MSG_CTL *pmctl, ANT_CABLE_LEN *p ) ;

 /**
 * @brief Send the GPS antenna cable length configuration
 *
 * @note This is only supported by GPS receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_ant_cable_len
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_ant_cable_len( MBG_MSG_CTL *pmctl, const ANT_CABLE_LEN *p ) ;

 /**
 * @brief Read configuration info and supported features for the device's IRIG output
 *
 * @note This is only supported if GPS_HAS_IRIG_TX is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_irig_tx_settings
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_irig_tx_info( MBG_MSG_CTL *pmctl, IRIG_INFO *p ) ;

 /**
 * @brief Send new configuration settings for the device's IRIG output
 *
 * @note This is only supported if GPS_HAS_IRIG_TX is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_irig_tx_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_irig_tx_settings( MBG_MSG_CTL *pmctl, const IRIG_SETTINGS *p ) ;

 /**
 * @brief Read configuration info and supported features for the device's IRIG input
 *
 * @note This is only supported if GPS_HAS_IRIG_RX is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_irig_rx_settings
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_irig_rx_info( MBG_MSG_CTL *pmctl, IRIG_INFO *p ) ;

 /**
 * @brief Send new configuration settings for the device's IRIG input
 *
 * @note This is only supported if GPS_HAS_IRIG_RX is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_irig_rx_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_irig_rx_settings( MBG_MSG_CTL *pmctl, const IRIG_SETTINGS *p ) ;

 /**
 * @brief Read current ref offset to %UTC configuration
 *
 * @note This is only supported if GPS_HAS_REF_OFFS is set in RECEIVER_INFO::features,
 * usually with IRIG receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_ref_offs
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_ref_offs( MBG_MSG_CTL *pmctl, MBG_REF_OFFS *p ) ;

 /**
 * @brief Send new ref offset to %UTC settings
 *
 * @note This is only supported if GPS_HAS_REF_OFFS is set in RECEIVER_INFO::features,
 * usually with IRIG receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_ref_offs
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_ref_offs( MBG_MSG_CTL *pmctl, const MBG_REF_OFFS *p ) ;

 /**
 * @brief Read current debug status
 *
 * @note This is only supported if GPS_HAS_DEBUG_STATUS is set in RECEIVER_INFO::features,
 * usually with IRIG receivers
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_debug_status( MBG_MSG_CTL *pmctl, MBG_DEBUG_STATUS *p ) ;

 /**
 * @brief Read current optional settings and supported options
 *
 * @note This is only supported if GPS_HAS_OPT_SETTINGS is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_opt_settings
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_opt_info( MBG_MSG_CTL *pmctl, MBG_OPT_INFO *p ) ;

 /**
 * @brief Send new optional settings flags
 *
 * @note This is only supported if GPS_HAS_OPT_SETTINGS is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_opt_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_opt_settings( MBG_MSG_CTL *pmctl, const MBG_OPT_SETTINGS *p ) ;

 /**
 * @brief Read information on a specific supported string format
 *
 * Retrieve a single entry from an array of supported string types.
 * The number of supported string types is available in RECEIVER_INFO::n_str_type.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 * @param idx    Index of the array element to be retrieved, 0..RECEIVER_INFO::n_str_type - 1
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_all_str_type_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_str_type_info_idx( MBG_MSG_CTL *pmctl, STR_TYPE_INFO_IDX *p, uint16_t idx ) ;

 /**
 * @brief Read an array of all supported string types
 *
 * The number of supported string types is available in RECEIVER_INFO::n_str_type.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param stii   An array which can hold at least RECEIVER_INFO::n_str_type entries
 * @param p_ri   Pointer to a valid ::RECEIVER_INFO structure
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_str_type_info_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_all_str_type_info( MBG_MSG_CTL *pmctl, STR_TYPE_INFO_IDX stii[], const RECEIVER_INFO *p_ri ) ;

 /**
 * @brief Read current settings and capabilities of a specific serial port
 *
 * The number of serial ports provided by the device is available in RECEIVER_INFO::n_com_ports.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 * @param idx    Index of the array element to be retrieved, 0..RECEIVER_INFO::n_com_ports - 1
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_all_port_info
 * @see mbgextio_set_port_settings_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_port_info_idx( MBG_MSG_CTL *pmctl, PORT_INFO_IDX *p, uint16_t idx ) ;

 /**
 * @brief Read an array of current settings and capabilities of all serial ports
 *
 * The number of serial ports provided by the device is available in RECEIVER_INFO::n_com_ports.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param pii    An array which can hold at least RECEIVER_INFO::n_com_ports entries
 * @param p_ri   Pointer to a valid ::RECEIVER_INFO structure
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_port_info_idx
 * @see mbgextio_set_port_settings_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_all_port_info( MBG_MSG_CTL *pmctl, PORT_INFO_IDX pii[], const RECEIVER_INFO *p_ri ) ;

 /**
 * @brief Send configuration settings for a specific serial port
 *
 * The number of serial ports provided by the device is available in RECEIVER_INFO::n_com_ports.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 * @param idx    Index of the serial port to be configured, 0..RECEIVER_INFO::n_com_ports - 1
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_port_info_idx
 * @see mbgextio_get_all_port_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_port_settings_idx( MBG_MSG_CTL *pmctl, const PORT_SETTINGS *p, uint16_t idx ) ;

 /**
 * @brief Read current settings and capabilities of a specific programmable pulse output
 *
 * The number of supported pulse outputs is available in RECEIVER_INFO::n_prg_out.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 * @param idx    Index of the array element to be retrieved, 0..RECEIVER_INFO::n_prg_out - 1
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_all_pout_info
 * @see mbgextio_set_pout_settings_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_pout_info_idx( MBG_MSG_CTL *pmctl, POUT_INFO_IDX *p, uint16_t idx ) ;

 /**
 * @brief Read an array of current settings and capabilities of all programmable pulse outputs
 *
 * The number of supported pulse outputs is available in RECEIVER_INFO::n_prg_out.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param pii    An array which can hold at least RECEIVER_INFO::n_prg_out entries
 * @param p_ri   Pointer to a valid ::RECEIVER_INFO structure
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_pout_info_idx
 * @see mbgextio_set_pout_settings_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_all_pout_info( MBG_MSG_CTL *pmctl, POUT_INFO_IDX *pii, const RECEIVER_INFO *p_ri ) ;

 /**
 * @brief Send configuration settings for a specific programmable pulse output
 *
 * The number of supported pulse outputs is available in RECEIVER_INFO::n_prg_out.
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 * @param idx    Index of the pulse output to be configured, 0..RECEIVER_INFO::n_prg_out - 1
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_pout_info_idx
 * @see mbgextio_get_all_pout_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_pout_settings_idx( MBG_MSG_CTL *pmctl, const POUT_SETTINGS *p, uint16_t idx ) ;

 /**
 * @brief Clear the user capture event buffer on-board the device
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_ucap
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_clr_ucap_buff( MBG_MSG_CTL *pmctl ) ;

 /**
 * @brief Read time scale configuration parameters
 *
 * @note Some devices may not support a configurable time scale
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_time_scale_settings
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_time_scale_info( MBG_MSG_CTL *pmctl, MBG_TIME_SCALE_INFO *p ) ;

 /**
 * @brief Send new time scale configuration settings
 *
 * @note Some devices may not support a configurable time scale
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_time_scale_info
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_time_scale_settings( MBG_MSG_CTL *pmctl, const MBG_TIME_SCALE_SETTINGS *p ) ;

 /**
 * @brief Clear the on-board event log
 *
 * @note Some devices don't provide an on-board event log
 *
 * @param pmctl  Pointer to a valid message control structure
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_num_evt_log_entries
 * @see mbgextio_get_first_evt_log_entry
 * @see mbgextio_get_next_evt_log_entry
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_clr_evt_log( MBG_MSG_CTL *pmctl ) ;

 /**
 * @brief Read the current number of entries in the on-board event log
 *
 * @note Some devices don't provide an on-board event log
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_clr_evt_log
 * @see mbgextio_get_first_evt_log_entry
 * @see mbgextio_get_next_evt_log_entry
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_num_evt_log_entries( MBG_MSG_CTL *pmctl, MBG_NUM_EVT_LOG_ENTRIES *p ) ;

 /**
 * @brief Return the first entry from the on-board event log
 *
 * This resets an internal counter, so subsequent calls to
 * mbgextio_get_next_evt_log_entry() will retrieve the following entries.
 *
 * @note Some devices don't provide an on-board event log
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_clr_evt_log
 * @see mbgextio_get_num_evt_log_entries
 * @see mbgextio_get_next_evt_log_entry
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_first_evt_log_entry( MBG_MSG_CTL *pmctl, MBG_EVT_LOG_ENTRY *p ) ;

 /**
 * @brief Return the next entry from the on-board event log
 *
 * This increments an internal counter, so subsequent calls will
 * return subsequent entries. mbgextio_get_first_evt_log_entry()
 * should be called first to reset the counter and retrieve the
 * oldest log entry.
 *
 * @note Some devices don't provide an on-board event log
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_clr_evt_log
 * @see mbgextio_get_num_evt_log_entries
 * @see mbgextio_get_first_evt_log_entry
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_next_evt_log_entry( MBG_MSG_CTL *pmctl, MBG_EVT_LOG_ENTRY *p ) ;

 /**
 * @brief Read the current IMS state and supported IMS features
 *
 * @note This is only supported if GPS_HAS_IMS is set in RECEIVER_INFO::features
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_ims_sensor_state_idx
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_ims_state( MBG_MSG_CTL *pmctl, MBG_IMS_STATE *p ) ;

 /**
 * @brief Read sensor values from a specified sensor on the device
 *
 * Info on supported sensors can be retrieved using mbgextio_get_ims_state().
 * Valid range for the sensor index is [0..MBG_IMS_STATE::num_sensors - 1].
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 * @param idx    The index of the array element to read
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_get_ims_state
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_ims_sensor_state_idx( MBG_MSG_CTL *pmctl, MBG_IMS_SENSOR_STATE_IDX *p, uint16_t idx ) ;

 /**
 * @brief Set the XMR holdover interval
 *
 * @todo In which case is this supported?
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_holdover_interval_counter
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_holdover_interval( MBG_MSG_CTL *pmctl, const XMR_HOLDOVER_INTV *p ) ;

 /**
 * @brief Read the XMR holdover interval counter
 *
 * @todo In which case is this supported?
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_holdover_interval
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_holdover_interval_counter( MBG_MSG_CTL *pmctl, XMR_HOLDOVER_INTV *p ) ;

 /**
 * @brief Read the local time conversion configuration ::TZCODE format
 *
 * @note Some devices may not support ::TZCODE configuration
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to return the received data
 *
 * @return  One of the ::TR_STATUS_CODES status codes
 *
 * @see mbgextio_set_tzcode
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_get_tzcode( MBG_MSG_CTL *pmctl, TZCODE *p ) ;

 /**
 * @brief Set the local time conversion configuration in ::TZCODE format
 *
 * @note Some devices may not support ::TZCODE configuration
 *
 * @param pmctl  Pointer to a valid message control structure
 * @param p      Pointer to the data structure to be sent to the device
 *
 * @return  The code returned by mbgextio_xmt_msg
 *
 * @see mbgextio_get_tzcode
 */
 _NO_MBG_API_ATTR int _MBG_API mbgextio_set_tzcode( MBG_MSG_CTL *pmctl, const TZCODE *p ) ;


/* ----- function prototypes end ----- */

#ifdef __cplusplus
}
#endif

#define _mbgextio_xmt_msg( _pmctl, _cmd, _s ) \
  mbgextio_xmt_msg( _pmctl, _cmd, _s, sizeof( *(_s) ) )

/* End of header body */

#undef _ext
#undef _DO_INIT

#endif  /* _MBGEXTIO_H */
