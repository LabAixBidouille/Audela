
/**************************************************************************
 *
 *  $Id: extiohlp.h 1.3 2013/02/01 15:52:16 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Definitions and prototypes for extiohlp.c.
 *
 * -----------------------------------------------------------------------
 *  $Log: extiohlp.h $
 *  Revision 1.3  2013/02/01 15:52:16  martin
 *  Updated function prototypes.
 *  Revision 1.2  2012/03/09 08:35:51Z  martin
 *  Updated function prototypes.
 *  Revision 1.1  2011/09/21 15:59:59  martin
 *  Initial revision.
 *
 **************************************************************************/

#ifndef _EXTIOHLP_H
#define _EXTIOHLP_H


/* Other headers to be included */

#include <mbgextio.h>

#include <cfg_hlp.h>


#ifdef _EXTIOHLP
 #define _ext
 #define _DO_INIT
#else
 #define _ext extern
#endif


/* Start of header body */

#ifdef __cplusplus
extern "C" {
#endif





/* function prototypes: */

/* ----- function prototypes begin ----- */

/* This section was generated automatically */
/* by MAKEHDR, do not remove the comments. */

 /**
 * @brief Read all serial port settings and supported configuration parameters
 *
 * @note The function mbgextio_setup_receiver_info() must have been called before,
 * and the returned ::RECEIVER_INFO has to be passed to this function.
 *
 * The complementary function mbgextio_save_serial_settings() should
 * be used to write a modified port configuration back to the device.
 *
 * @param pmctl   Pointer to a valid message control structure
 * @param *p_cfg  Pointer to a ::RECEIVER_PORT_CFG structure to be set up
 * @param *p_ri   Pointer to a valid ::RECEIVER_INFO structure
 *
 * @return  0 on success, < 0 on error
 *
 * @see mbgextio_save_serial_settings
 * @see mbgextio_get_receiver_info
 */
 int mbgextio_get_serial_settings( MBG_MSG_CTL *pmctl, RECEIVER_PORT_CFG *p_cfg, const RECEIVER_INFO *p_ri ) ;

 /**
 * @brief Send the configuration settings for a single serial port to a device
 *
 * @note The function mbgextio_setup_receiver_info() must have been called before,
 * and the returned ::RECEIVER_INFO has to be passed to this function as well as
 * to mbgextio_get_serial_settings() which should have been called befor to read
 * the current settings and supported features for each port.
 *
 * @param pmctl     Valid pointer to a message control structure
 * @param pcfg      Pointer to a ::RECEIVER_PORT_CFG structure
 * @param port_idx  Index of the serial port to be saved
 *
 * @return ::MBG_SUCCESS or error code returned by device I/O control function.
 *
 * @see mbgextio_get_serial_settings
 * @see mbgextio_get_receiver_info
 */
 int mbgextio_save_serial_settings( MBG_MSG_CTL *pmctl, const RECEIVER_PORT_CFG *pcfg, uint16_t port_idx ) ;


/* ----- function prototypes end ----- */

#ifdef __cplusplus
}
#endif


/* End of header body */

#undef _ext
#undef _DO_INIT

#endif  /* _EXTIOHLP_H */
