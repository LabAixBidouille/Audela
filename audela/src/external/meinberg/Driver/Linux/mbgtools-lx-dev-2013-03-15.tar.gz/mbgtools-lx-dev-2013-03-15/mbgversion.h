
/**************************************************************************
 *
 *  $Id: mbgversion.h 1.3 2013/01/03 12:09:30 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Program version definitions for package mbgtools-lx.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgversion.h $
 *  Revision 1.3  2013/01/03 12:09:30  martin
 *  Changed copyright year to 2013.
 *  Revision 1.2  2012/01/17 10:10:54  martin
 *  Changed current copyright year to 2012.
 *  Revision 1.1  2011/07/08 11:38:32  martin
 *  Initial revision for pre-release.
 *
 **************************************************************************/

#define MBG_CURRENT_COPYRIGHT_YEAR      2013
#define MBG_CURRENT_COPYRIGHT_YEAR_STR  "2013"

#define MBG_MAJOR_VERSION_CODE          3
#define MBG_MINOR_VERSION_CODE          4

#define MBG_MAIN_VERSION_STR            "3.4"

// The codes below should only fe defined in development/pre-release versions
#define MBG_MICRO_VERSION_CODE_DEV      99
#define MBG_MICRO_VERSION_STR_DEV       "99"


#define MBG_MAIN_VERSION_CODE           ( ( MBG_MAJOR_VERSION_CODE << 8 ) | MBG_MINOR_VERSION_CODE )

#define MBG_VERSION_CODE( _micro )      ( (uint16_t) ( ( MBG_MAIN_VERSION_CODE << 8 ) | (_micro) ) )
