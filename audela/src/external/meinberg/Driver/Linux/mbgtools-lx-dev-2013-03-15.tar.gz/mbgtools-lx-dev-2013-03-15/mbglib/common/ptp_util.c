
/**************************************************************************
 *
 *  $Id: ptp_util.c 1.1 2011/11/14 16:03:39 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    PTP utility functions.
 *
 * -----------------------------------------------------------------------
 *  $Log: ptp_util.c $
 *  Revision 1.1  2011/11/14 16:03:39  martin
 *  Initial revision.
 *
 **************************************************************************/

#define _PTP_UTIL
  #include <ptp_util.h>
#undef _PTP_UTIL


/*HDR*/
/**
 * @brief Get the MAC addr from a PTP clock ID
 *
 * The clock ID is usually the MAC ID with 2 octets
 * 0xFF and 0xFE inserted in the middle.
 *
 * @param p_mac_addr  The MAC ID to be filled up
 * @param p_clock_id  The PTP clock ID
 */
void mac_from_ptp_clock_id( MBG_MAC_ADDR *p_mac_addr,
                            const PTP_CLOCK_ID *p_clock_id )
{
  const uint8_t *srcp = p_clock_id->b;
  uint8_t *dstp = p_mac_addr->b;
  int i;

  for ( i = 0; i < sizeof( *p_mac_addr ); i++ )
  {
    if ( i == 3 )
      srcp += 2;  // skip 0xFF/0xFE octets

    *dstp = *srcp;
    dstp++;
    srcp++;
  }

}  // mac_from_ptp_clock_id



/*HDR*/
/**
 * @brief Get the PTP clock ID from the MAC addr
 *
 * The clock ID is usually the MAC ID with 2 octets
 * 0xFF and 0xFE inserted in the middle.
 *
 * @param p_clock_id  The PTP clock ID
 * @param p_mac_addr  The MAC ID to be filled up
 */
void ptp_clock_id_from_mac( PTP_CLOCK_ID *p_clock_id,
                            const MBG_MAC_ADDR *p_mac_addr )
{
  const uint8_t *srcp = p_mac_addr->b;
  uint8_t *dstp = p_clock_id->b;
  int i;

  for ( i = 0; i < sizeof( *p_clock_id ); i++ )
  {
    if ( i == 3 )  // insert 0xFF/0xFE octets
    {
      *dstp++ = 0xFF;
      *dstp++ = 0xFE;
    }

    *dstp = *srcp;
    dstp++;
    srcp++;
  }

}  // ptp_clock_id_from_mac



