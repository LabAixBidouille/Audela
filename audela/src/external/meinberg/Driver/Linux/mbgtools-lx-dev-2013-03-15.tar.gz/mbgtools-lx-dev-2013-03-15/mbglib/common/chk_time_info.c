
/**************************************************************************
 *
 *  $Id: chk_time_info.c 1.2 2013/03/04 16:01:01 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    NTP shared memory support functions.
 *
 * -----------------------------------------------------------------------
 *  $Log: chk_time_info.c $
 *  Revision 1.2  2013/03/04 16:01:01  martin
 *  Use common function setup_hr_time_cycles_from_timestamp_cycles().
 *  Made snprint_chk_time_info() more flexible.
 *  Revision 1.1  2012/05/29 09:52:26  martin
 *  Initial revision.
 *
 **************************************************************************/

#define _CHK_TIME_INFO
  #include <chk_time_info.h>
#undef _CHK_TIME_INFO

#include <toolutil.h>
#include <stdio.h>


//##++++++
extern MBG_PC_CYCLES_FREQUENCY cyc_freq;


static /*HDR*/
MBG_PC_CYCLES do_filter( FILTER *p, MBG_PC_CYCLES cyc )
{
  if ( p->entries < MAX_FILTER_ENTRIES )
    p->entries++;

  if ( ++( p->index ) >= MAX_FILTER_ENTRIES )
    p->index = 0;

  // update the sum of filter entries
  p->sum -= p->cyc[p->index];   // subtract oldest sample
  p->cyc[p->index] = cyc;       // save new sample
  p->sum += cyc;                // add new sample

  return p->sum / p->entries;   // return mean value

}  /* do_filter */



/*HDR*/
int mbg_chk_time_info( MBG_DEV_HANDLE dh, MBG_CHK_TIME_INFO *p, FILTER *p_filter, int fast_ts_only )
{
  MBG_PC_CYCLES tmp;
  PCPS_TIME_STAMP *p_ref_ts;
  MBG_PC_CYCLES *p_ref_cyc;
  MBG_SYS_TIME_CYCLES *p_sys_tic;
  int rc;

  memset( p, 0, sizeof( *p ) );

  if ( fast_ts_only )
  {
    MBG_TIME_INFO_TSTAMP tsi;

    rc = mbg_get_time_info_tstamp( dh, &tsi );
    setup_hr_time_cycles_from_timestamp_cycles( &p->hrti.ref_hr_time_cycles, &tsi.ref_tstamp_cycles );
    p->hrti.sys_time_cycles = tsi.sys_time_cycles;
  }
  else
    rc = mbg_get_time_info_hrt( dh, &p->hrti );

  if ( rc < 0 )
    return rc;


  p_ref_ts = &p->hrti.ref_hr_time_cycles.t.tstamp;
  p_ref_cyc = &p->hrti.ref_hr_time_cycles.cycles;
  p_sys_tic = &p->hrti.sys_time_cycles;

  p->d_ref = (double) p_ref_ts->sec + ( (double) p_ref_ts->frac ) / (double) PCPS_HRT_BIN_FRAC_SCALE;
  p->d_sys = (double) p_sys_tic->sys_time.sec + (double) p_sys_tic->sys_time.nsec / 1e9;

  p->ltcy_cyc = mbg_delta_pc_cycles( p_ref_cyc, &p_sys_tic->cyc_after );
  p->exec_cyc = mbg_delta_pc_cycles( &p_sys_tic->cyc_after, &p_sys_tic->cyc_before );
  p->exec_cyc_limit = p_filter ? do_filter( p_filter, p->exec_cyc ) : 0;

  if ( cyc_freq )
  {
    p->ltcy_sec = ( (double) p->ltcy_cyc ) / (double) cyc_freq;
    p->exec_sec = ( (double) p->exec_cyc ) / (double) cyc_freq;
    p->exec_sec_limit = ( (double) p->exec_cyc_limit ) / (double) cyc_freq;
  }

  // Compensate latencies between time stamps ->
  // normalize ref time to system time stamp
  p->d_ref_comp = p->d_ref - p->ltcy_sec;

  // Try to set the limit to 1.7 of the mean execution cycles.
  tmp = ( 7 * p->exec_cyc_limit ) / 10;

  // If execution takes only a few cycles make sure the limit
  // is above the mean number of cycles.
  if ( tmp == 0 )
    tmp++;

  p->exec_cyc_limit += tmp;

  return MBG_SUCCESS;

}  // mbg_chk_time_info



/*HDR*/
int snprint_chk_time_info( char *s, size_t max_len, const MBG_CHK_TIME_INFO *p, const PCPS_DEV *p_dev,
                           int frac_digits, int print_raw )
{
  size_t n = 0;

  if ( p_dev )
    n += snprintf( &s[n], max_len - n, "%-9s: ", _pcps_type_name( p_dev ) );

  n += mbg_snprint_hr_tstamp( &s[n], max_len - n, &p->hrti.ref_hr_time_cycles.t.tstamp, 0 );  // raw timestamp?

  n += snprintf( &s[n], max_len - n, ": %.*f-%.*f: ",
                 frac_digits, p->d_ref,
                 frac_digits, p->d_sys );

  if ( print_raw )
    n += snprintf( &s[n], max_len - n, "%+.*f->",
                   frac_digits, p->d_ref - p->d_sys );

  n += snprintf( &s[n], max_len - n, "%+.*f, ltcy: ",
                 frac_digits, p->d_ref_comp - p->d_sys );


  if ( cyc_freq )  // print latency and execution time in microseconds
  {
      n += snprintf( &s[n], max_len - n, "%.2f us, exec: %.2f us, limit: %.2f us",
                     p->ltcy_sec * 1e6, p->exec_sec * 1e6, p->exec_sec_limit * 1e6 );
  }
  else  // print latency and execution time in cycles only
  {
    n += snprintf( &s[n], max_len - n, "%lli cyc, exec: %lli cyc, limit: %lli cyc",
                   (long long) p->ltcy_cyc, (long long) p->exec_cyc,
                   (long long) p->exec_cyc_limit );
  }

  return n;

}  // snprint_chk_time_info

