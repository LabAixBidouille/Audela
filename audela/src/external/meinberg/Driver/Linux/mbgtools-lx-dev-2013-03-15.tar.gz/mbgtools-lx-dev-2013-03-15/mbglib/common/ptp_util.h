
/**************************************************************************
 *
 *  $Id: ptp_util.h 1.1 2011/11/14 16:03:39 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Definitions and prototypes for ptp_util.c.
 *
 * -----------------------------------------------------------------------
 *  $Log: ptp_util.h $
 *  Revision 1.1  2011/11/14 16:03:39  martin
 *  Initial revision.
 *
 **************************************************************************/

#ifndef _PTP_UTIL_H
#define _PTP_UTIL_H


/* Other headers to be included */

#include <lan_util.h>
#include <gpsdefs.h>


#ifdef _PTP_UTIL
 #define _ext
 #define _DO_INIT
#else
 #define _ext extern
#endif


/* Start of header body */

#if defined( _USE_PACK )
  #pragma pack( 1 )      // set byte alignment
  #define _USING_BYTE_ALIGNMENT
#endif

#ifdef __cplusplus
extern "C" {
#endif


/* function prototypes: */

/* ----- function prototypes begin ----- */

/* This section was generated automatically */
/* by MAKEHDR, do not remove the comments. */

 /**
 * @brief Get the MAC addr from a PTP clock ID
 *
 * The clock ID is usually the MAC ID with 2 octets
 * 0xFF and 0xFE inserted in the middle.
 *
 * @param p_mac_addr  The MAC ID to be filled up
 * @param p_clock_id  The PTP clock ID
 */
 void mac_from_ptp_clock_id( MBG_MAC_ADDR *p_mac_addr, const PTP_CLOCK_ID *p_clock_id ) ;

 /**
 * @brief Get the PTP clock ID from the MAC addr
 *
 * The clock ID is usually the MAC ID with 2 octets
 * 0xFF and 0xFE inserted in the middle.
 *
 * @param p_clock_id  The PTP clock ID
 * @param p_mac_addr  The MAC ID to be filled up
 */
 void ptp_clock_id_from_mac( PTP_CLOCK_ID *p_clock_id, const MBG_MAC_ADDR *p_mac_addr ) ;


/* ----- function prototypes end ----- */

#ifdef __cplusplus
}
#endif


#if defined( _USING_BYTE_ALIGNMENT )
  #pragma pack()      // set default alignment
  #undef _USING_BYTE_ALIGNMENT
#endif

/* End of header body */


#undef _ext
#undef _DO_INIT

#endif  /* _PTP_UTIL_H */

