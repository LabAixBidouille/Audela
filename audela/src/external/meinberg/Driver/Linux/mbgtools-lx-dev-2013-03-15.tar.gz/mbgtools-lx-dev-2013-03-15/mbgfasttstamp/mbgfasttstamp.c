
/**************************************************************************
 *
 *  $Id: mbgfasttstamp.c 1.6.1.7 2013/01/24 14:39:33 martin TEST $
 *
 *  Description:
 *    Main file for mbgfasttstamp program which demonstrates how to access
 *    a Meinberg device via memory mapped I/O, if supported by the device.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgfasttstamp.c $
 *  Revision 1.6.1.7  2013/01/24 14:39:33  martin
 *  Revision 1.6.1.6  2012/06/01 18:46:52  martin
 *  Added option to sleep between calls.
 *  Revision 1.6.1.5  2011/12/19 16:09:17  martin
 *  Revision 1.6.1.4  2011/09/26 16:00:51  martin
 *  Modified program version handling.
 *  Account for modified library functions which can now
 *  optionally print the raw (hex) HR time stamp.
 *  Started to support signal handler to catch CTRL-C.
 *  Revision 1.6.1.3  2011/01/28 12:04:07  martin
 *  Revision 1.6.1.2  2011/01/28 11:51:13  martin
 *  Revision 1.6.1.1  2011/01/28 11:17:00  martin
 *  Abort if MM access not supported on the target OS.
 *  Revision 1.6  2010/05/21 12:54:33  martin
 *  Print warning if no cycles supported on the target platform
 *  and thus latencies can not be computed.
 *  Revision 1.5  2009/09/29 15:02:14  martin
 *  Updated version number to 3.4.0.
 *  Revision 1.4  2009/07/24 09:50:08  martin
 *  Updated version number to 3.3.0.
 *  Revision 1.3  2009/06/19 14:01:32  martin
 *  Made print_hr_timestamp() to toolutil.c as mbg_print_hr_timestamp().
 *  Updated version number to 3.2.0.
 *  Revision 1.2  2009/03/20 11:48:19  martin
 *  Updated version number to 3.1.0.
 *  Updated copyright year to include 2009.
 *  New parameter -r lets the program read raw timestamps
 *  using the new API call mbg_get_fast_hr_timestamp().
 *  Revision 1.1  2008/12/22 11:45:01  martin
 *  Initial revision.
 *  Revision 1.1  2008/12/22 11:05:24  martin
 *  Initial revision.
 *
 **************************************************************************/

// include Meinberg headers
#include <mbgdevio.h>
#include <pcpsutil.h>
#include <toolutil.h>  // common utility functions

// include system headers
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


#define MBG_MICRO_VERSION          0
#define MBG_FIRST_COPYRIGHT_YEAR   2007
#define MBG_LAST_COPYRIGHT_YEAR    0     // use default

static const char *pname = "mbgfasttstamp";


#define MAX_TS_BURST  1000

static int loops;
static int burst_read;
static int read_raw;
static long sleep_secs;
static long sleep_usecs;



// The function below reads a number of time stamps and prints
// each timestamp immediately. This is not as fast as possible
// since printing the time stamp takes some time to execute.
// However, this can run continuously forever.

static /*HDR*/
int show_fast_hr_timestamp( MBG_DEV_HANDLE dh )
{
  int this_loops = loops;
  PCPS_TIME_STAMP ts;
  int32_t hns_latency = 0;

  for (;;)
  {
    int rc = read_raw ? mbg_get_fast_hr_timestamp( dh, &ts ) :
             mbg_get_fast_hr_timestamp_comp( dh, &ts, &hns_latency );

    if ( mbg_ioctl_err( rc, "mbg_get_fast_hr_timestamp..." ) )
      goto fail;

    mbg_print_hr_timestamp( &ts, hns_latency, NULL, read_raw, 1 );  // raw timestamp?

    if ( this_loops > 0 )
      this_loops--;

    if ( this_loops == 0 )
      break;

    if ( sleep_secs )
      sleep( sleep_secs );
    else
      if ( sleep_usecs )
        usleep( sleep_usecs );

    // if this_loops is < 0 then loop forever
  }

  return 0;

fail:
  return -1;

}  // show_fast_hr_timestamp



// The function below takes a number of time stamps and saves
// them to a buffer. After the time stamps have been read
// a second loop prints the time stamps from the buffer.
// This way the time stamps are read in shorter intervals.
// However, this can not run continuously forever since
// the buffer size is somewhat limited.

static /*HDR*/
int show_fast_hr_timestamp_burst( MBG_DEV_HANDLE dh )
{
  PCPS_TIME_STAMP ts[MAX_TS_BURST];
  int32_t hns_latency[MAX_TS_BURST];
  int this_loops;
  int i;

  this_loops = ( loops && ( loops < MAX_TS_BURST ) ) ? loops : MAX_TS_BURST;


  if ( read_raw )
  {
    for ( i = 0; i < this_loops; i++ )
    {
      int rc = mbg_get_fast_hr_timestamp( dh, &ts[i] );

      if ( mbg_ioctl_err( rc, "mbg_get_fast_hr_timestamp" ) )
        goto fail;
    }
  }
  else
    for ( i = 0; i < this_loops; i++ )
    {
      int rc = mbg_get_fast_hr_timestamp_comp( dh, &ts[i], &hns_latency[i] );

      if ( mbg_ioctl_err( rc, "mbg_get_fast_hr_timestamp_comp" ) )
        goto fail;
    }

  for ( i = 0; i < this_loops; i++ )
  {
    PCPS_TIME_STAMP *p_prv_ts = i ? &ts[i - 1] : NULL;
    mbg_print_hr_timestamp( &ts[i], hns_latency[i], p_prv_ts, read_raw, 0 );  // raw timestamp?
  }

  return 0;


fail:
  return -1;

}  // show_fast_hr_timestamp_burst



static /*HDR*/
int do_mbgfasttstamp( MBG_DEV_HANDLE dh, const PCPS_DEV *p_dev )
{
  int supported = 0;
  int rc = mbg_dev_has_fast_hr_timestamp( dh, &supported );

  if ( mbg_ioctl_err( rc, "mbg_has_fast_hr_timestamp" ) )
    goto done;

  if ( !supported )
  {
    printf( "This device does not support fast (memory mapped) time stamps.\n" );
    goto done;
  }

  if ( burst_read )
    show_fast_hr_timestamp_burst( dh );
  else
    show_fast_hr_timestamp( dh );

done:
  mbg_close_device( &dh );

  return rc;

}  // do_mbgfasttstamp



static /*HDR*/
void usage( void )
{
  mbg_print_usage_intro( pname,
    "This example program reads fast high resolution time stamps.\n"
    "\n"
    "This is done using memory mapped I/O in the kernel driver, so\n"
    "this works only with cards which support memory mapped I/O."
  );
  mbg_print_help_options();
  mbg_print_opt_info( "-c", "run continuously" );
  mbg_print_opt_info( "-n num", "run num loops" );
  mbg_print_opt_info( "-b", "burst read" );
  mbg_print_opt_info( "-r", "read raw time stamps, no cycles" );
  mbg_print_opt_info( "-s num", "sleep num seconds between calls" );
  mbg_print_opt_info( "-u num", "sleep num microseconds between calls" );
  mbg_print_device_options();
  puts( "" );

}  // usage



int main( int argc, char *argv[] )
{
  int rc;
  int c;

  mbg_print_program_info( pname, MBG_MICRO_VERSION, MBG_FIRST_COPYRIGHT_YEAR, MBG_LAST_COPYRIGHT_YEAR );

  // check command line parameters
  while ( ( c = getopt( argc, argv, "bcn:rs:u:h?" ) ) != -1 )
  {
    switch ( c )
    {
      case 'b':
        burst_read = 1;
        break;

      case 'c':
        loops = -1;
        break;

      case 'n':
        loops = atoi( optarg );
        break;

      case 'r':
        read_raw = 1;
        break;

      case 's':
        sleep_secs = atoi( optarg );
        break;

      case 'u':
        sleep_usecs = atoi( optarg );
        break;

      case 'h':
      case '?':
      default:
        must_print_usage = 1;
    }
  }

  if ( must_print_usage )
  {
    usage();
    return 1;
  }

  #if !MBG_TGT_SUPP_MEM_ACC
    printf( "** Memory mapped access not supported on this target platform.\n\n" );
    return 1;
  #endif

  #if !MBG_PC_CYCLES_SUPPORTED
    printf( "** Warning: No cycles support to compute real latencies on this platform!\n" );

    if ( !read_raw )
    {
      read_raw = 1;
      printf( "** Falling back to raw mode.\n" );
    }

    printf( "\n" );
  #endif

  // The function below checks which devices have been specified
  // on the command, and for each device
  // - tries to open the device
  // - shows basic device info
  // - calls the function passed as last parameter
  rc = mbg_check_devices( argc, argv, optind, do_mbgfasttstamp );

  return abs( rc );
}
