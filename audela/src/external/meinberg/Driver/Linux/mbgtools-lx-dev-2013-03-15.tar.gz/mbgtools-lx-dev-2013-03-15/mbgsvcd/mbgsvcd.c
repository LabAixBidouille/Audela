
/**************************************************************************
 *
 *  $Id: mbgsvcd.c 1.3.1.15.1.3 2013/01/24 14:41:53 martin TEST martin $
 *
 *  Description:
 *    Main file for mbgsvcd which compares the system time to a PCI card's 
 *    time and transfers this data pair to the SHM driver of the ntpd.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgsvcd.c $
 *  Revision 1.3.1.15.1.3  2013/01/24 14:41:53  martin
 *  Revision 1.3.1.15.1.2  2013/01/02 10:24:47  daniel
 *  preliminary support for nsec
 *  Revision 1.3.1.15.1.1  2012/06/02 10:18:40  martin
 *  Tmp. code to print leap second status.
 *  Revision 1.3.1.15  2012/05/24 12:46:23  martin
 *  Moved some code to some extra modules which can be shared.
 *  Revision 1.3.1.14  2011/11/17 10:07:08  martin
 *  Added leap second support.
 *  Revision 1.3.1.13  2011/10/06 13:03:46  martin
 *  Combined printf() and syslog() to mbg_log().
 *  Cleanup.
 *  Revision 1.3.1.12  2011/10/05 15:11:50  martin
 *  Log reasons for error if function calls fail.
 *  Revision 1.3.1.11  2011/09/07 15:08:56  martin
 *  Account for modified library functions which can now
 *  optionally print the raw (hex) HR time stamp.
 *  Revision 1.3.1.10  2011/07/14 13:30:57  martin
 *  Code cleanup.
 *  Eliminated some potential warnings due to ignored function return values.
 *  Revision 1.3.1.9  2011/07/05 15:35:55  martin
 *  Modified version handling.
 *  Revision 1.3.1.8  2011/07/05 14:35:19  martin
 *  New way to maintain version information.
 *  Revision 1.3.1.7  2011/06/23 15:35:40  martin
 *  Skip devices which don't support HR time immediately at startup.
 *  Revision 1.3.1.6  2011/06/23 15:02:55  martin
 *  Compute execution time limit in cycles instead of us so this can also
 *  be done if the cycle counter clock rate can not be determined.
 *  Revision 1.3.1.5  2011/06/23 12:45:37  martin
 *  Workaround in case cycle frequency can not be determined.
 *  Revision 1.3.1.4  2011/06/20 15:10:22  martin
 *  Using generic MBG_SYS_TIME with nanosecond resolution.
 *  Revision 1.3.1.3  2011/03/25 11:05:24  martin
 *  Optionally support timespec for sys time.
 *  Cleanup.
 *  Revision 1.3.1.2  2011/03/23 16:30:40  martin
 *  Use /var/run as directory for the lockfile.
 *  Revision 1.3.1.1  2010/04/26 14:37:41  martin
 *  Print PC cycles counter frequency at program start.
 *  Revision 1.3  2010/03/03 14:59:36  martin
 *  Support -p parameter to pretend sync.
 *  Revision 1.2  2010/02/03 16:15:09  daniel
 *  Revision 1.1  2010/02/03 16:07:18  daniel
 *
 **************************************************************************/

// include Meinberg headers
#include <mbgdevio.h>
#include <pcpsutil.h>
#include <toolutil.h>  // common utility functions
#include <pcpsmktm.h>
#include <chk_time_info.h>
#include <ntp_shm.h>

// include system headers
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h> 
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <syslog.h>
#include <stdarg.h>


#include <sys/ipc.h>
#include <sys/shm.h>

#define RUNNING_DIR                "/var/run"
#define LOCK_FILE                  "mbgsvcd.pid"

#define MBG_MICRO_VERSION          0
#define MBG_FIRST_COPYRIGHT_YEAR   2010
#define MBG_LAST_COPYRIGHT_YEAR    0      // use default

static const char *pname = "mbgsvcd";

static int sleep_intv = 1;
static int pretend_sync;
static int frac_digits = 9;
static int print_raw;

MBG_PC_CYCLES_FREQUENCY cyc_freq;



static struct shmTime *shmTime[MAX_SHM_REFCLOCKS];
static FILTER filter;  //##++++ [MAX_SHM_REFCLOCKS] ?



/*HDR*/
void mbg_log( int lvl, const char *fmt, ... )
{
  char ws[256];
  va_list ap;

  va_start( ap, fmt );
  vsnprintf( ws, sizeof( ws ), fmt, ap );
  va_end( ap );

  syslog( lvl, ws );
  fprintf( stdout, "%s\n", ws );

}  // mbg_log



static /*HDR*/
int do_mbgsvctasks( void )
{
  char ws[256];
  int rc = 0;
  int n_devices_found;
  int n_devices;
  MBG_DEV_HANDLE dhs[MAX_SHM_REFCLOCKS];
  PCPS_DEV devs[MAX_SHM_REFCLOCKS];
  int i;

  n_devices_found = mbg_find_devices();

  for ( i = 0, n_devices = 0; i < n_devices_found; i++ )
  {
    MBG_DEV_HANDLE dh = mbg_open_device( i );
    PCPS_DEV dev_info;

    rc = mbg_get_device_info( dh, &dev_info );

    if ( rc < 0 )
    {
      mbg_log( LOG_WARNING, "Failed to read device info from device #%i.", i );
      mbg_close_device( &dh );
      continue;
    }

    if ( !_pcps_has_hr_time( &dev_info ) )
    {
      mbg_log( LOG_WARNING, "Device %s does not support HR time stamps.",
               _pcps_type_name( &dev_info ) );
      mbg_close_device( &dh );
      continue;
    }

    dhs[n_devices] = dh;
    devs[n_devices] = dev_info;

    if ( ++n_devices >= MAX_SHM_REFCLOCKS )
      break;
  }

  if ( n_devices == 0 )
  {
    mbg_log( LOG_WARNING, "No usable device found!" );
    goto done;
  }


  // Search for devices up to the maximum of supported number of NTP SHM refclocks
  if ( n_devices > MAX_SHM_REFCLOCKS )
    n_devices = MAX_SHM_REFCLOCKS;

  mbg_log( LOG_INFO, "Found %d devices usable for the NTP daemon", n_devices );  //##++++

  rc = mbg_get_default_cycles_frequency_from_dev( dhs[0], &cyc_freq );

  if ( mbg_ioctl_err( rc, "mbg_get_default_cycles_frequency_from_dev" ) )
    goto done;


  mbg_log( LOG_INFO, "%sPC cycles counter clock frequency: %Lu Hz",
           ( cyc_freq == 0 ) ? "*** Warning: " : "",
           (unsigned long long) cyc_freq );

  // Initialize NTP shared memory area
  ntpshm_init( shmTime, n_devices );

  for (;;)
  {
    for ( i = 0; i < n_devices; i++ )
    {
      MBG_CHK_TIME_INFO cti;
      const char *cp;
      int leap;

      rc = mbg_chk_time_info( dhs[i], &cti, &filter, 0 );   //##+++++ one or more filter instances ?

      if ( mbg_ioctl_err( rc, "mbg_chk_time_info" ) )
        continue;


      cp = "";
      leap = 0;

      // check if refclock is sync and if exec time of the system time call was fast enough
      if ( ( cti.exec_cyc <= cti.exec_cyc_limit ) && ( pretend_sync || (
           ( ( cti.hrti.ref_hr_time_cycles.t.status & PCPS_FREER ) == 0 ) &&
           ( ( cti.hrti.ref_hr_time_cycles.t.status & PCPS_SYNCD ) != 0 ) ) ) )
      {
        struct shmTime *p = shmTime[i];

        if ( p )
        {
          MBG_SYS_TIME_CYCLES *p_sys_tic = &cti.hrti.sys_time_cycles;
          cp = " *";

          // fill SHM structure
          p->count++;
          p->clockTimeStampSec = (time_t) cti.d_ref_comp;
          p->clockTimeStampUSec = (int) ( ( cti.d_ref_comp - p->clockTimeStampSec ) * 1e6 ); // get µs from d_ref
          p->receiveTimeStampSec = (time_t) p_sys_tic->sys_time.sec;
          p->receiveTimeStampUSec = (int) ( p_sys_tic->sys_time.nsec / 1000 );

          // These fields are only supported by newer versions of ntpd //##++++++++++++++++++ which versions ?
          p->clockTimeStampNSec = (int) ( ( cti.d_ref_comp - p->clockTimeStampSec ) * 1e9 ); // get ns from d_ref
          p->receiveTimeStampNSec = (int) ( p_sys_tic->sys_time.nsec );

          // patch precision value according to the ref time accuracy
          if ( _pcps_is_lwr( &devs[i] ) )
            p->precision = -8;
          else
          {
            if ( _pcps_is_irig_rx( &devs[i] ) )
            {
              if ( _pcps_is_usb( &devs[i] ) )
                p->precision = -10;
              else
                p->precision = -18;
            }
            else
              p->precision = -20;
          }

          if ( cti.hrti.ref_hr_time_cycles.t.status & PCPS_LS_ANN_NEG )
            p->leap = LEAP_DELSECOND;
          else
            if ( cti.hrti.ref_hr_time_cycles.t.status & PCPS_LS_ANN )
              p->leap = LEAP_ADDSECOND;
            else
              p->leap = LEAP_NOWARNING;

          leap = p->leap;  //##+++

          p->count++;
          p->valid = 1;
        }
      }

      snprint_chk_time_info( ws, sizeof( ws ), &cti, &devs[i], frac_digits, print_raw );
      printf( "%s, leap: %02X%s\n", ws, leap, cp );

      usleep( 10 );
    }

    if ( n_devices > 1 )
      printf( "\n" );

    if ( sleep_intv )
      sleep( sleep_intv );
  }

done:
  for ( i = 0; i < n_devices; i++ )
    mbg_close_device( &dhs[i] );

  return rc;

}  // do_mbgsvctasks



static /*HDR*/
void usage( void )
{
  mbg_print_usage_intro( pname,
    "This program periodically reads a reference time stamp and an associated\n"
    "system time stamp from every mbgclock device, and feeds the time stamp pairs\n"
    "to the NTP daemon's shared memory refclock driver.\n"
    "It usually runs as daemon but can also be run in the foreground to monitor the\n"
    "time stamps and offsets.\n"
    "This works only for cards supporting high resolution time stamps.\n"
  );
  mbg_print_help_options();
  mbg_print_opt_info( "-f", "run program in foreground" );
  mbg_print_opt_info( "-s num", "sleep num seconds between calls" );
  mbg_print_opt_info( "-p", "pretend device is always synchronized" );
  mbg_print_device_options();
  puts( "" );

}  // usage



static /*HDR*/
void startup_daemon( void )
{
  int i;
  int lfp;
  int rc;
  char str[1024];

  if ( getppid() == 1 )
    return; /* already a daemon */

  mbg_log( LOG_INFO, "Daemon mode, backgrounding" );
  i = fork();

  if ( i < 0 )
    exit( 1 );  /* fork error */

  if ( i > 0 )
    exit( 0 );  /* parent exits */


  /* child (daemon) continues */
  setsid(); /* obtain a new process group */

  for ( i = getdtablesize(); i >= 0; --i )
    close( i ); /* close all descriptors */

  /* handle standard I/O */
  i = open( "/dev/null", O_RDWR );
  rc = dup( i );
  rc = dup( i );

  umask( 027 );  /* set newly created file permissions */
  rc = chdir( RUNNING_DIR ); /* change running directory */

  lfp = open( LOCK_FILE, O_RDWR | O_CREAT, 0640 );

  if ( lfp < 0 )
    exit( 1 );  /* unable to open lock file */

  if ( lockf( lfp, F_TLOCK, 0 ) < 0 ) 
  {
    mbg_log( LOG_ERR, "Lock file already exists, another instance of this daemon seems to be running" );
    closelog();
    exit( 0 );  /* can not lock */
  }

  /* first instance continues */
  snprintf( str, sizeof( str ), "%d\n", getpid() );
  rc = write( lfp, str, strlen( str ) );  /* record pid to lockfile */

  signal( SIGCHLD, SIG_IGN ); /* ignore child */
  signal( SIGTSTP, SIG_IGN ); /* ignore tty signals */
  signal( SIGTTOU, SIG_IGN );
  signal( SIGTTIN, SIG_IGN );

}  // startup_daemon



int main( int argc, char *argv[] )
{
  int rc;
  int c;
  int foreground = 0;

  mbg_print_program_info( pname, MBG_MICRO_VERSION, MBG_FIRST_COPYRIGHT_YEAR, MBG_LAST_COPYRIGHT_YEAR );

  // check command line parameters
  while ( ( c = getopt( argc, argv, "fps:h?" ) ) != -1 )
  {
    switch ( c )
    {
      case 'f':
        foreground = 1;
        break;

      case 'p':
        pretend_sync = 1;
        break;

      case 's':
        sleep_intv = atoi( optarg );
        break;

      case 'h':
      case '?':
      default:
        must_print_usage = 1;
    }
  }

  if ( must_print_usage )
  {
    usage();
    return 1;
  }

  if ( foreground == 0 )
  {
    char ws[256];

    mbg_program_info_str( ws, sizeof( ws ), pname, MBG_MICRO_VERSION,
                          MBG_FIRST_COPYRIGHT_YEAR, MBG_LAST_COPYRIGHT_YEAR );

    mbg_log( LOG_INFO, "Starting Meinberg Service Daemon %s", ws );

    startup_daemon();
  }

  rc = do_mbgsvctasks();

  return abs( rc );
}
