
/**************************************************************************
 *
 *  $Id: mbgclock_main.c 1.25.1.30 2013/01/02 16:22:20 martin TEST martin $
 *
 *  Description:
 *    Main file for the mbgclock driver for Linux which allows access to
 *    Meinberg radio clock devices from user space.
 *
 *    The binary is a loadable module called mbgclock which implements
 *    /dev/mbgclock* devices.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgclock_main.c $
 *  Revision 1.25.1.30  2013/01/02 16:22:20  martin
 *  Use common code from lx-shared.h.
 *  Revision 1.25.1.29  2012/12/19 16:49:28  martin
 *  Moved kernelk version compatibility checks to mbg_lx.h.
 *  Revision 1.25.1.28  2012/09/06 08:42:46  martin
 *  Print return code if request_irq() fails.
 *  Added some example code to list IRQs supported by the kernel.
 *  Revision 1.25.1.27  2011/12/14 14:12:23  martin
 *  This is a test
 *  Revision 1.25.1.26  2011/11/23 17:40:33  martin
 *  Print IOCTL code names in debug messages.
 *  Revision 1.25.1.25  2011/11/16 10:26:50  martin
 *  Check all PCI base address registers and don't stop if one register is 0.
 *  Revision 1.25.1.24  2011/10/28 13:45:59  martin
 *  Revision 1.25.1.23  2011/09/12 12:32:14  martin
 *  Revision 1.25.1.22  2011/09/12 08:38:10  martin
 *  Removed obsolete definition of K26, and cleaned up.
 *  Revision 1.25.1.21  2011/09/09 13:52:46  martin
 *  Enhanced IRQ timing debug code.
 *  Read jiffies at IRQ protected by a lock.
 *  Revision 1.25.1.20  2011/08/18 08:53:46  martin
 *  Revision 1.25.1.19  2011/07/20 15:02:04  martin
 *  Revision 1.25.1.18  2011/07/18 07:49:23  hannes
 *  Revision 1.25.1.17  2011/07/08 11:38:51  martin
 *  Revision 1.25.1.16  2011/07/07 13:30:53  martin
 *  Revision 1.25.1.15  2011/07/07 12:41:45  martin
 *  Renamed this file from mbgdrvr.c to mbgclock_main.c.
 *  Revision 1.25.1.14  2011/07/06 07:55:48  martin
 *  Revision 1.25.1.13  2011/07/05 15:35:52  martin
 *  Modified version handling.
 *  Revision 1.25.1.12  2011/07/05 14:35:16  martin
 *  New way to maintain version information.
 *  Revision 1.25.1.11  2011/06/29 14:12:20  martin
 *  Added device IDs for TCR600USB, MSF600USB, and WVB600USB.
 *  Revision 1.25.1.10  2011/06/24 12:52:01  martin
 *  Revision 1.25.1.9  2011/05/16 17:57:43  martin
 *  Revision 1.25.1.8  2011/05/13 20:23:23  martin
 *  Started to support privilege levels for IOCTL calls.
 *  Revision 1.25.1.7  2011/04/18 15:29:44  martin
 *  Revision 1.25.1.6  2011/03/31 11:16:46  martin
 *  Revision 1.25.1.5  2011/03/23 17:07:21  martin
 *  Account for modified _pcps_kfree() macro.
 *  Revision 1.25.1.4  2011/02/09 17:22:23  martin
 *  Revision 1.25.1.3  2011/01/31 14:33:38  martin
 *  Fixes to handle locked/unlocked ioctl calls depending on kernel settings.
 *  Revision 1.25.1.2  2010/11/11 09:15:37  martin
 *  Added definitions to support DCF600USB.
 *  Revision 1.25.1.1  2010/07/14 14:47:31  martin
 *  Account for renamed inline functions.
 *  Revision 1.25  2010/05/03 15:00:42  martin
 *  Fixed exported functions mbgclock_default_get_ucap_entries()
 *  and mbgclock_default_get_ucap_event().
 *  Added some conditional debug code for exported kernel functions.
 *  Revision 1.24  2010/04/26 14:44:04  martin
 *  Generate a compiler warning if no cycles support to compute latencies.
 *  Revision 1.23  2010/03/05 14:41:31  martin
 *  If IRQ needs to be re-enabled the disable/unregister it first in order not to mess up
 *  the kernel. Moved mbgdrvr_disable_cyclic() up, in front of mbgdrvr_enable_cyclic().
 *  Revision 1.22  2010/02/23 16:02:25  martin
 *  Changed the name of some exported functions from mbgclock_get_default_...() 
 *  to mbgclock_default_get_...() for a consistent nameing convention.
 *  Added and exported some new functions which provide access to the ucap FIFO.
 *  Revision 1.21  2009/12/21 15:52:46  martin
 *  Added functions which can be called from other kernel modules 
 *  to read memory mapped timestamps.
 *  Moved some driver-internal definitions from the .h file here.
 *  Changed version code to 3.4.1.
 *  Revision 1.20  2009/09/29 14:55:46  martin
 *  Use the ioctl_switch() inline code instead of the macro.
 *  Revision 1.19  2009/09/21 13:53:20  martin
 *  Fixed CONFIG_COMPAT stuff for kernels 2.6.9.
 *  Revision 1.18  2009/08/12 15:25:29  martin
 *  Fixed a bug due to the device_create() parameter count in kernel 2.6.26.
 *  Revision 1.17  2009/07/22 12:36:30  martin
 *  Check rc of down_interruptible() with sem_usb_cyclic in mbgclock_read().
 *  Revision 1.16  2009/06/30 13:28:49  martin
 *  Set the UTC indicator in the time string passed to ntpd based on the 
 *  UTC offset hours being 0, not based on the UTC status flag.
 *  Fixed printing of version number in kernel messages.
 *  Revision 1.15  2009/03/20 11:58:13  martin
 *  Enhanced error handling of USB devices.
 *  Revision 1.14  2008/12/22 13:26:50  martin
 *  Migrated former file mbginit.c to mbgdrvr.c and merged code
 *  from mbgclk.c and mbgntp.c which are now obsolete.
 *  Use only one common device node per HW device.
 *  Support USB devices and gracefully handle disconnect/reconnect
 *  while the device is opened.
 *  Return -EBUSY if ioctl() is called and unsafe PEX IRQ is enabled.
 *  Restrict usage to 2.6.x kernels for now.
 *  Create own device class with dynamical unique major number
 *  under kernel 2.6 instead of misc devices.
 *  Use 2.6 kernel API calls which trigger udev support.
 *  Enable device IRQ only when poll() or read() is called the first time.
 *  IRQs are disabled when open count decreases to 0 in release().
 *  A cyclic USB read thread emulates IRQs for USB devices.
 *  Init mutexes/spinlocks in pcps_start_device().
 *  Consistenly use pcps_drvr_name instead of mbgclock_name for messages.
 *  mbgclock_name should be used for device nodes/names etc.
 *  Conditionally use kthread API for USB cyclic polling threads.
 *  Protection against unsafe access is now handled in _ioctl_switch(),
 *  depending on whether HW access is required, or not.
 *  Initial debug level set from DEBUG symbol value.
 *  Account for signed irq_num.
 *  Changed debug messages to common fmt printing file pointers first.
 *  Check IRQ timeout also at blocking reads rather than only while polling.
 *  Use MBG_MEM_ADDR type for memory rather than split high/low types.
 *  Added conditional code for hardware timing debugging via LPT port.
 *  Use malloc'ed kernel memory for private PNP device data.
 *  Revision 1.13  2007/07/24 09:40:58  martin
 *  Added support for PEX511, TCR511PEX, and GPS170PEX.
 *  Account for new unified resource handling.
 *  Revision 1.12  2007/03/02 10:39:01  martin
 *  There are kernel sources around v2.6.9 which provide different
 *  versions of the "module_param_array" macro which is specified
 *  in the kernel header moduleparams.h.
 *  Newer versions of that file also define a macro "__MODULE_PARM_TYPE",
 *  so guess which version of "module_param_array" is to be used based
 *  on the presence of the "__MODULE_PARAM_TYPE" macro.
 *  Added type casts to avoid compiler warnings.
 *  Revision 1.11  2006/08/28 11:15:22  martin
 *  Added an optional module parameter pretend_sync which makes the driver
 *  pretend to NTP the device is always synchronized.
 *  Revision 1.10  2006/07/03 13:17:16  martin
 *  Added support for GPS170PCI, PCI511, and TCR511PCI.
 *  Updated copyright string and turned it into a macro.
 *  Export symbols which may be required for inter-module calls.
 *  Use module_param from 2.6.x kernels, if applicable.
 *  Revision 1.9  2005/06/02 15:48:34  martin
 *  Call pci_enable_device() which also accounts for IRQ routing in
 *  recent 2.6 kernels.
 *  Don't report the the return value of pci_register_driver() as number
 *  of devices found since this has been changed in the kernel code.
 *  Revision 1.8  2004/11/09 09:32:03  martin
 *  Modifications to support kernel 2.6.
 *  Use static table of supported devices to support "modinfo".
 *  Added support for TCR167PCI.
 *  New module parameter dev allows to select device.
 *  Modified load messages.
 *  Revision 1.7  2003/07/30 07:32:41  martin
 *  Print debug level before radio clock listing.
 *  Revision 1.6  2003/07/08 15:24:58  martin
 *  Use plug'n'play manager functions for PCI cards under
 *  kernel 2.4.0 or newer.
 *  Removed obsolete __initfunc() stuff.
 *  Revision 1.5  2003/04/25 10:22:10  martin
 *  Updated copyright string.
 *  Revision 1.4  2002/11/21 10:18:02  martin
 *  Modified startup syslog messages.
 *  Revision 1.3  2002/05/07 07:56:14  martin
 *  Added module license to prevent newer kernels from
 *  printing "module will taint the kernel" warning.
 *  Revision 1.2  2001/07/27 13:25:12  MARTIN
 *  Control usage of __initfunc().
 *  Revision 1.1  2001/03/05 17:19:28  MARTIN
 *  Initial revision
 *
 **************************************************************************/

#define EXPORT_SYMTAB

#define _MBGCLOCK
  #include <mbgclock.h>
#undef _MBGCLOCK

#include <mbgversion.h>
#include <mbgioctl.h>
#include <pcpsirq.h>
#include <mbgddmsg.h>

#include <stddef.h>

#include <linux/termios.h>  //##++ or <asm/termios.h> ??
#include <linux/pci.h>

#if _USE_LINUX_DEVFS
  #include <linux/devfs_fs_kernel.h>
#endif

#if defined( MBG_MICRO_VERSION_CODE_DEV )
  #define MBG_MICRO_VERSION_CODE  MBG_MICRO_VERSION_CODE_DEV
  #define MBG_MICRO_VERSION_STR   MBG_MICRO_VERSION_STR_DEV
#else
  #define MBG_MICRO_VERSION_CODE  0
  #define MBG_MICRO_VERSION_STR   "0"
#endif


#define MBG_COPYRIGHT    "(c) Meinberg 2001-" MBG_CURRENT_COPYRIGHT_YEAR_STR

#define MBG_DRVR_NAME    "mbgclock"

#if !defined( MBGCLOCK_MAX_DEVS )
  #define MBGCLOCK_MAX_DEVS  20
#endif


#define DEBUG_LATENCY     ( 0 && defined( DEBUG ) )
#define DEBUG_IOCTL       ( 0 && defined( DEBUG ) )
#define DEBUG_IRQ_TIMING  ( 0 && defined( DEBUG ) )
#define DEBUG_SYS_IRQS    ( 0 && defined( DEBUG ) )

#if !defined( OMIT_PRIV_CHECKING )
  #define OMIT_PRIV_CHECKING  0
#endif



const char pcps_driver_name[] = MBG_DRVR_NAME;
#define mbgclock_name  pcps_driver_name

PCPS_DRVR_INFO drvr_info = { MBG_VERSION_CODE( MBG_MICRO_VERSION_CODE ),
                             0, MBG_DRVR_NAME " radio clock driver" };

int pretend_sync;
// NOTE: int debug is defined in a library module

// The variable below is set to point to the first device supporting
// fast HR timestamps (via memotry mapped access).
static PCPS_DDEV *default_fast_hr_time_pddev;
static PCPS_DDEV *default_ucap_pddev;

#if USE_DEBUG_PORT
  static MBG_DBG_DATA mbg_dbg_data;
  static MBG_DBG_PORT mbg_dbg_port = 0x378 + 0;  //##++
  static PCPS_IO_ADDR_MAPPED mbg_dbg_port_mapped;  //##++
#endif  // USE_DEBUG_PORT

#include <macioctl.h>


#if !defined( atomic_inc_return )

static __inline__ int atomic_add_return(int i, atomic_t *v)
{
	int __i;
#ifdef CONFIG_M386
	if(unlikely(boot_cpu_data.x86==3))
		goto no_xadd;
#endif
	/* Modern 486+ processor */
	__i = i;
	__asm__ __volatile__(
		LOCK "xaddl %0, %1;"
		:"=r"(i)
		:"m"(v->counter), "0"(i));
	return i + __i;

#ifdef CONFIG_M386
no_xadd: /* Legacy 386 processor */
	local_irq_disable();
	__i = atomic_read(v);
	atomic_set(v, i + __i);
	local_irq_enable();
	return i + __i;
#endif
}

  #define atomic_inc_return(v) atomic_add_return(1, v)

#endif


// the following variables may be overwritten at load time
static int io[PCPS_MAX_ISA_CARDS];
static int irq[PCPS_MAX_ISA_CARDS];

#if _PCPS_USE_LINUX_CHRDEV
  static int major = 0;
  static int minor = 0;
  static int max_devs = MBGCLOCK_MAX_DEVS;
  static int ddev_list_alloc_size;
#elif _PCPS_USE_LINUX_MISC_DEV  //##++
  static int max_devs = MBGCLOCK_MAX_DEVS;
  //##++
  // index of the device to use by the kernel driver
  // static int dev;
#endif


#ifdef MODULE

MODULE_AUTHOR( "Martin Burnicki <martin.burnicki@meinberg.de>" );
MODULE_DESCRIPTION( "Driver for Meinberg plug-in and USB radio clocks." );
#ifdef MODULE_VERSION
  MODULE_VERSION( MBG_MAIN_VERSION_STR "." MBG_MICRO_VERSION_STR );
#endif
#ifdef MODULE_LICENSE
  MODULE_LICENSE( "GPL" );
#endif
MODULE_SUPPORTED_DEVICE( "mbgclock" );

#if defined( module_param_array )
  static int n_io;
  #if defined( __MODULE_PARM_TYPE )
    module_param_array( io, int, &n_io, 0444 );
  #else
    module_param_array( io, int, n_io, 0444 );
  #endif
#elif defined( MODULE_PARM )
  MODULE_PARM( io, "1-" __MODULE_STRING( PCPS_MAX_ISA_CARDS ) "i" );
#endif
MODULE_PARM_DESC( io, "port address(es) of ISA card(s)" );

#if defined( module_param_array )
  static int n_irq;
  #if defined( __MODULE_PARM_TYPE )
    module_param_array( irq, int, &n_irq, 0444 );
  #else
    module_param_array( irq, int, n_irq, 0444 );
  #endif
#elif defined( MODULE_PARM )
  MODULE_PARM( irq, "1-" __MODULE_STRING( PCPS_MAX_ISA_CARDS ) "i" );
#endif
MODULE_PARM_DESC( irq, "IRQ line(s) used by ISA card(s)" );

#if _PCPS_USE_LINUX_CHRDEV

  #if defined( module_param )
    module_param( major, int, S_IRUGO );
    module_param( minor, int, S_IRUGO );
    module_param( max_devs, int, S_IRUGO );
  #elif defined( MODULE_PARM )
    MODULE_PARM( major, "i" );
    MODULE_PARM( minor, "i" );
    MODULE_PARM( max_devs, "i" );
  #endif
  MODULE_PARM_DESC( major, "major device number, dynamic by default" );
  MODULE_PARM_DESC( minor, "first minor device number, dynamic by default" );
  MODULE_PARM_DESC( max_devs, "max number of supported devices" );

#elif _PCPS_USE_LINUX_MISC_DEV  //##++

  #if defined( module_param )
    module_param( dev, int, 0444 );
  #elif defined( MODULE_PARM )
    MODULE_PARM( dev, "i" );
  #endif
  MODULE_PARM_DESC( dev, "index of device to use" );

#endif

#if defined( module_param )
  module_param( pretend_sync, int, 0444 );
#elif defined( MODULE_PARM )
  MODULE_PARM( pretend_sync, "i" );
#endif
MODULE_PARM_DESC( pretend_sync, "pretend to NTP to be always sync'ed" );

#ifdef DEBUG
  #if defined( module_param )
    module_param( debug, int, 0444 );
  #elif defined( MODULE_PARM )
    MODULE_PARM( debug, "i" );
  #endif
  MODULE_PARM_DESC( debug, "debug level, only if compiled with DEBUG" );
#endif

#if _PCPS_USE_LINUX_MISC_DEV
  #ifdef MODULE_ALIAS_MISCDEV
    MODULE_ALIAS_MISCDEV( MISC_MINOR_CLK );
    MODULE_ALIAS_MISCDEV( MISC_MINOR_NTP );
  #endif
#endif

#ifdef EXPORT_SYMBOL
#if 0 //##++
EXPORT_SYMBOL( pcps_ddev );
EXPORT_SYMBOL( n_ddevs );
EXPORT_SYMBOL( access_in_progress );
#endif
#endif

#ifndef module_init
  #define mbgclock_init_module     init_module
  #define mbgclock_cleanup_module  cleanup_module
#endif

#endif

#define DRV_NAME    MBG_DRVR_NAME

#define MBG_SIZE_TLG    33

#define _min( _a, _b )  ( ( (_b) < (_a) ) ? (_b) : (_a) )

#define CYCLIC_TIMEOUT ( (ulong) 2 * HZ )  // 2 seconds

#if NEW_FASYNC2
  #define _kill_fasync( _fa, _sig, _band ) \
    kill_fasync( _fa, _sig, _band )
#elif NEW_FASYNC
  #define _kill_fasync( _fa, _sig, _band ) \
    kill_fasync( *(_fa), _sig, _band )
#else
  #define _kill_fasync( _fa, _sig, _band ) \
    kill_fasync( *(_fa), _sig )
#endif


#if !defined( IRQF_DISABLED ) && !defined( IRQF_SHARED )
  #define IRQF_DISABLED   SA_INTERRUPT
  #define IRQF_SHARED     SA_SHIRQ
#endif

#ifndef __exit
  #define __exit
#endif

static PCPS_DDEV **ddev_list;
static struct semaphore sem_fops;  // still needs to be initialized !!

// The definitions in this file are shared with other Linux drivers:
#include <lx-shared.h>


#define DEBUG_HW_LPT  0

#if DEBUG_HW_LPT
  static spinlock_t hwdbg_lock = SPIN_LOCK_UNLOCKED;

  #define MBG_BIT_OPEN     0x03
  #define MBG_BIT_RELEASE  0x01
  #define MBG_BIT_IRQ      0x04
  #define MBG_BIT_TEST     0x08


  #define _mbg_dbg_hw_lpt_vars \
    unsigned long hwdbg_flags;

  #define _mbg_dbg_hw_lpt_set_bit( _b )                 \
  {                                                     \
    spin_lock_irqsave( &hwdbg_lock, hwdbg_flags );      \
    _mbg_dbg_set_bit( pddev, _b );                      \
    spin_unlock_irqrestore( &hwdbg_lock, hwdbg_flags ); \
  }

  #define _mbg_dbg_hw_lpt_clr_bit( _b )                 \
  {                                                     \
    spin_lock_irqsave( &hwdbg_lock, hwdbg_flags );      \
    _mbg_dbg_clr_bit( pddev, _b );                      \
    spin_unlock_irqrestore( &hwdbg_lock, hwdbg_flags ); \
  }

#else

  #define _mbg_dbg_hw_lpt_vars
  #define _mbg_dbg_hw_lpt_set_bit( _b );
  #define _mbg_dbg_hw_lpt_clr_bit( _b );

#endif


#if _PCPS_HAVE_LINUX_CLASS
  static char mbgclock_class_name[] = "mbgclock";
  static char mbg_clk_dev_node_fmt[] = "mbgclock%d";

  #if _PCPS_HAVE_LINUX_CLASS_CREATE
    static struct class *mbgclock_class;
  #elif _PCPS_HAVE_LINUX_CLASS_SIMPLE
    static struct class_simple *mbgclock_class;
  #endif
#endif


#if DEBUG_LATENCY
  static unsigned long long tsc_irq_1;
  static unsigned long long tsc_irq_2;
  static unsigned long long tsc_usb_1;
  static unsigned long long tsc_usb_2;
#endif



#if defined( DEBUG )

static /*HDR*/
const char *get_ioctl_name( unsigned long code )
{
  static const MBG_CODE_NAME_TABLE_ENTRY tbl[] = MBG_IOCTL_CODE_TABLE;

  const MBG_CODE_NAME_TABLE_ENTRY *p = tbl;

  for ( p = tbl; p->name; p++ )
  {
    if ( p->code == code )
      return p->name;
  }

  return "UNKNOWN_IOCTL";

}  // get_ioctl_name

#endif



#if DEBUG_SYS_IRQS

static /*HDR*/
void list_system_irqs( void )
{
  int i;
  struct irq_desc *desc;

  // This is some sample code from a forum which should
  // list some information on all IRQs supported by the kernel.
  // However, the members of struct irq_desc may vary with
  // the kernel version, so this code may need to be adapted
  // depending on the kernel version.
  for_each_irq_desc( i, desc )
  {
    if ( !desc )
      continue;

    printk( KERN_INFO "%d: status=%08x, chip=%08x, handle_irq=%08x\n",
            i, (u32) desc->status, (u32) desc->chip, (u32) desc->handle_irq );
  }

}  // list_system_irqs

#endif


#if _PCPS_USE_LINUX_KTHREAD

  #define _usb_read_thread_should_stop() \
     kthread_should_stop()

  #define _usb_read_thread_exit( _pddev, _v ) \
    return (_v);

  #define _usb_read_thread_started( _pddev ) \
    ( (_pddev)->usb_read_thread != NULL )

  #define _usb_read_thread_start( _fnc, _pddev )               \
    (_pddev)->usb_read_thread = kthread_run( (_fnc), (_pddev), \
       "%s%d", mbgclock_name, MINOR( (_pddev)->lx_dev ) )

  #define _usb_read_thread_failed_to_start( _pddev ) \
    ( IS_ERR( (_pddev)->usb_read_thread ) )

  #define _usb_read_thread_set_unused( _pddev ) \
    (_pddev)->usb_read_thread = NULL;

  #define _usb_read_thread_stop( _pddev ) \
    kthread_stop( (_pddev)->usb_read_thread )

  // This is not required if the kthread API is being used.
  #define _usb_read_thread_daemonize( _pddev ) \
    _nop_macro_fnc()

#else

  #define _usb_read_thread_should_stop() \
    signal_pending( current )

  #define _usb_read_thread_exit( _pddev, _v ) \
    complete_and_exit( &pddev->usb_read_thread.exit, (_v) )

  #define _usb_read_thread_started( _pddev ) \
    ( (_pddev)->usb_read_thread.pid != 0 )

  #define _usb_read_thread_start( _fnc, _pddev )         \
    init_completion( &(_pddev)->usb_read_thread.exit );  \
    (_pddev)->usb_read_thread.pid = kernel_thread( (_fnc), (_pddev), CLONE_KERNEL );

  #define _usb_read_thread_failed_to_start( _pddev ) \
    ( (_pddev)->usb_read_thread.pid == 0 )

  #define _usb_read_thread_set_unused( _pddev ) \
    (_pddev)->usb_read_thread.pid = 0;

  #define _usb_read_thread_stop( _pddev )                   \
    kill_proc( (_pddev)->usb_read_thread.pid, SIGKILL, 1 ); \
    wait_for_completion( &(_pddev)->usb_read_thread.exit )

  #define _usb_read_thread_daemonize( _pddev )                                          \
    snprintf( (_pddev)->usb_read_thread.name, sizeof( (_pddev)->usb_read_thread.name ), \
              "%s%d", mbgclock_name, MINOR( (_pddev)->lx_dev ) );                       \
    daemonize( (_pddev)->usb_read_thread.name );                                        \
    allow_signal( SIGKILL )

#endif


static void mbgdrvr_delete_device( PCPS_DDEV *pddev );


static /*HDR*/
void ddev_list_free( void )
{
  if ( ddev_list )
  {
    _pcps_kfree( ddev_list, ddev_list_alloc_size );
    ddev_list = NULL;

    _mbgddmsg_1( MBG_DBG_DETAIL, "%s: freed device list", pcps_driver_name );
  }

}  // ddev_list_free



static /*HDR*/
int ddev_list_alloc( void )
{
  ddev_list_alloc_size = max_devs * sizeof( *ddev_list );

  ddev_list = _pcps_kmalloc( ddev_list_alloc_size );

  if ( ddev_list == NULL )
  {
    printk( KERN_ERR "%s: failed to allocate memory for device list\n", pcps_driver_name );
    return -ENOMEM;
  }

  _mbgddmsg_3( MBG_DBG_DETAIL, "%s: allocated device list, %u bytes for up to %u entries",
               pcps_driver_name, ddev_list_alloc_size, max_devs );

  memset( ddev_list, 0, ddev_list_alloc_size );

  return 0;

}  // ddev_list_alloc



static /*HDR*/
PCPS_DDEV **ddev_list_locate_minor( unsigned int minor )
{
  int i;

  for ( i = 0; i < max_devs; i++ )
  {
    PCPS_DDEV **ppddev = &ddev_list[i];

    if ( *ppddev )
      if ( minor == MINOR( (*ppddev)->lx_dev ) )
        return ppddev;
  }

  printk( KERN_WARNING "%s: unable to locate minor %i in device list\n",
          pcps_driver_name, minor );

  return NULL;

}  // ddev_list_locate_minor



static /*HDR*/
PCPS_DDEV **ddev_list_locate_device( PCPS_BUS_FLAGS bus_flags, PCPS_DEV_ID dev_id, PCPS_SN_STR sernum )
{
  int i;

  _mbgddmsg_3( MBG_DBG_DETAIL, "%s: searching device list for ID %04X, S/N %s",
               pcps_driver_name, dev_id, sernum  );

  for ( i = 0; i < max_devs; i++ )
  {
    PCPS_DDEV **ppddev = &ddev_list[i];

    if ( *ppddev )
    {
      _mbgddmsg_4( MBG_DBG_DETAIL, "%s: entry %i: ID %04X, S/N %s",
                   pcps_driver_name, i, _pcps_ddev_dev_id( *ppddev ), _pcps_ddev_sernum( *ppddev ) );

      if ( ( dev_id == _pcps_ddev_dev_id( *ppddev ) )
        && ( strcmp( sernum, _pcps_ddev_sernum( *ppddev ) ) == 0 ) )
      {
        // device found
        _mbgddmsg_3( MBG_DBG_INFO, "%s: new device %04X S/N %s already in device list",
                     pcps_driver_name, dev_id, sernum  );

        return ppddev;
      }
    }
  }

  _mbgddmsg_3( MBG_DBG_DETAIL, "%s: device ID %04X, S/N %s not found in device list",
               pcps_driver_name, dev_id, sernum  );

  return NULL;

}  // ddev_list_locate_device



static /*HDR*/
int ddev_list_remove_entry( PCPS_DDEV *pddev )
{
  int i;

  for ( i = 0; i < max_devs; i++ )
  {
    PCPS_DDEV **ppddev = &ddev_list[i];

    if ( *ppddev == pddev )
    {
      *ppddev = NULL;
      return 0;
    }
  }

  printk( KERN_WARNING "%s: failed to remove device minor %i from device list\n",
          pcps_driver_name, MINOR( pddev->lx_dev ) );

  return -1;

}  // ddev_list_remove_entry



static /*HDR*/
int ddev_list_add_entry( PCPS_DDEV *pddev )
{
  int i;

  for ( i = 0; i < max_devs; i++ )
  {
    PCPS_DDEV **ppddev = &ddev_list[i];

    if ( *ppddev == NULL )
    {
      *ppddev = pddev;
      return i;
    }
  }

  printk( KERN_WARNING "%s: failed to add device to device list: list full\n",
          pcps_driver_name);

  return -1;

}  // ddev_list_add_entry



static /*HDR*/
void pcps_time_to_time_str( PCPS_TIME *t, char *s )
{
  PCPS_TIME_STATUS status = t->status;

  if ( status & PCPS_INVT )    // invalid time
  {
    status |= PCPS_FREER;
    status &= ~PCPS_SYNCD;
  }

  *s++ = '\02';                                       // STX
  s += sprintf( s, "D:%2.2d.%2.2d.%2.2d;T:%1.1d;U:%2.2d.%2.2d.%2.2d;",
                t->mday, t->month, t->year, t->wday,
                t->hour, t->min, t->sec );

  *s++ = ( pretend_sync || ( status & PCPS_SYNCD ) ) ? ' ' : '#';     // sync'd after reset

  *s++ = ( !pretend_sync && ( status & PCPS_FREER ) ) ? '*' : ' ';    // free running

  *s++ = ( t->offs_utc == 0 ) ? 'U' :                 // UTC
         ( ( status & PCPS_DL_ENB ) ? 'S' : ' ' );    // DST enabled

  *s++ = ( status & PCPS_DL_ANN ) ? '!' :             // DST change announced
         ( ( status & PCPS_LS_ANN ) ? 'A' : ' ' );    // leap second announced

  *s++ = '\03';                                       // ETX
  *s = 0;                                             // terminate string

}  // pcps_time_to_time_str



// The interrupt handler for plug-in cards. USB devices
// don't generate periodic interrupts. Instead, they can
// send a periodic message once per second.

static /*HDR*/
#if REQUEST_IRQ_WO_REGS
  irqreturn_t mbgclock_irq_handler( int hw_irq, void *arg )
#else
  irqreturn_t mbgclock_irq_handler( int hw_irq, void *arg, struct pt_regs *regs )
#endif
{
  PCPS_DDEV *pddev;
  unsigned long flags;
  int curr_access_in_progress;
  #if defined( IRQ_RETVAL )
    int retval = IRQ_NONE;
  #endif
  #if DEBUG_IRQ_TIMING
    unsigned long prv_jiffies_at_irq;
  #endif
  int rc;
  _mbg_dbg_hw_lpt_vars


  pddev = (PCPS_DDEV *) arg;

  if ( pddev == NULL )
  {
    printk( KERN_WARNING "%s: IRQ handler called with NULL device\n",
            pcps_driver_name );

    goto out;
  }

  if ( !_pcps_ddev_has_gen_irq( pddev ) )
    goto out;


  _mbg_dbg_hw_lpt_set_bit( MBG_BIT_IRQ );

  rc = -1;
  spin_lock_irqsave( &pddev->irq_lock, flags );

  curr_access_in_progress = atomic_read( &pddev->access_in_progress );

  #if DEBUG_IRQ_TIMING
    prv_jiffies_at_irq = pddev->jiffies_at_irq;
  #endif
  pddev->jiffies_at_irq = jiffies;

  #if DEBUG_LATENCY
    rdtscll( tsc_irq_1 );
  #endif

  if ( !curr_access_in_progress )
    rc = _pcps_read_var( pddev, PCPS_GIVE_TIME, pddev->t );

  #if DEBUG_LATENCY
    rdtscll( tsc_irq_2 );
  #endif

  _pcps_ddev_ack_irq( pddev );


  if ( !curr_access_in_progress )
  {
    if ( rc == PCPS_SUCCESS )
    {
      atomic_set( &pddev->data_avail, 1 );

      wake_up_interruptible( &pddev->wait_queue );

      if ( pddev->fasyncptr )
        _kill_fasync( &pddev->fasyncptr, SIGIO, POLL_IN );
    }
  }

  spin_unlock_irqrestore( &pddev->irq_lock, flags );


  #if DEBUG_IRQ_TIMING
  {
    const char *info;

    if ( !curr_access_in_progress )
    {
      if ( rc == PCPS_SUCCESS )
        info = "data read";
      else
        info = "read error";
    }
    else
    {
      info = "** access in progress";
      rc = curr_access_in_progress;
    }

    printk( KERN_INFO "%s: irq_handler %i at 0x%lX - 0x%lX -> %li, %s_%s: %s: %i\n",
            pcps_driver_name, _pcps_ddev_irq_num( pddev),
            pddev->jiffies_at_irq, prv_jiffies_at_irq,
            (long) pddev->jiffies_at_irq - (long) prv_jiffies_at_irq,
            _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ),
            info, rc );
  }
  #endif

  #if defined( IRQ_RETVAL )
    retval = IRQ_HANDLED;
  #endif

out:
  _mbg_dbg_hw_lpt_clr_bit( MBG_BIT_IRQ );

  #if defined( IRQ_RETVAL )
    return retval;
  #endif

}  // mbgclock_irq_handler



__mbg_inline
int get_cyclic_lock( PCPS_DDEV *pddev, unsigned long *p_flags )
{
  #if _PCPS_USE_USB
  if ( _pcps_ddev_is_usb( pddev ) )
  {
    if ( _down_interruptible_pddev( &pddev->sem_usb_cyclic, "sem_usb_cyclic", "read_usb_cyclic", pddev ) < 0 )
      return -ERESTARTSYS;
  }
  else
  #endif
    spin_lock_irqsave( &pddev->irq_lock, *p_flags );

  return 0;

}  // get_cyclic_lock



__mbg_inline
void release_cyclic_lock( PCPS_DDEV *pddev, unsigned long *p_flags )
{
  #if _PCPS_USE_USB
  if ( _pcps_ddev_is_usb( pddev ) )
    _up_pddev( &pddev->sem_usb_cyclic, "sem_usb_cyclic", "read_usb_cyclic", pddev );
  else
  #endif
    spin_unlock_irqrestore( &pddev->irq_lock, *p_flags );

}  // release_cyclic_lock



#if _PCPS_USE_USB

// The function below is started as a new kernel thread in order to
// receive periodic messages from an USB device.
// This is used to emulate the hardware IRQ generated by
// plug-in cards.

static /*HDR*/
int mbgdrvr_read_usb_cyclic( void *p )
{
  PCPS_DDEV *pddev = p;
  PCPS_TIME t;

  _mbgddmsg_5( MBG_DBG_DETAIL, "%s: USB xmt tmo: %u, rcv tmo: %u, cycl tmo: %u, HZ: %u",
               pcps_driver_name, MBGUSB_TIMEOUT_SEND, MBGUSB_TIMEOUT_RECEIVE,
               MBGUSB_TIMEOUT_RECEIVE_CYCLIC, HZ );

  _usb_read_thread_daemonize( pddev );

  // The device sends a cyclic message in intervals of 1 s,
  // so we have to wait more than 1 s totally to detect a
  // timeout.
  // Unfortunatly the USB read function does not return if
  // we receive a signal (e.g. to terminate), so in order
  // to be able to react on a signal in a timely manner
  // we call the read function with a fraction of the total
  // timeout and simply retry unless we have received a signal,
  // or the total timeout interval has expired.
  for (;;)
  {
    int actual_count = 0;  // required by macro
    int rc;

    if ( _usb_read_thread_should_stop() )  // we have been signalled to abort
    {
      _mbgddmsg_3( MBG_DBG_DETAIL, "%s: cyclic USB read %s_%s received signal to stop", pcps_driver_name,
                   _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      break;
    }

    // read with fractional timeout interval
    rc = _pcps_usb_read_var_cyclic( pddev, &t );

    if ( rc < 0 )
    {
      if ( rc == -ETIMEDOUT )      // == -110
      {
        #if 0
          _mbgddmsg_3( MBG_DBG_DETAIL, "%s: cyclic USB read %s_%s timed out", pcps_driver_name,
                       _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
        #endif
        continue;    // this may be a normal case
      }

      // Read has been terminated due to some other error.
      // Maybe the device has been disconnected.
      _mbgddmsg_4( MBG_DBG_WARN, "%s: cyclic USB read %s_%s returned %i", pcps_driver_name,
                   _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ), rc );
      break;
    }

    if ( actual_count != sizeof( t ) )
    {
      _mbgddmsg_5( MBG_DBG_WARN, "%s: cyclic USB read %s_%s returned %i of %i bytes", pcps_driver_name,
                   _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ), actual_count, (int) sizeof( t ) );
      continue;
    }

    // received a message from the device
    #if DEBUG_LATENCY
      rdtscll( tsc_usb_1 );
    #endif

    if ( _down_interruptible_pddev( &pddev->sem_usb_cyclic, "sem_usb_cyclic", "read_usb_cyclic", pddev ) < 0 )
      break;

    #if DEBUG_LATENCY
      rdtscll( tsc_usb_2 );
    #endif

    pddev->jiffies_at_irq = jiffies;
    pddev->t = t;
    atomic_set( &pddev->data_avail, 1 );

    _up_pddev( &pddev->sem_usb_cyclic, "sem_usb_cyclic", "read_usb_cyclic", pddev );

    _mbgddmsg_7( MBG_DBG_DETAIL, "%s: cyclic USB read %s_%s success: %02d:%02d:%02d.%02d",
                 pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ),
                 t.hour, t.min, t.sec, t.sec100 );

    wake_up_interruptible( &pddev->wait_queue );

    if ( pddev->fasyncptr )
      _kill_fasync( &pddev->fasyncptr, SIGIO, POLL_IN );
  }

  _mbgddmsg_3( MBG_DBG_DETAIL, "%s: cyclic USB read thread for %s_%s exits",
               pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );

  _usb_read_thread_set_unused( pddev );
  _usb_read_thread_exit( pddev, 0 );

}  // mbgdrvr_read_usb_cyclic



static /*HDR*/
int mbgdrvr_ctrl_usb_cyclic( PCPS_DDEV *pddev, uint8_t cmd )
{
  int actual_count = 0;  // required by macro
  int rc;

  if ( _down_interruptible( &pddev->dev_mutex, "dev_mutex", "ctrl_usb_cyclic", pddev ) < 0 )
    return -ERESTARTSYS;

  rc = _pcps_usb_write_var( pddev, &cmd );

  _up( &pddev->dev_mutex, "dev_mutex", "ctrl_usb_cyclic", pddev );

  _mbgddmsg_3( MBG_DBG_DETAIL, "%s control USB cyclic cmd %02X, rc: %d",
               pcps_driver_name, cmd, rc );

  return rc;

}  // mbgdrvr_ctrl_usb_cyclic

#endif  // _PCPS_USE_USB



static /*HDR*/
int mbgdrvr_disable_cyclic( PCPS_DDEV *pddev )
{
  _mbg_dbg_hw_lpt_vars

  if ( !( pddev->irq_stat_info & PCPS_IRQ_STAT_ENABLED ) )
    goto done;

  #if _PCPS_USE_USB
  if ( _pcps_ddev_is_usb( pddev ) )
  {
    _mbg_dbg_hw_lpt_set_bit( MBG_BIT_TEST );
    mbgdrvr_ctrl_usb_cyclic( pddev, PCPS_IRQ_NONE );
    _mbg_dbg_hw_lpt_clr_bit( MBG_BIT_TEST );

    _mbgddmsg_1( MBG_DBG_DETAIL, "%s: disabled cyclic USB msgs", pcps_driver_name );

    if ( _usb_read_thread_started( pddev ) )
    {
      _mbgddmsg_3( MBG_DBG_DETAIL, "%s: cyclic USB read thread for %s_%s going to be stopped",
                   pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );

      _usb_read_thread_stop( pddev );

      _mbgddmsg_3( MBG_DBG_DETAIL, "%s: cyclic USB read thread for %s_%s has been stopped",
                   pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
    }
  }
  else
  #endif
  {
    int irq_num = _pcps_ddev_irq_num( pddev );

    _mbg_dbg_hw_lpt_set_bit( MBG_BIT_TEST );
    _pcps_ddev_disb_irq( pddev );
    _mbg_dbg_hw_lpt_clr_bit( MBG_BIT_TEST );

    free_irq( irq_num, pddev );

    _mbgddmsg_2( MBG_DBG_INFO, "%s: disabled IRQ %i", pcps_driver_name, irq_num );
  }

done:
  pddev->irq_stat_info &= ~( PCPS_IRQ_STAT_ENABLED | PCPS_IRQ_STAT_ENABLE_CALLED );
  return 0;

}  // mbgdrvr_disable_cyclic



static /*HDR*/
int mbgdrvr_enable_cyclic( PCPS_DDEV *pddev, unsigned int force )
{
  if ( ( force == 0 ) && ( pddev->irq_stat_info & PCPS_IRQ_STAT_ENABLE_CALLED ) )
    return 0;   // has already been called

  if ( force > 1 )
    printk( KERN_WARNING "%s: trying to re-initialize cyclic msgs for %s_%s\n",
            pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );

  pddev->irq_stat_info |= PCPS_IRQ_STAT_ENABLE_CALLED;

  if ( pddev->irq_stat_info & PCPS_IRQ_STAT_UNSAFE )
    printk( KERN_WARNING "%s: Enabling IRQs for dev %s_%s though unsafe\n",
            pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );

  pddev->jiffies_at_irq = jiffies;

  #if _PCPS_USE_USB
  if ( _pcps_ddev_is_usb( pddev ) )
  {
    if ( force > 1 )
      usb_reset_device( pddev->udev );

    if ( !_usb_read_thread_started( pddev ) )
    {
      _usb_read_thread_start( mbgdrvr_read_usb_cyclic, pddev );

      if ( _usb_read_thread_failed_to_start( pddev ) )
      {
        printk( KERN_WARNING "%s: failed to start cyclic USB read thread for %s_%s\n",
                pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
        _usb_read_thread_set_unused( pddev );
      }
      else
        _mbgddmsg_3( MBG_DBG_DETAIL, "%s: cyclic USB read thread for %s_%s started successfully",
                     pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
    }
    else
      _mbgddmsg_3( MBG_DBG_DETAIL, "%s: cyclic USB read thread for %s_%s already started",
                   pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );

    if ( _usb_read_thread_started( pddev ) )
    {
      pddev->irq_stat_info |= PCPS_IRQ_STAT_ENABLED;
      mbgdrvr_ctrl_usb_cyclic( pddev, PCPS_IRQ_1_SEC );
      _mbgddmsg_3( MBG_DBG_INFO, "%s: initialized cyclic USB msgs for %s_%s",
                   pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
    }
  }
  else
  #endif
  {
    int irq_num = _pcps_ddev_irq_num( pddev );
    int rc;

    // If the IRQ has already been enabled and registered with the kernel before
    // then we must disable and unregister it before we re-enable it and register
    // it once more. Otherwise the kernel's list of registered IRQ handlers as
    // reported by 'cat /proc/interrupts' will be messed up.
    if ( pddev->irq_stat_info & PCPS_IRQ_STAT_ENABLED )
      mbgdrvr_disable_cyclic( pddev );

    rc = request_irq( irq_num, mbgclock_irq_handler,
                      _pcps_ddev_is_isa( pddev ) ?
                      IRQF_DISABLED : IRQF_SHARED,
                      pcps_driver_name, pddev );

    if ( rc < 0 )
    {
      printk( KERN_ERR "%s: failed to request IRQ %i for %s_%s, rc: %i",
              pcps_driver_name, irq_num, _pcps_ddev_type_name( pddev ),
              _pcps_ddev_sernum( pddev ), rc );
      return -EBUSY;
    }

    pddev->irq_stat_info |= PCPS_IRQ_STAT_ENABLED;

    _pcps_ddev_enb_irq( pddev, PCPS_IRQ_1_SEC );
    _mbgddmsg_5( MBG_DBG_INFO, "%s: initialized IRQ %i for %s_%s (open_count: %i)",
                 pcps_driver_name, irq_num, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ),
                 atomic_read( &pddev->open_count ) );
  }

  return 0;

}  // mbgdrvr_enable_cyclic



static /*HDR*/
unsigned int mbgclock_poll( struct file *filp, poll_table *pt )
{
  unsigned int poll_retval = 0;
  PCPS_DDEV *pddev = NULL;
  int rc = mbgdrvr_get_pddev( &pddev, filp, "poll" );

  if ( rc < 0 )
  {
    poll_retval = POLLERR | POLLHUP;
    goto out;
  }

  mbgdrvr_enable_cyclic( pddev, 0 );

  poll_wait( filp, &pddev->wait_queue, pt );

  if ( atomic_read( &pddev->data_avail ) )
    poll_retval = POLLIN | POLLRDNORM;
  else
  {
    unsigned long flags = 0;
    unsigned long jiffies_now = jiffies;
    unsigned long jiffies_at_irq;
    long delta_jiffies;

    if ( get_cyclic_lock( pddev, &flags ) < 0 )
      return -ERESTARTSYS;

    jiffies_at_irq = pddev->jiffies_at_irq;

    release_cyclic_lock( pddev, &flags );

    delta_jiffies = (long) jiffies_now - (long) jiffies_at_irq;


    #if 0 && DEBUG_IRQ_TIMING
      printk( KERN_WARNING "%s: poll chk cyclic timeout %s_%s: 0x%08lX - 0x%08lX = %li, timeout: %li",
                   pcps_driver_name,
                   _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ),
                   jiffies_now, jiffies_at_irq,
                   delta_jiffies, CYCLIC_TIMEOUT
                 );
    #endif

    if ( delta_jiffies > CYCLIC_TIMEOUT )
    {
      printk( KERN_WARNING "%s: ** cyclic timeout polling %s_%s: 0x%08lX - 0x%08lX = %li, exceeds %li",
                   pcps_driver_name,
                   _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ),
                   jiffies_now, jiffies_at_irq,
                   delta_jiffies, CYCLIC_TIMEOUT
                 );

      mbgdrvr_enable_cyclic( pddev, 2 );
    }
  }

out:
  return poll_retval;

}  // mbgclock_poll



/*
 * The function below is called whenever fcntl( .., F_SETFL, ..) is called
 * to change the device's FASYNC flag.
 *
 */
static /*HDR*/
int mbgclock_fasync( int fd, struct file *filp, int on )
{
  PCPS_DDEV *pddev = NULL;
  int rc = mbgdrvr_get_pddev( &pddev, filp, "fasync" );

  if ( rc < 0 )
    goto out;

  // mbgdrvr_enable_cyclic( pddev, 0 );    //##++ conditionally / always enable IRQ here?

  rc = fasync_helper( fd, filp, on, &pddev->fasyncptr );

out:
  return rc;

}  // mbgclock_fasync



static /*HDR*/
#if FLUSH_WITH_LOCK_OWNER_ID
int mbgclock_flush( struct file *filp, fl_owner_t id )
#else
int mbgclock_flush( struct file *filp )
#endif
{
  PCPS_DDEV *pddev = NULL;
  int rc = mbgdrvr_get_pddev( &pddev, filp, "flush" );

  if ( rc < 0 )
    goto out;

  atomic_set( &pddev->data_avail, 0 );

out:
  return rc;

}  // mbgclock_flush



static /*HDR*/
int mbgclock_open( struct inode *inode, struct file *filp )
{
  PCPS_DDEV **ppddev;
  PCPS_DDEV *pddev;
  int minor = iminor( inode );
  int retval = 0;
  _mbg_dbg_hw_lpt_vars

  _mbg_dbg_hw_lpt_set_bit( MBG_BIT_OPEN );

  if ( filp == NULL )
  {
    printk( KERN_WARNING "%s: open minor %i called with file pointer NULL\n",
            pcps_driver_name, minor );
    retval = -EBADF;
    goto out;
  }

  if ( _down_interruptible( &sem_fops, "sem_fops", "open", filp ) < 0 )
  {
    _mbgddmsg_3( MBG_DBG_INFO, "%s: %p open minor %i: interrupted wait for sem_fops",
                 pcps_driver_name, filp, minor );
    retval = -ERESTARTSYS;
    goto out;
  }

  ppddev = ddev_list_locate_minor( minor );

  if ( ppddev == NULL )
    goto out_enodev;

  pddev = *ppddev;

  if ( pddev == NULL )
    goto out_enodev;


  _mbgddmsg_3( MBG_DBG_INFO, "%s: %p open minor %i",
               pcps_driver_name, filp, minor );

  filp->private_data = ppddev;

  atomic_inc( &pddev->open_count );

  _mbgddmsg_4( MBG_DBG_INFO, "%s: %p open: new open count: %i, dev: %p",
               pcps_driver_name, filp, atomic_read( &pddev->open_count ), pddev );

  #if _PCPS_MUST_UPDATE_USE_COUNT
    MOD_INC_USE_COUNT;
  #endif

  goto out_up_sem_fops;


out_enodev:
   retval = -ENODEV;
  _mbgddmsg_3( MBG_DBG_INFO, "%s: %p open failed for minor %i: ENODEV",
               pcps_driver_name, filp, minor );

out_up_sem_fops:
  _up( &sem_fops, "sem_fops", "open", filp );

out:
  _mbg_dbg_hw_lpt_clr_bit( MBG_BIT_OPEN );

  return retval;

}  // mbgclock_open



static /*HDR*/
int mbgclock_release( struct inode *inode, struct file *filp )
{
  PCPS_DDEV *pddev;
  int retval = 0;
  _mbg_dbg_hw_lpt_vars


  _mbg_dbg_hw_lpt_set_bit( MBG_BIT_RELEASE );

  if ( _down_interruptible( &sem_fops, "sem_fops", "release", filp ) < 0 )
  {
    _mbgddmsg_3( MBG_DBG_INFO, "%s: %p release %i: interrupted wait for sem_fops",
                 pcps_driver_name, filp, minor );
    retval = -ERESTARTSYS;
    goto out;  // don't return directly
  }

  // sem_fops must not be released before we're through with pddev !

  pddev = *( (PCPS_DDEV **) filp->private_data );

  if ( pddev == NULL )
  {
    _mbgddmsg_3( MBG_DBG_INFO, "%s: %p release %i: closing with dev NULL",
                 pcps_driver_name, filp, iminor( inode ) );
    retval = -ENODEV;
    goto out_up_sem_fops;
  }

  _mbgddmsg_3( MBG_DBG_INFO, "%s: %p release %i: closing",
               pcps_driver_name, filp, iminor( inode ) );

  if ( atomic_dec_and_test( &pddev->open_count ) )
  {
    if ( get_dev_connected( pddev ) )
      mbgdrvr_disable_cyclic( pddev );
    else
    {
      _mbgddmsg_5( MBG_DBG_INFO, "%s: %p release %i: closing with disconnected dev %s_%s",
                   pcps_driver_name, filp, iminor( inode ),
                   _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      mbgdrvr_delete_device( pddev );
      pddev = NULL;
      retval = -ENODEV;
    }
  }
  else
    _mbgddmsg_6( MBG_DBG_INFO, "%s: %p release %i: new open count: %i, dev %s_%s",
                 pcps_driver_name, filp, iminor( inode ), atomic_read( &pddev->open_count ),
                 _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );

  #if _PCPS_MUST_UPDATE_USE_COUNT
    MOD_DEC_USE_COUNT;
  #endif

  if ( pddev )  // has not been deleted above
  {
    _mbgddmsg_3( MBG_DBG_INFO, "%s: %p release %i calling fasync_helper",
                 pcps_driver_name, filp, iminor( inode ));
    fasync_helper( -1, filp, 0, &pddev->fasyncptr );
  }


out_up_sem_fops:
  _up( &sem_fops, "sem_fops", "release", filp );

out:
  _mbg_dbg_hw_lpt_clr_bit( MBG_BIT_RELEASE );

  return retval;

}  // mbgclock_release



#if DEBUG_LATENCY

static /*HDR*/
long dt( int64_t delta_cyc )
{
  return (long) ( delta_cyc / cpu_khz / 1000 );

}  // dt

#endif



static /*HDR*/
ssize_t mbgclock_read( struct file *filp, char *buffer,
                       size_t count, loff_t *ppos )
{
  PCPS_DDEV *pddev;
  unsigned long flags = 0;
  PCPS_TIME t;
  char timestr[MBG_SIZE_TLG];
  int bytes_to_copy;
  ssize_t ret_val = mbgdrvr_get_pddev( &pddev, filp, ( filp->f_flags & O_NONBLOCK ) ?
                                       "read (non-blocking)" : "read (blocking)" );

  if ( ret_val < 0 )
    goto out;

  _mbgddmsg_2( MBG_DBG_WARN, "%s: %p read starts",
              pcps_driver_name, filp );

  if ( atomic_read( &pddev->open_count ) == 0 )  //##++
  {
    _mbgddmsg_4( MBG_DBG_WARN, "%s: %p read: dev %s_%s not opened",
                 pcps_driver_name, filp, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
    ret_val = -EIO;
    goto out;
  }

  #if !ESPIPE_BY_VFS
    if ( ppos != &filp->f_pos )
    {
      _mbgddmsg_4( MBG_DBG_WARN, "%s: %p read: dev %s_%s past end",
                   pcps_driver_name, filp, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      ret_val = -ESPIPE;
      goto out;
    }
  #endif

  if ( buffer == NULL )
  {
    _mbgddmsg_2( MBG_DBG_WARN, "%s: %p read: no buffer specified",
                 pcps_driver_name, filp );
    ret_val = -EINVAL;
    goto out;
  }

  mbgdrvr_enable_cyclic( pddev, 0 );

  if ( count < sizeof( timestr ) )
    _mbgddmsg_4( MBG_DBG_WARN, "%s: %p read: buffer size (%i) less than required (%i)",
                 pcps_driver_name, filp, (int) count, (int) sizeof( timestr ) );

  _mbgddmsg_2( MBG_DBG_WARN, "%s: %p read: wait for data_avail",
               pcps_driver_name, filp );

  while ( !atomic_read( &pddev->data_avail ) )
  {
    if ( filp->f_flags & O_NONBLOCK )
    {
      _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p read non-blocking returns with no data available, dev: %s_%s",
                   pcps_driver_name, filp, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      ret_val = -EAGAIN;
      goto out;
    }

    #if USE_WAIT_EVENT
      for (;;)
      {
        int dev_connected = 0;
        int rc = wait_event_interruptible_timeout( pddev->wait_queue,
           atomic_read( &pddev->data_avail ) || !(dev_connected = get_dev_connected( pddev ) ), CYCLIC_TIMEOUT );

        if ( rc < 0 )  // interrupted
          goto out_interrupted_wait;

        if ( !dev_connected )  // device has been removed
        {
          _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p read dev %s_%s: device removed while waiting",
                       pcps_driver_name, filp, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
          ret_val = -ERESTARTSYS;
          goto out;
        }

        if ( rc )  // data available, the normal case
          break;

        // timeout, cyclic reads may have been disabled, try to re-enable
        _mbgddmsg_4( MBG_DBG_WARN, "%s: %p read: IRQ timeout, dev %s_%s",
                     pcps_driver_name, filp, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );

        mbgdrvr_enable_cyclic( pddev, 2 );
      }
    #else
      // There may be a race condition if data has become available
      // after the while() check but before we go to sleep below.
      // However, this doesn't really matter for our application.
      interruptible_sleep_on_timeout( &pddev->wait_queue );   // used with 2.4.x and needs to be fixed

      if ( signal_pending( current ) )
        goto out_interrupted_wait;
    #endif
  }


  if ( get_cyclic_lock( pddev, &flags ) < 0 )
    return -ERESTARTSYS;

  t = pddev->t;
  atomic_set( &pddev->data_avail, 0 );

  release_cyclic_lock( pddev, &flags );


  pcps_time_to_time_str( &t, timestr );

  #if DEBUG_LATENCY
    if ( debug > 1 )
    {
      unsigned long long tsc;

      rdtscll( tsc );

      if ( _pcps_ddev_is_usb( pddev ) )
        printk( KERN_INFO "%s %Lu %lu %lu, %lu\n", _pcps_ddev_type_name( pddev ),
                tsc, dt( tsc - tsc_usb_2 ), dt( tsc_usb_2 - tsc_usb_1 ), dt( tsc_usb_1 - tsc_irq_1 ) );
      else
        printk( KERN_INFO "%s %Lu %lu %lu\n", _pcps_ddev_type_name( pddev ),
                tsc, dt( tsc - tsc_irq_2 ), dt( tsc_irq_2 - tsc_irq_1 ) );
    }
  #endif

  bytes_to_copy = _min( count, sizeof( timestr ) - 1 );

  if ( copy_to_user( buffer, timestr, bytes_to_copy ) )
  {
    _mbgddmsg_4( MBG_DBG_WARN, "%s: %p read: unable to copy to user space, dev %s_%s",
                 pcps_driver_name, filp, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
    ret_val = -EFAULT;
    goto out;
  }

  ret_val = bytes_to_copy;
  _mbgddmsg_5( MBG_DBG_WARN, "%s: %p read dev %s_%s: \"%s\"",
               pcps_driver_name, filp, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ), timestr );
  goto out;


out_interrupted_wait:
  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: %p read dev %s_%s: blocking interrupted",
               pcps_driver_name, filp, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
  ret_val = -ERESTARTSYS;

out:
  return ret_val;

}  // mbgclock_read



static /*HDR*/
ssize_t mbgclock_write( struct file *filp, const char *buffer,
                        size_t count, loff_t *ppos )
{
  _mbgddmsg_2( MBG_DBG_WARN, "%s: %p write: not supported",
               pcps_driver_name, filp );

  #if !ESPIPE_BY_VFS
    if ( ppos != &filp->f_pos )
      return -ESPIPE;
  #endif

  return -EIO;

}  // mbgclock_write



static /*HDR*/
int mbgdrvr_ioctl_emu_serial( struct file *filp, unsigned int cmd, unsigned long arg )
{
  _mbgddmsg_3( MBG_DBG_DETAIL, "%s: %p ioctl: emu serial cmd 0x%X",
               pcps_driver_name, filp, cmd );

  switch ( cmd )
  {
    case TCGETS:
    {
      struct termios termios = { 0 };

      /*** Setzen der termios-Werte fuer die Meinberg Funkuhr
         ueber serielle Leitung zur Abfrage. ***/
      termios.c_iflag = IGNBRK|IGNPAR|ISTRIP;   /* input mode flags */
      termios.c_oflag = 0;                      /* output mode flags */
      termios.c_cflag = B9600|CS7|PARENB|CREAD|HUPCL|CLOCAL;  /* control mode flags */
      termios.c_lflag = 0;                      /* local mode flags */
      termios.c_line = 0;                       /* line discipline */

      if ( copy_to_user( (struct termios *) arg, &termios, sizeof( termios ) ) )
      {
        _mbgddmsg_2( MBG_DBG_WARN, "%s: %p ioctl: cmd TCGETS copy_to_user failed",
                     pcps_driver_name, filp );
        return -EFAULT;
      }

      break;
    }


    case TIOCGWINSZ:
    {
      struct winsize winsize = { 0, 0, 0, 0 };

      if ( copy_to_user( (struct winsize *) arg, &winsize, sizeof( winsize ) ) )
      {
        _mbgddmsg_2( MBG_DBG_WARN, "%s: %p ioctl: cmd TIOCGWINSZ copy_to_user failed",
                     pcps_driver_name, filp );
        return -EFAULT;
      }

      break;
    }


    case TCSETS:
    case TCFLSH:
      break;

    default:
      _mbgddmsg_3( MBG_DBG_DETAIL, "%s: %p ioctl: serial IOCTL cmd 0x%X not supported",
                   pcps_driver_name, filp, cmd );
      return -EINVAL;

  }  // switch

  return 0;

}  // mbgdrvr_ioctl_emu_serial



#if DEBUG_IOCTL

static /*HDR*/
void decode_ioctl( const char *s, ulong cmd )
{

  _mbgddmsg_5( MBG_DBG_INFO, "          %s 0x%08lX: type: 0x%02lX, nr: 0x%02lX, size: %lu",
               s, cmd, (ulong) _IOC_TYPE( cmd ), (ulong) _IOC_NR( cmd ), (ulong) _IOC_SIZE( cmd ) );

}  // decode_ioctl

#endif



static /*HDR*/
long mbgclock_unlocked_ioctl( struct file *filp, unsigned int cmd, unsigned long arg )
{
  PCPS_DDEV *pddev = NULL;
  long rc = mbgdrvr_get_pddev( &pddev, filp, "ioctl" );
  int priv_lvl;
  #if defined( DEBUG )
    const char *ioctl_name = get_ioctl_name( cmd );
  #endif

  if ( rc < 0 )
    goto out;

  // Find out which privilege level is required
  // to execute this IOCTL command.
  priv_lvl = ioctl_get_required_privilege( cmd );

  // Check if the calling process has the required privilege.
  switch ( priv_lvl )
  {
    case MBG_REQ_PRIVL_NONE:
      _mbgddmsg_6( MBG_DBG_INFO, "%s: %p %s (0x%02X): no priv lvl required, dev %s_%s",
                   pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      // Always allow.
      break;

    case MBG_REQ_PRIVL_EXT_STATUS:
    case MBG_REQ_PRIVL_CFG_READ:
      _mbgddmsg_6( MBG_DBG_WARN, "%s: %p %s (0x%02X): no priv lvl required to read cfg, dev %s_%s",
                   pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      // This may require some privilege for the calling process.
      // Anyway, always allow for now.
      break;

    case MBG_REQ_PRIVL_CFG_WRITE:
    case MBG_REQ_PRIVL_SYSTEM:
      #if !OMIT_PRIV_CHECKING   // this is the default case
        _mbgddmsg_6( MBG_DBG_WARN, "%s: %p %s (0x%02X): admin rights required, dev %s_%s",
                     pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );

        if ( !capable( CAP_SYS_ADMIN ) )  // allow only if root privileges available.
        {
          _mbgddmsg_6( MBG_DBG_INFO, "%s: %p %s (0x%02X): permission denied, dev %s_%s",
                       pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
          return -EPERM;
        }
      #else
        _mbgddmsg_6( MBG_DBG_WARN, "%s: %p %s (0x%02X): admin rights would be required (checking omitted), dev %s_%s",
                     pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      #endif
      break;

    default:
      // maybe an unknown IOCTL code ...
      // This is OK if it is one of those codes required
      switch ( cmd )
      {
        case TCGETS:
        case TIOCGWINSZ:
        case TCSETS:
        case TCFLSH:
          rc = mbgdrvr_ioctl_emu_serial( filp, cmd, arg );

          if ( rc == 0 )
            goto out;  // has been handled normally

          _mbgddmsg_6( MBG_DBG_WARN, "%s: %p %s (0x%02X): invalid cmd, dev %s_%s",
                       pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
          #if DEBUG_IOCTL
            decode_ioctl( "ioctl", cmd );
          #endif
          break;

        default:
          _mbgddmsg_6( MBG_DBG_INFO, "%s: %p %s (0x%02X): unknown command code, dev %s_%s",
                       pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
          #if DEBUG_IOCTL
            decode_ioctl( "ioctl", cmd );
          #endif
          return -EINVAL;

      }  // switch
  }

  rc = ioctl_switch( pddev, cmd, (void *) arg, (void *) arg );

  // On success we return quickly.

  if ( rc == MBG_SUCCESS )
  {
    _mbgddmsg_6( MBG_DBG_INFO, "%s: %p %s (0x%02X): success, dev %s_%s",
                 pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
    goto out;
  }


  // An error has occurred. 
  // Generate an appropriate debug/error message
  // and return an error status.

  switch ( rc )
  {
    case MBG_ERR_INV_DEV_REQUEST:
      rc = -EINVAL;
      break;


    case MBG_ERR_NOT_SUPP_BY_DEV:
      _mbgddmsg_6( MBG_DBG_WARN, "%s: %p %s (0x%02X): not supported by dev %s_%s",
                   pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      rc = -EIO;
      break;


    case MBG_ERR_NO_MEM:
      _mbgddmsg_6( MBG_DBG_WARN, "%s: %p %s (0x%02X): unable to allocate buffer for dev %s_%s",
                   pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      rc = -EFAULT;
      break;



    case MBG_ERR_IRQ_UNSAFE:
      _mbgddmsg_6( MBG_DBG_DETAIL, "%s: %p %s (0x%02X): busy since unsafe IRQ enabled, dev %s_%s",
                   pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      rc = -EBUSY;
      break;


    case MBG_ERR_COPY_TO_USER:
      _mbgddmsg_6( MBG_DBG_DETAIL, "%s: %p %s (0x%02X): failed to copy data to user space, dev %s_%s",
                   pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      rc = -EFAULT;
      break;


    case MBG_ERR_COPY_FROM_USER:
      _mbgddmsg_6( MBG_DBG_DETAIL, "%s: %p %s (0x%02X): failed to copy data from user space, dev %s_%s",
                   pcps_driver_name, filp, ioctl_name, cmd, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      rc = -EFAULT;
      break;


    default:  // any access error code returned by the low level routine
              // or copying from or to user space
      _mbgddmsg_7( MBG_DBG_WARN, "%s: %p %s (0x%02X): error %li accessing dev %s_%s",
                   pcps_driver_name, filp, ioctl_name, cmd, rc, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      rc = -EFAULT;

  }  // switch error rc


out:
  return rc;

}  // mbgclock_unlocked_ioctl



#if defined( HAVE_COMPAT_IOCTL ) && defined( CONFIG_COMPAT )

static /*HDR*/
long mbgclock_compat_ioctl( struct file *filp, unsigned int cmd, unsigned long arg )
{
  long rc;

  _mbgddmsg_2( MBG_DBG_DETAIL, "%s: %p compat_ioctl calling ioctl()",
               pcps_driver_name, filp );

  rc = mbgclock_unlocked_ioctl( filp, cmd, arg );

  return rc;

}  // mbgclock_compat_ioctl

#endif



#if !defined( HAVE_UNLOCKED_IOCTL )

static /*HDR*/
int mbgclock_ioctl( struct inode *not_used, struct file *filp, unsigned int cmd, unsigned long arg )
{
  long rc;

  _mbgddmsg_2( MBG_DBG_DETAIL, "%s: %p unlocked_ioctl calling ioctl()",
               pcps_driver_name, filp );

  rc = mbgclock_unlocked_ioctl( filp, cmd, arg );

  return (int) rc;

}  // mbgclock_ioctl

#endif



static /*HDR*/
int mbgclock_mmap( struct file * filp, struct vm_area_struct *vma )
{
  MBG_MEM_ADDR addr;
  PCPS_DDEV *pddev = NULL;
  int rc = mbgdrvr_get_pddev( &pddev, filp, "mmap" );

  if ( rc < 0 )
    goto out;

  addr = pddev->rsrc_info.mem[0].start;

#if VMA_HAS_VM_PGOFF
  if ( ( ( vma->vm_end - vma->vm_start ) != PAGE_SIZE ) || vma->vm_pgoff )
#else
  if ( ( ( vma->vm_end - vma->vm_start ) != PAGE_SIZE ) )
#endif
  {
    printk( KERN_ERR "%s: vm_end (0x%08lX) - vm_start (0x%08lX) doesn't match PAGE_SIZE (0x%08lX)\n",
            pcps_driver_name, vma->vm_end, vma->vm_start, (unsigned long) PAGE_SIZE );
    rc = -EINVAL;
    goto out;
  }

  #if VMA_HAS_VM_PGOFF
    _mbgddmsg_5( MBG_DBG_DETAIL,
                 "%s: vm_end (0x%08lX) - vm_start (0x%08lX) == PAGE_SIZE (0x%08lX), pg_off: 0x%08lX",
                 pcps_driver_name, vma->vm_end, vma->vm_start, (unsigned long) PAGE_SIZE, vma->vm_pgoff );
  #else
    _mbgddmsg_4( MBG_DBG_DETAIL, "%s: vm_end (0x%08lX) - vm_start (0x%08lX) == PAGE_SIZE (0x%08lX)",
                 pcps_driver_name, vma->vm_end, vma->vm_start, (unsigned long) PAGE_SIZE );
  #endif

  vma->vm_flags |= VM_IO;

  #if defined( pgprot_noncached )
    vma->vm_page_prot = pgprot_noncached( vma->vm_page_prot );
  #endif

  #if _PCPS_HAS_REMAP_PFN
    rc = io_remap_pfn_range( vma, vma->vm_start, addr >> PAGE_SHIFT, PAGE_SIZE, vma->vm_page_prot );
  #else
    rc = io_remap_page_range( vma, vma->vm_start, addr, PAGE_SIZE, vma->vm_page_prot );
  #endif

  if ( rc )
  {
    rc = -EAGAIN;
    goto out;
  }

  rc = 0;

out:
  return rc;

}  // mbgclock_mmap



struct file_operations mbgclock_fops =
{
  #if NEW_FILE_OPS
    owner: THIS_MODULE,
  #endif

  read: mbgclock_read,
  write: mbgclock_write,
  poll: mbgclock_poll,
  #if defined( HAVE_UNLOCKED_IOCTL )
    unlocked_ioctl: mbgclock_unlocked_ioctl,
  #else
    ioctl: mbgclock_ioctl,
  #endif
  #if defined( HAVE_COMPAT_IOCTL ) && defined( CONFIG_COMPAT )
    compat_ioctl: mbgclock_compat_ioctl,  // called if a 32 bit app ioctls a 64 bit driver
  #endif
  open: mbgclock_open,
  flush: mbgclock_flush,
  release: mbgclock_release,
  fasync: mbgclock_fasync,
  mmap: mbgclock_mmap,
  llseek: NULL
};



#if _PCPS_USE_PCI_PNP

static /*HDR*/
int __devinit mbgdrvr_create_device( PCPS_DDEV *pddev )
{
  char ws[256];
  int n;
  int rc;
  #if _PCPS_USE_LINUX_CHRDEV
    int dev_idx;
    dev_t dev;
  #endif

  _mbgddmsg_3( MBG_DBG_INIT_DEV, "%s: entering mbgdrvr_create_device() for %s_%s",
               pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );


  #if _PCPS_USE_LINUX_CHRDEV
    dev_idx = ddev_list_add_entry( pddev );

    if ( dev_idx < 0 )
    {
      printk( KERN_WARNING "%s: didn't find free device list entry\n",
              pcps_driver_name );
      goto fail;
    }

    dev = MKDEV( major, minor + dev_idx );
    pddev->lx_dev = dev;

    cdev_init( &pddev->cdev, &mbgclock_fops );
    pddev->cdev.owner = THIS_MODULE;

    rc = cdev_add( &pddev->cdev, dev, 1 );

    if ( rc )
    {
      _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: failed to add chrdev, index %d",
                   pcps_driver_name, dev_idx );
      goto fail;
    }

    _mbgddmsg_4( MBG_DBG_INIT_DEV, "%s: successfully registered chrdev %d:%d, index %d",
                 pcps_driver_name, MAJOR( pddev->cdev.dev ), MINOR( pddev->cdev.dev ), dev_idx );

    #if _PCPS_HAVE_LINUX_CLASS
      if ( !IS_ERR( mbgclock_class ) )
      {
        #if _PCPS_CLASS_DEV_OBSOLETED
          struct device *device;
          device = device_create( mbgclock_class, NULL, dev,
                                  #if _PCPS_DEVICE_CREATE_WITH_DEV_DATA
                                    pddev,
                                  #endif
                                  mbg_clk_dev_node_fmt, minor + dev_idx );
        #elif _PCPS_HAVE_LINUX_CLASS_CREATE
          struct class_device *device;
          device = class_device_create( mbgclock_class,
                                        #if _PCPS_CLASS_DEVICE_CREATE_WITH_PARENT
                                          NULL,
                                        #endif
                                        dev, NULL, mbg_clk_dev_node_fmt, minor + dev_idx );
        #elif _PCPS_HAVE_LINUX_CLASS_SIMPLE
          struct class_device *device;
          device = class_simple_device_add( mbgclock_class, dev, NULL, mbg_clk_dev_node_fmt, minor + dev_idx );
        #endif

        if ( IS_ERR( device ) )
        {
          printk( KERN_WARNING "%s: failed to create device for %s_%s, errno: %li\n",
                  pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ),
                  PTR_ERR( device ) );
          goto fail;
        }
      }
    #endif

  #elif _PCPS_USE_LINUX_MISC_DEV

    pddev->mdev.minor = MISC_DYNAMIC_MINOR;
    pddev->mdev.name = mbgclock_name;
    pddev->mdev.fops = &mbgclk_fops;
    #if 0  //##++
      struct list_head list;
      struct device *device;
      struct class_device *class;
      char devfs_name[64];
    #endif
    #error Misc devices not supported at this stage.
    rc = misc_register( &pddev->mdev );

    if ( rc )
    {
      _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: failed to register misc device",
                  pcps_driver_name );
      goto fail;
    }

    _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: registered misc device, minor %d",
                pcps_driver_name,
                pddev->mdev.minor
              );
  #endif

  #if _USE_LINUX_DEVFS
    devfs_mk_cdev( MKDEV( pddev->major, 0 ),
                   S_IFCHR | S_IRUSR | S_IWUSR, mbgclock_name );
  #endif

  drvr_info.n_devs++;

  n = snprintf( ws, sizeof( ws ), "found %s, S/N %s",
                _pcps_ddev_fw_id( pddev ), _pcps_ddev_sernum( pddev ) );

  if ( _pcps_ddev_port_base( pddev, 0 ) )
  {
    n += snprintf( &ws[n], sizeof( ws ) - n,
                   ", port %03lX", (ulong) _pcps_ddev_port_base( pddev, 0 ) );

    if ( _pcps_ddev_port_base( pddev, 1 ) )
      n += snprintf( &ws[n], sizeof( ws ) - n,
                     ",%03lX", (ulong) _pcps_ddev_port_base( pddev, 1 ) );
  }

  if ( pddev->rsrc_info.num_rsrc_irq )
    n += snprintf( &ws[n], sizeof( ws ) - n,
                   ", irq %i", _pcps_ddev_irq_num( pddev ) );

  printk( KERN_INFO "%s: %s\n", pcps_driver_name, ws );

  if ( pddev->irq_stat_info & PCPS_IRQ_STAT_UNSAFE )
    printk( KERN_WARNING "%s: *** warning: %s IRQ support unsafe with FW v%u.%02u and ASIC v%u.%02u\n",
            pcps_driver_name, _pcps_ddev_type_name( pddev ),
            _pcps_fw_rev_num_major( _pcps_ddev_fw_rev_num( pddev ) ),
            _pcps_fw_rev_num_minor( _pcps_ddev_fw_rev_num( pddev ) ),
            _pcps_asic_version_major( _pcps_ddev_asic_version( pddev ) ),
            _pcps_asic_version_minor( _pcps_ddev_asic_version( pddev ) )
          );

  #if NEW_WAIT_QUEUE
    init_waitqueue_head( &pddev->wait_queue );
  #else
    pddev->wait_queue = NULL;
  #endif

#if 0  //##++++++++++
  pddev->remove_lock = ATOMIC_INIT( 0 );
  pddev->access_in_progress = ATOMIC_INIT( 0 );
  pddev->data_avail = ATOMIC_INIT( 0 );
#endif

  #if _PCPS_USE_USB
    _sema_init_pddev( &pddev->sem_usb_cyclic, 1, "sem_usb_cyclic", "create dev", pddev );
  #endif

  if ( default_fast_hr_time_pddev == NULL )
    if ( _pcps_ddev_has_fast_hr_timestamp( pddev ) )
    {
      default_fast_hr_time_pddev = pddev;
      _mbgddmsg_3( MBG_DBG_INIT_DEV, "%s: made %s_%s the default device for MM access",
                   pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
    }

  if ( default_ucap_pddev == NULL )
    if ( _pcps_ddev_has_ucap( pddev ) )
    {
      default_ucap_pddev = pddev;
      _mbgddmsg_3( MBG_DBG_INIT_DEV, "%s: made %s_%s the default device for user capture support",
                   pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
    }

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: leaving mbgdrvr_create_device() without error",
               pcps_driver_name );

  return 0;

fail:
  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: leaving mbgdrvr_create_device() with error",
               pcps_driver_name );

  return -1;

}  // mbgdrvr_create_device



// Applying the _devexit attribute to the function below causes a linker warning
// since the function could also be called from outside the exit section.

static /*HDR*/
void mbgdrvr_delete_device( PCPS_DDEV *pddev )
{
  if ( pddev )
  {
    _mbgddmsg_3( MBG_DBG_INIT_DEV, "%s: entering mbgdrvr_delete_device() for %s, S/N %s",
                 pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );

    if ( pddev == default_fast_hr_time_pddev )
    {
      _mbgddmsg_3( MBG_DBG_INIT_DEV, "%s: removing %s_%s as default device for MM access",
                   pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      default_fast_hr_time_pddev = NULL;
    }

    if ( pddev == default_ucap_pddev )
    {
      _mbgddmsg_3( MBG_DBG_INIT_DEV, "%s: removing %s_%s as default device for ucap events",
                   pcps_driver_name, _pcps_ddev_type_name( pddev ), _pcps_ddev_sernum( pddev ) );
      default_ucap_pddev = NULL;
    }

    #if _USE_LINUX_DEVFS
      //##++ devfs_mk_cdev( MKDEV( pddev->major, 0 ),
      //               S_IFCHR | S_IRUSR | S_IWUSR, mbgclock_name );
    #endif

    #if _PCPS_USE_LINUX_CHRDEV

      cdev_del( &pddev->cdev );

      #if _PCPS_HAVE_LINUX_CLASS
        if ( !IS_ERR( mbgclock_class ) )
        {
          #if _PCPS_CLASS_DEV_OBSOLETED
            device_destroy( mbgclock_class, pddev->lx_dev );
          #elif _PCPS_HAVE_LINUX_CLASS_CREATE
            class_device_destroy( mbgclock_class, pddev->lx_dev );
          #elif _PCPS_HAVE_LINUX_CLASS_SIMPLE
            class_simple_device_remove( pddev->lx_dev );
          #endif

          _mbgddmsg_3( MBG_DBG_INIT_DEV, "%s: destroyed class device %d:%d",
                      pcps_driver_name,
                      MAJOR( pddev->lx_dev ), MINOR( pddev->lx_dev ) );
        }
      #endif

    #elif _PCPS_USE_LINUX_MISC_DEV
      _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: deregistering misc device %X",
                  pcps_driver_name,
                  pci_dev->device );
      misc_deregister( &pddev->mdev );
    #endif

    pcps_cleanup_device( pddev );
    pcps_free_ddev( pddev );

    ddev_list_remove_entry( pddev );

    if ( drvr_info.n_devs )
      drvr_info.n_devs--;
  }
  else
  {
    _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: entering mbgdrvr_delete_device() with dev NULL",
                 pcps_driver_name );
  }

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: leaving mbgdrvr_delete_device()", pcps_driver_name );

}  // mbgdrvr_delete_device



#if _PCPS_USE_ISA && !_PCPS_USE_ISA_PNP  //##++ this needs cleanup

static /*HDR*/
int __devinit mbgdrvr_add_isa_device( PCPS_DDEV *pddev )
{
  int rc = mbgdrvr_create_device( pddev );

  if ( rc >= 0 )
    set_dev_connected( pddev, 1 );

  return rc;

}  // mbgdrvr_add_isa_device

#endif



static /*HDR*/
int __devinit mbgclock_probe_pci_device( struct pci_dev *pci_dev,
                                         const struct pci_device_id *ent )
{
  PCPS_DDEV *pddev = NULL;
  int rc;
  int i;

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: entering mbgclock_probe_pci_device()",
               pcps_driver_name
             );

  rc = pci_enable_device( pci_dev );

  if ( rc )
  {
    printk( KERN_ERR "%s: failed to enable PCI device %04X, I/O %04lX: rc = %i\n",
            pcps_driver_name,
            pci_dev->device,
            (ulong) pci_resource_start( pci_dev, 0 ),
            rc
          );
    goto fail;
  }

  _mbgddmsg_3( MBG_DBG_INIT_DEV, "%s: init PCI device %04X at %04lX",
               pcps_driver_name,
               pci_dev->device,
               (ulong) pci_resource_start( pci_dev, 0 )
             );

  // Get address of unused driver device structure.
  pddev = pcps_alloc_ddev();

  if ( pddev == NULL )
  {
    rc = -ENOMEM;
    goto fail;
  }

  rc = pcps_init_ddev( pddev, PCPS_BUS_PCI, pci_dev->device );

  if ( rc != PCPS_SUCCESS )
  {
    rc = -ENODEV;
    goto fail;
  }

  for ( i = 0; i < 5; i++ )
  {
    ulong flags = pci_resource_flags( pci_dev, i );

    if ( flags & IORESOURCE_IO )
      pcps_add_rsrc_io( pddev, pci_resource_start( pci_dev, i ), pci_resource_len( pci_dev, i ) );
    else
      if ( flags & IORESOURCE_MEM )
        pcps_add_rsrc_mem( pddev, pci_resource_start( pci_dev, i ), pci_resource_len( pci_dev, i ) );
  }

  pcps_add_rsrc_irq( pddev, pci_dev->irq );

  rc = pcps_start_device( pddev, pci_dev->bus->number, pci_dev->devfn );

  if ( rc != PCPS_SUCCESS )
  {
    rc = -EIO;
    goto fail;
  }

  pci_set_drvdata( pci_dev, pddev );

  rc = mbgdrvr_create_device( pddev );

  if ( rc < 0 )
    goto fail;


  set_dev_connected( pddev, 1 );

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: leaving mbgclock_probe_pci_device() without error",
               pcps_driver_name );

  return 0;

fail:
  if ( pddev )
    pcps_free_ddev( pddev );

  _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: leaving mbgclock_probe_pci_device() with error %i",
               pcps_driver_name, rc );

  return rc;

}  // mbgclock_probe_pci_device



static /*HDR*/
void __devexit mbgclock_remove_pci_device( struct pci_dev *pci_dev )
{
  PCPS_DDEV *pddev = (PCPS_DDEV *) pci_get_drvdata( pci_dev );

  _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: removing PCI device %04X",
               pcps_driver_name,
               pci_dev->device
             );

  set_dev_connected( pddev, 0 );

  mbgdrvr_delete_device( pddev );

  pci_set_drvdata( pci_dev, NULL );

}  // mbgclock_remove_pci_device



static struct pci_device_id mbgclock_pci_tbl[] __devinitdata =
{
  { PCI_VENDOR_MEINBERG, PCI_ANY_ID, PCI_ANY_ID, PCI_ANY_ID },
  { 0 }
};

MODULE_DEVICE_TABLE( pci, mbgclock_pci_tbl );

static struct pci_driver mbgclock_pci_driver =
{
  name:      MBG_DRVR_NAME,
  id_table:  mbgclock_pci_tbl,
  probe:     mbgclock_probe_pci_device,
  remove:    __devexit_p( mbgclock_remove_pci_device )
};

#endif  // _PCPS_USE_PCI_PNP



#if _PCPS_USE_USB

static /*HDR*/
int __devinit mbgclock_probe_usb_device( struct usb_interface *pintf,
                                         const struct usb_device_id *ent )
{
  PCPS_DDEV **ppddev = NULL;
  PCPS_DDEV *pddev = NULL;
  PCPS_DEV_ID dev_id;
  int rc;
  struct usb_device *usb_device;

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: entering mbgclock_probe_usb_device()",
               pcps_driver_name
             );

  if ( _down_interruptible( &sem_fops, "sem_fops", "probe_usb_device", pintf ) < 0 )
  {
    rc = -ERESTARTSYS;
    goto fail;
  }

  usb_device = interface_to_usbdev( pintf );
  dev_id = le16_to_cpu( usb_device->descriptor.idProduct );

  // search list if device already exists!

  #if STRUCT_USB_DEVICE_HAS_SERIAL
    ppddev = ddev_list_locate_device( PCPS_BUS_USB, dev_id, usb_device->serial );
  #elif STRUCT_USB_DEVICE_HAS_STATIC_SERIAL
    ppddev = ddev_list_locate_device( PCPS_BUS_USB, dev_id, usb_device->static_serial );
  #else
    if ( usb_device->descriptor.iSerialNumber )
    {
      char buf[128];

      if ( usb_string( usb_device, usb_device->descriptor.iSerialNumber, buf, sizeof( buf ) ) > 0 )
        ppddev = ddev_list_locate_device( PCPS_BUS_USB, dev_id, buf );
    }
  #endif

  if ( ppddev )
    pddev = *ppddev;
  else
    pddev = pcps_alloc_ddev();

  if ( pddev == NULL )
  {
    rc = -ENOMEM;
    goto fail_free_up_sem_fops;
  }

  pddev->udev = usb_device;

  rc = pcps_init_ddev( pddev, PCPS_BUS_USB, dev_id );

  if ( rc != PCPS_SUCCESS )
  {
    rc = -ENODEV;
    goto fail_free_up_sem_fops;
  }

  pddev->intf = pintf;

  usb_set_intfdata( pintf, pddev );
  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: called usb_set_intfdata()",
               pcps_driver_name
             );

  // no resources to add

  rc = pcps_start_device( pddev, 0, 0 );

  if ( rc != PCPS_SUCCESS )
  {
    rc = -EIO;
    goto fail_free_up_sem_fops;
  }

  set_dev_connected( pddev, 1 );

  if ( ppddev == NULL )  // device did not exist before
  {
    rc = mbgdrvr_create_device( pddev );

    if ( rc < 0 )
      goto fail_free_up_sem_fops;
  }

  // If the device has been "recycled" and is still opened
  // by an application then we re-enable cyclic interrupts
  if ( atomic_read( &pddev->open_count ) )
    mbgdrvr_enable_cyclic( pddev, 1 );

  _up_pddev( &sem_fops, "sem_fops", "probe_usb_device", pddev );

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: leaving mbgclock_probe_usb_device() without error",
               pcps_driver_name );

  return 0;

fail_free_up_sem_fops:
  if ( pddev )
    pcps_free_ddev( pddev );

  _up_pddev( &sem_fops, "sem_fops", "probe_usb_device (err)", NULL );

fail:
  _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: leaving mbgclock_probe_usb_device() with error %i",
               pcps_driver_name, rc );
  return rc;

}  // mbgclock_probe_usb_device



static /*HDR*/
void  __devexit mbgclock_remove_usb_device( struct usb_interface *intf )
{
  PCPS_DDEV *pddev = (PCPS_DDEV *) usb_get_intfdata( intf );

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: entering mbgclock_remove_usb_device()",
               pcps_driver_name );

  set_dev_connected( pddev, 0 );

  _down( &sem_fops, "sem_fops", "remove_usb_device", NULL );

  if ( atomic_read( &pddev->open_count ) )
  {
    _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: USB remove: calling wake_up_interruptible",
                 pcps_driver_name );
    wake_up_interruptible( &pddev->wait_queue );
  }

  if ( atomic_read( &pddev->open_count) == 0 )
  {
    _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: USB remove: wait for outstanding requests",
               pcps_driver_name );
    _down( &pddev->dev_mutex, "dev_mutex", "remove_usb_device", NULL );

    _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: USB remove: delete USB device",
                pcps_driver_name );
    mbgdrvr_delete_device( pddev );
    usb_set_intfdata( intf, NULL );
  }

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: leaving mbgclock_remove_usb_device()",
               pcps_driver_name );

  _up( &sem_fops, "sem_fops", "remove_usb_device", NULL );

}  // mbgclock_remove_usb_device



static struct usb_device_id mbgclock_usb_tbl[] __devinitdata =
{
  // A wildcard product ID for USB devices does not seem to be supported
  // by the kernel, so we have to specify each supported device explicitely:
  { USB_DEVICE( USB_VENDOR_MEINBERG, USB_DEV_USB5131 ) },
  { USB_DEVICE( USB_VENDOR_MEINBERG, USB_DEV_TCR51USB ) },
  { USB_DEVICE( USB_VENDOR_MEINBERG, USB_DEV_MSF51USB ) },
  { USB_DEVICE( USB_VENDOR_MEINBERG, USB_DEV_WWVB51USB ) },
  { USB_DEVICE( USB_VENDOR_MEINBERG, USB_DEV_DCF600USB ) },
  { USB_DEVICE( USB_VENDOR_MEINBERG, USB_DEV_TCR600USB ) },
  { USB_DEVICE( USB_VENDOR_MEINBERG, USB_DEV_MSF600USB ) },
  { USB_DEVICE( USB_VENDOR_MEINBERG, USB_DEV_WVB600USB ) },
  { 0 }
};

MODULE_DEVICE_TABLE( usb, mbgclock_usb_tbl );

static struct usb_driver mbgclock_usb_driver =
{
  name:        MBG_DRVR_NAME,
  id_table:    mbgclock_usb_tbl,
  probe:       mbgclock_probe_usb_device,
  disconnect:  mbgclock_remove_usb_device
};

#endif  // _PCPS_USE_USB



#ifdef MODULE

// Applying the _exit attribute to the function below causes a linker warning
// since the function could also be called from the module init function.

 /*HDR*/
void mbgclock_cleanup_module( void )
{
  int i;

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: entering mbgclock_cleanup_module()",
               pcps_driver_name );

  #if _PCPS_USE_PNP
    #if _PCPS_USE_PCI_PNP
      pci_unregister_driver( &mbgclock_pci_driver );
      _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: PCI driver has been unregistered",
                   pcps_driver_name );
    #endif

    #if _PCPS_USE_USB
      usb_deregister( &mbgclock_usb_driver );
      _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: USB driver has been unregistered",
                   pcps_driver_name );
    #endif
  #endif

  // Stop and remove all devices which are still active (maybe ISA cards)
  for ( i = 0; i < max_devs; i++ )
  {
    PCPS_DDEV **ppddev = &ddev_list[i];

    if ( *ppddev )
    {
      _mbgddmsg_3( MBG_DBG_INIT_DEV, "%s: removing device %s, S/N %s", pcps_driver_name,
                   _pcps_ddev_type_name( *ppddev ), _pcps_ddev_sernum( *ppddev ) );
      mbgdrvr_delete_device( *ppddev );
    }
  }

  #if _PCPS_USE_LINUX_CHRDEV
    unregister_chrdev_region( MKDEV( major, minor ), max_devs );
    _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: chrdev device numbers have been unregistered",
                 pcps_driver_name );

    ddev_list_free();
  #endif

  #if _PCPS_HAVE_LINUX_CLASS
    if ( !IS_ERR( mbgclock_class ) )
    {
      #if _PCPS_HAVE_LINUX_CLASS_CREATE
        class_destroy( mbgclock_class );
      #elif _PCPS_HAVE_LINUX_CLASS_SIMPLE
        class_simple_destroy( mbgclock_class );
      #endif

      _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: class %s destroyed",
                   pcps_driver_name, mbgclock_class_name );
    }
  #endif

  printk( KERN_INFO "%s: Meinberg radio clock driver unloading.\n",
          pcps_driver_name );

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: leaving mbgclock_cleanup_module()",
               pcps_driver_name );

}  // mbgclock_cleanup_module

#endif



 /*HDR*/
int __init mbgclock_init_module( void )
{
  int rc = 0;


  #if _PCPS_USE_PCI_PNP
    static const char info[] = "(PNP)";
  #else
    static const char info[] = "(non-PNP)";
  #endif

  #ifdef EXPORT_NO_SYMBOLS
    EXPORT_NO_SYMBOLS;
  #endif

  #ifdef DEBUG
    debug = DEBUG;
  #endif

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: entering mbgclock_init_module()",
               pcps_driver_name );

  printk( KERN_INFO "%s: Meinberg radio clock driver v%u.%u.%u %s loading.\n",
          pcps_driver_name,
          MBG_MAJOR_VERSION_CODE,
          MBG_MINOR_VERSION_CODE,
          MBG_MICRO_VERSION_CODE,
          info
        );

  printk( KERN_INFO "%s: %s\n", pcps_driver_name, MBG_COPYRIGHT );

  #ifdef DEBUG
    printk( KERN_INFO "%s: debug level = %i\n", pcps_driver_name, debug );
  #endif

  #if DEBUG_SYS_IRQS
    list_system_irqs();
  #endif

  _sema_init_pddev( &sem_fops, 1, "sem_fops", "init_module", NULL );

  #if _PCPS_USE_LINUX_CHRDEV
  {
    dev_t dev;

    // Note: In early 2.6.x kernels the functions alloc_chrdev_region()
    // and register_chrdev_region() expected (char *) rather than
    // (const char *) for the device name. Thus we cast mbgclock_name
    // to (char *) below in order to avoid compiler warnings.

    if ( major )  //##++ != DYNAMIC_MAJOR ?
    {
      dev = MKDEV( major, minor );
      rc = register_chrdev_region( dev, max_devs, (char *) mbgclock_name );  // see note above

      if ( rc < 0 )
      {
        printk( KERN_WARNING "%s: failed to register major %d\n",
                pcps_driver_name, major );
        goto fail;
      }
    }
    else
    {
      rc = alloc_chrdev_region( &dev, minor, max_devs, (char *) mbgclock_name );  // see note above

      if ( rc < 0 )
      {
        printk( KERN_WARNING "%s: failed to allocate dynamic major %d\n",
                pcps_driver_name, major );
        goto fail;
      }

      major = MAJOR( dev );
    }

    _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: successfully registered chrdev, major %d",
                 pcps_driver_name, major );

    #if _PCPS_HAVE_LINUX_CLASS
      #if _PCPS_HAVE_LINUX_CLASS_CREATE
        mbgclock_class = class_create( THIS_MODULE, mbgclock_class_name );
      #elif _PCPS_HAVE_LINUX_CLASS_SIMPLE
        mbgclock_class = class_simple_create( THIS_MODULE, mbgclock_class_name );
      #endif

      if ( !IS_ERR( mbgclock_class ) )
      {
        _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: class %s created successfully",
                    pcps_driver_name, mbgclock_class_name );
      }
      else
        printk( KERN_WARNING "%s: failed to create class %s, no UDEV support\n",
                pcps_driver_name, mbgclock_class_name );
    #endif

    rc = ddev_list_alloc();

    if ( rc < 0 )
    {
      printk( KERN_WARNING "%s: failed to allocate device list\n",
              pcps_driver_name );

      goto fail_with_cleanup;
    }
  }
  #endif

  #if _USE_LINUX_DEVFS
    #error devfs support needs cleanup!!
    devfs_mk_cdev( MKDEV( pddev->major, 0 ),
                  S_IFCHR | S_IRUSR | S_IWUSR, mbgclock_name );
  #endif

  #if _PCPS_USE_PNP
    #if _PCPS_USE_ISA && !_PCPS_USE_ISA_PNP  //##++ this needs cleanup
      pcps_detect_isa_clocks( pcps_alloc_ddev, pcps_free_ddev, mbgdrvr_add_isa_device, io, irq );
    #endif

    #if _PCPS_USE_PCI_PNP
      rc = pci_register_driver( &mbgclock_pci_driver );

      _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: done registering PCI devices, rc: %d",
                   pcps_driver_name, rc );
    #endif  // _PCPS_USE_PCI_PNP

    #if _PCPS_USE_USB  //##++
      rc = usb_register( &mbgclock_usb_driver );

      _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: done registering USB devices, rc: %d",
                   pcps_driver_name, rc );
    #endif   // _PCPS_USE_USB

  #else
    pcps_detect_clocks( io, irq );
  #endif


  if ( drvr_info.n_devs == 0 )
  {
    printk( KERN_INFO "%s: no supported device found.\n", pcps_driver_name );
    rc = -ENODEV;
    goto fail_with_cleanup;
  }

  #if 0 && _PCPS_USE_ISA  //##+++++
  {
    int i;

    for ( i = 0; i < n_ddevs; i++ )
    {
      PCPS_DDEV *pddev = &pcps_ddev[i];

      printk( KERN_INFO "%s: ", pcps_driver_name );

      if ( n_ddevs > 1 )
        printk( "dev #%i: ", i );

      printk( "\n" );
    }
  }
  #endif  // PCPS_USE_ISA

  if ( pretend_sync )
    printk( KERN_INFO "%s: pretending to NTP to be always sync'ed\n", pcps_driver_name );

  _mbgddmsg_1( MBG_DBG_INIT_DEV, "%s: leaving mbgclock_init_module() without error",
               pcps_driver_name );
  return 0;


fail_with_cleanup:
  mbgclock_cleanup_module();

fail:
  _mbgddmsg_2( MBG_DBG_INIT_DEV, "%s: leaving mbgclock_init_module() with error %i",
               pcps_driver_name, rc );
  return rc;

}  // mbgclock_init_module



#ifdef module_init
  module_init( mbgclock_init_module );
  module_exit( mbgclock_cleanup_module );
#endif



/*HDR*/
/**
    Read a high resolution ::PCPS_TIME_STAMP structure via memory mapped access.
    This function can be called from other kernel drivers and reads the timestamp
    from the first device registered by the driver which supports this call.

    @param *p_ts Pointer to a ::PCPS_TIME_STAMP structure to be filled up

    @return ::MBG_SUCCESS on success, or MBG_ERR_NOT_SUPP_BY_DEV if no device
            supports this call.

    @see mbgclock_default_get_fast_hr_timestamp_cycles()
*/
int mbgclock_default_get_fast_hr_timestamp( PCPS_TIME_STAMP *p_ts )
{
  if ( default_fast_hr_time_pddev == NULL )
    return MBG_ERR_NOT_SUPP_BY_DEV;

  _mbgddmsg_1( MBG_DBG_DETAIL, "%s: entering mbgclock_default_get_fast_hr_timestamp",
               pcps_driver_name );

  do_get_fast_hr_timestamp_safe( default_fast_hr_time_pddev, p_ts );

  _mbg_swab_pcps_time_stamp( p_ts );

  _mbgddmsg_1( MBG_DBG_DETAIL, "%s: leaving mbgclock_default_get_fast_hr_timestamp",
               pcps_driver_name );

  return MBG_SUCCESS;

}  // mbgclock_default_get_fast_hr_timestamp

EXPORT_SYMBOL( mbgclock_default_get_fast_hr_timestamp );



/*HDR*/
/**
    Read a high resolution ::PCPS_TIME_STAMP_CYCLES structure via memory mapped access.
    This function can be called from other kernel drivers and reads the timestamp
    from the first device registered by the driver which supports this call, plus
    an associated cycles counter which can be used to determine the latency.

    @param *p_ts_cyc Pointer to a ::PCPS_TIME_STAMP_CYCLES structure to be filled up

    @return ::MBG_SUCCESS on success, or MBG_ERR_NOT_SUPP_BY_DEV if no device
            supports this call.

    @see mbgclock_default_get_fast_hr_timestamp()
*/
int mbgclock_default_get_fast_hr_timestamp_cycles( PCPS_TIME_STAMP_CYCLES *p_ts_cyc )
{
  if ( default_fast_hr_time_pddev == NULL )
    return MBG_ERR_NOT_SUPP_BY_DEV;

  _mbgddmsg_1( MBG_DBG_DETAIL, "%s: entering mbgclock_default_get_fast_hr_timestamp_cycles",
               pcps_driver_name );

  do_get_fast_hr_timestamp_cycles_safe( default_fast_hr_time_pddev, p_ts_cyc );

  _mbg_swab_pcps_time_stamp_cycles( p_ts_cyc );

  _mbgddmsg_1( MBG_DBG_DETAIL, "%s: leaving mbgclock_default_get_fast_hr_timestamp_cycles",
               pcps_driver_name );

  return MBG_SUCCESS;

}  // mbgclock_default_get_fast_hr_timestamp_cycles

EXPORT_SYMBOL( mbgclock_default_get_fast_hr_timestamp_cycles );



/*HDR*/
/**
    Clear the user capture FIFO buffer on the first device registered
    by the driver which supports this call.

    @return ::MBG_SUCCESS on success, or
            MBG_ERR_NOT_SUPP_BY_DEV if no device supports this call, or
            MBG_ERR_IRQ_UNSAFE called on a device where such calls are unsafe
            if IRQs are enabled.

    @see mbgclock_default_get_ucap_entries()
    @see mbgclock_default_get_ucap_event()
*/
int mbgclock_default_clr_ucap_buff( void )
{
  int rc;

  if ( default_ucap_pddev == NULL )
    return MBG_ERR_NOT_SUPP_BY_DEV;

  _mbgddmsg_1( MBG_DBG_DETAIL, "%s: entering mbgclock_default_clr_ucap_buff",
               pcps_driver_name );

  _pcps_sem_inc_safe( default_ucap_pddev );
  rc = _pcps_write_byte( default_ucap_pddev, PCPS_CLR_UCAP_BUFF );
  _pcps_sem_dec( default_ucap_pddev );

  _mbgddmsg_2( MBG_DBG_DETAIL, "%s: leaving mbgclock_default_clr_ucap_buff, rc: %i",
               pcps_driver_name, rc );

  return rc;

err_busy_unsafe:
  return MBG_ERR_IRQ_UNSAFE;

}  // mbgclock_default_clr_ucap_buff

EXPORT_SYMBOL( mbgclock_default_clr_ucap_buff );



/*HDR*/
/**
    Read a ::PCPS_UCAP_ENTRIES structure to retrieve the number of saved
    user capture events and the maximum capture buffer sizefrom the first
    device registered by the driver which supports this call.

    @return ::MBG_SUCCESS on success, or
            MBG_ERR_NOT_SUPP_BY_DEV if no device supports this call, or
            MBG_ERR_IRQ_UNSAFE called on a device where such calls are unsafe
            if IRQs are enabled.

    @see mbgclock_default_clr_ucap_buff()
    @see mbgclock_default_get_ucap_event()
*/
int mbgclock_default_get_ucap_entries( PCPS_UCAP_ENTRIES *p )
{
  int rc;

  if ( default_ucap_pddev == NULL )
    return MBG_ERR_NOT_SUPP_BY_DEV;

  _mbgddmsg_1( MBG_DBG_DETAIL, "%s: entering mbgclock_default_get_ucap_entries",
               pcps_driver_name );

  _pcps_sem_inc_safe( default_ucap_pddev );
  rc = _pcps_read_var( default_ucap_pddev, PCPS_GIVE_UCAP_ENTRIES, *p );
  _pcps_sem_dec( default_ucap_pddev );

  _mbg_swab_pcps_ucap_entries( p );

  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: leaving mbgclock_default_get_ucap_entries: %u/%u, rc: %i",
               pcps_driver_name, p->used, p->max, rc );

  return rc;

err_busy_unsafe:
  return MBG_ERR_IRQ_UNSAFE;

}  // mbgclock_default_get_ucap_entries

EXPORT_SYMBOL( mbgclock_default_get_ucap_entries );



/*HDR*/
/**
    Retrieve a single time capture event from the on-board FIFO buffer of the
    first device registered by the driver which supports this call.
    The captured event time is returned in a ::PCPS_HR_TIME structure.
    The oldest entry of the FIFO is retrieved and then removed from the FIFO.
    If no capture event is available in the FIFO buffer then both the seconds
    and the fractions of the returned timestamp are 0.

    @return ::MBG_SUCCESS on success, or
            MBG_ERR_NOT_SUPP_BY_DEV if no device supports this call, or
            MBG_ERR_IRQ_UNSAFE called on a device where such calls are unsafe
            if IRQs are enabled.

    @see mbgclock_default_clr_ucap_buff()
    @see mbgclock_default_get_ucap_entries()
*/
int mbgclock_default_get_ucap_event( PCPS_HR_TIME *p )
{
  int rc;

  if ( default_ucap_pddev == NULL )
    return MBG_ERR_NOT_SUPP_BY_DEV;

  _mbgddmsg_1( MBG_DBG_DETAIL, "%s: entering mbgclock_default_get_ucap_event",
               pcps_driver_name );

  _pcps_sem_inc_safe( default_ucap_pddev );
  rc = _pcps_read_var( default_ucap_pddev, PCPS_GIVE_UCAP_EVENT, *p );
  _pcps_sem_dec( default_ucap_pddev );

  _mbg_swab_pcps_hr_time( p );

  _mbgddmsg_4( MBG_DBG_DETAIL, "%s: leaving mbgclock_default_get_ucap_event: %08lX.%08lX, rc: %i",
               pcps_driver_name, (ulong) p->tstamp.sec, (ulong) p->tstamp.frac, rc );

  return rc;

err_busy_unsafe:
  return MBG_ERR_IRQ_UNSAFE;

}  // mbgclock_default_get_ucap_event

EXPORT_SYMBOL( mbgclock_default_get_ucap_event );



#if defined( DEBUG )

// In a debug build we define a few function pointer variables
// just to verify the declaration of the function pointer types
// match the associated function prototypes.

MBGCLOCK_DEFAULT_GET_FAST_HR_TIMESTAMP_FNC get_fast_hr_timestamp_fnc = mbgclock_default_get_fast_hr_timestamp;
MBGCLOCK_DEFAULT_GET_FAST_HR_TIMESTAMP_CYCLES_FNC get_fast_hr_timestamp_cycles_fnc = mbgclock_default_get_fast_hr_timestamp_cycles;

MBGCLOCK_DEFAULT_CLR_UCAP_BUFF_FNC clr_ucap_buff_fnc = mbgclock_default_clr_ucap_buff;
MBGCLOCK_DEFAULT_GET_UCAP_ENTRIES_FNC get_ucap_entries_fnc = mbgclock_default_get_ucap_entries;
MBGCLOCK_DEFAULT_GET_UCAP_EVENT_FNC get_ucap_event_fnc = mbgclock_default_get_ucap_event;

#endif


#if !MBG_PC_CYCLES_SUPPORTED
  #warning No cycles support to compute latencies on this platform.
#endif

#if OMIT_PRIV_CHECKING
  #warning IOCTL privilege checking is omitted on your own risk!
#endif
