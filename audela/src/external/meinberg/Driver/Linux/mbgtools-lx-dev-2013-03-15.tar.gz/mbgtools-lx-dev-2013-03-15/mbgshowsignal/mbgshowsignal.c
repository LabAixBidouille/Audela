
/**************************************************************************
 *
 *  $Id: mbgshowsignal.c 1.8.1.4 2011/10/05 15:10:56 martin TEST $
 *
 *  Description:
 *    Main file for mbgshowsignal program which demonstrates how to
 *    access a Meinberg device via IOCTL calls and show the modulation
 *    signal (second marks) of a longwave receiver, e.g. for DCF77.
 *
 * -----------------------------------------------------------------------
 *  $Log: mbgshowsignal.c $
 *  Revision 1.8.1.4  2011/10/05 15:10:56  martin
 *  Show PZF correlation state.
 *  Revision 1.8.1.3  2011/07/05 15:35:55  martin
 *  Modified version handling.
 *  Revision 1.8.1.2  2011/07/05 14:35:19  martin
 *  New way to maintain version information.
 *  Revision 1.8.1.1  2011/07/04 13:19:04  martin
 *  Update modulation status continuously.
 *  Revision 1.8  2009/09/29 15:02:15  martin
 *  Updated version number to 3.4.0.
 *  Revision 1.7  2009/07/24 09:50:09  martin
 *  Updated version number to 3.3.0.
 *  Revision 1.6  2009/06/19 12:38:52  martin
 *  Updated version number to 3.2.0.
 *  Revision 1.5  2009/03/19 17:04:26  martin
 *  Updated version number to 3.1.0.
 *  Updated copyright year to include 2009.
 *  Revision 1.4  2008/12/22 12:44:43  martin
 *  Changed ealier program name mbgdcfmod to mbgshowsignal.
 *  Updated description, copyright, revision number and string.
 *  Use unified functions from toolutil module.
 *  Accept device name(s) on the command line.
 *  Don't use printf() without format, which migth produce warnings
 *  with newer gcc versions.
 *  Revision 1.3  2007/07/24 09:32:11  martin
 *  Updated copyright to include 2007.
 *  Revision 1.2  2003/04/25 10:28:05  martin
 *  Use new functions from mbgdevio library.
 *  New program version v2.1.
 *  Revision 1.1  2001/09/17 15:08:09  martin
 *
 **************************************************************************/

// include Meinberg headers
#include <mbgdevio.h>
#include <pcpsutil.h>
#include <toolutil.h>  // common utility functions

// include system headers
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#define MBG_MICRO_VERSION          0
#define MBG_FIRST_COPYRIGHT_YEAR   2001
#define MBG_LAST_COPYRIGHT_YEAR    0     // use default

static const char *pname = "mbgshowsignal";



static /*HDR*/
int show_modulation( MBG_DEV_HANDLE dh, const PCPS_DEV *p_dev )
{
  static time_t prv_sys_t;
  time_t sys_t;
  PCPS_STATUS_PORT status_port;   // current value of the clock's status port
  PCPS_TIME t;
  int signal;
  int rc = mbg_get_status_port( dh, &status_port );  // read status port

  if ( mbg_ioctl_err( rc, "mbg_get_status_port" ) )
    return -1;

  // show signal only once per second
  sys_t = time( NULL );

  if ( sys_t != prv_sys_t )
  {
    rc = mbg_get_time( dh, &t );

    if ( mbg_ioctl_err( rc, "mbg_get_time" ) )
      return -1;

    prv_sys_t = sys_t;
  }

  // The current value of the modulation (second mark) is returned
  // in a single bit of the status port, so ignore the other bits.
  printf( "\rMod: %c", ( status_port & PCPS_ST_MOD ) ? '*' : '_' );

  signal = t.signal - PCPS_SIG_BIAS;

  if ( signal < 0 )
    signal = 0;
  else
    if ( signal > PCPS_SIG_MAX )
      signal = PCPS_SIG_MAX;

  printf( "  Signal: %u%%  ", signal * 100 / PCPS_SIG_MAX );

  if ( _pcps_has_pzf( p_dev ) )
    mbg_show_pzf_corr_info( dh, p_dev, 1 );

  printf( "  " );

  return 0;

}  // show_modulation



static /*HDR*/
int do_mbgshowsignal( MBG_DEV_HANDLE dh, const PCPS_DEV *p_dev )
{
  int has_mod = 0;
  int rc = mbg_dev_has_mod( dh, &has_mod );

  if ( mbg_ioctl_err( rc, "mbg_dev_has_mod" ) )
    goto fail;

  if ( !has_mod )
  {
    printf( "This device does not support monitoring signal modulation.\n" );
    goto done;
  }

  printf( "\nMonitoring signal modulation:\n" );

  for (;;)
    if ( show_modulation( dh, p_dev ) < 0 )
      goto fail;

done:
  return 0;

fail:
  return -1;

}  // do_mbgshowsignal



static /*HDR*/
void usage( void )
{
  mbg_print_usage_intro( pname,
    "This program displays the modulation signal of cards which receive\n"
    "a slowly modulated input signal, e.g. the longwave signal from DCF77.\n"
  );
  mbg_print_help_options();
  mbg_print_device_options();
  puts( "" );

}  // usage



int main( int argc, char *argv[] )
{
  int c;
  int rc;

  mbg_print_program_info( pname, MBG_MICRO_VERSION, MBG_FIRST_COPYRIGHT_YEAR, MBG_LAST_COPYRIGHT_YEAR );

  // check command line parameters
  while ( ( c = getopt( argc, argv, "h?" ) ) != -1 )
  {
    switch ( c )
    {
      case 'h':
      case '?':
      default:
        must_print_usage = 1;
    }
  }

  if ( must_print_usage )
  {
    usage();
    return 1;
  }

  // The function below checks which devices have been specified
  // on the command, and for each device
  // - tries to open the device
  // - shows basic device info
  // - calls the function passed as last parameter
  rc = mbg_check_devices( argc, argv, optind, do_mbgshowsignal );

  return abs( rc );
}
