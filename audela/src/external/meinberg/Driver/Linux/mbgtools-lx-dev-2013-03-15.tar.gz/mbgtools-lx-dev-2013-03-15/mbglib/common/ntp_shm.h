
/**************************************************************************
 *
 *  $Id: ntp_shm.h 1.2 2013/01/02 10:23:41 daniel REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    Definitions and prototypes for ntp_shm.c.
 *
 * -----------------------------------------------------------------------
 *  $Log: ntp_shm.h $
 *  Revision 1.2  2013/01/02 10:23:41  daniel
 *  Added nsec support.
 *  Revision 1.2  2013/01/02 10:23:41  daniel
 *  Added nsec support
 *  Revision 1.1  2012/05/29 09:54:15  martin
 *  Initial revision.
 *
 **************************************************************************/

#ifndef _NTP_SHM_H
#define _NTP_SHM_H


/* Other headers to be included */

#include <sys/ipc.h>
#include <sys/shm.h>


#ifdef _NTP_SHM
 #define _ext
 #define _DO_INIT
#else
 #define _ext extern
#endif


/* Start of header body */

#if 0 && defined( _USE_PACK )  // use default alignment
  #pragma pack( 1 )      // set byte alignment
  #define _USING_BYTE_ALIGNMENT
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup group_ntp_defs NTP interface definitions
 *
 * @Note These definitions have been copied from the NTP source code (http://www.ntp.org)
 *
 * @{ */

/** @brief Structure of NTP's shared memory segment */
struct shmTime {
  int    mode; /* 0 - if valid set
                *       use values,
                *       clear valid
                * 1 - if valid set
                *       if count before and after read of
                *       values is equal,
                *         use values
                *       clear valid
                */
  int    count;
  time_t clockTimeStampSec;      /* external clock */
  int    clockTimeStampUSec;     /* external clock */
  time_t receiveTimeStampSec;    /* internal clock, when external value was received */
  int    receiveTimeStampUSec;   /* internal clock, when external value was received */
  int    leap;
  int    precision;
  int    nsamples;
  int    valid;
  unsigned clockTimeStampNSec;    /* unsigned ns timestamps */
  unsigned receiveTimeStampNSec;
  int    dummy[8];
};

/** @brief codes used with struct shmTime::leap */
#define LEAP_NOWARNING  0x0 /**< normal, no leap second warning */
#define LEAP_ADDSECOND  0x1 /**< last minute of day has 61 seconds */
#define LEAP_DELSECOND  0x2 /**< last minute of day has 59 seconds */
#define LEAP_NOTINSYNC  0x3 /**< overload, clock is free running */

#define NTPD_BASE                  0x4e545030    /* "NTP0" */

#define MAX_SHM_REFCLOCKS          4

/** @} group_ntp_defs */




/* function prototypes: */

/* ----- function prototypes begin ----- */

/* This section was generated automatically */
/* by MAKEHDR, do not remove the comments. */

 struct shmTime *getShmTime( int unit ) ;
 int ntpshm_init( struct shmTime **shmTime, int n_units ) ;

/* ----- function prototypes end ----- */

#ifdef __cplusplus
}
#endif


#if defined( _USING_BYTE_ALIGNMENT )
  #pragma pack()      // set default alignment
  #undef _USING_BYTE_ALIGNMENT
#endif

/* End of header body */


#undef _ext
#undef _DO_INIT

#endif  /* _NTP_SHM_H */

