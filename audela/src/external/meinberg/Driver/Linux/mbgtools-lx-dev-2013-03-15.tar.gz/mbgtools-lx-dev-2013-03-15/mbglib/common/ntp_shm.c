
/**************************************************************************
 *
 *  $Id: ntp_shm.c 1.1 2012/05/29 09:54:15 martin REL_M $
 *
 *  Copyright (c) Meinberg Funkuhren, Bad Pyrmont, Germany
 *
 *  Description:
 *    NTP shared memory support functions.
 *
 * -----------------------------------------------------------------------
 *  $Log: ntp_shm.c $
 *  Revision 1.1  2012/05/29 09:54:15  martin
 *  Initial revision.
 *
 **************************************************************************/

#define _NTP_SHM
  #include <ntp_shm.h>
#undef _NTP_SHM

#include <syslog.h>
#include <errno.h>
#include <string.h>


//##+++++++++++
extern void mbg_log( int lvl, const char *fmt, ... );


/*HDR*/
struct shmTime *getShmTime( int unit )
{
  struct shmTime *p;

  int shmid = shmget( (key_t) ( NTPD_BASE + unit ),
                      sizeof( struct shmTime ), IPC_CREAT | 0644 );

  if ( shmid == -1 )
  {
    mbg_log( LOG_ERR, "shmget %i failed: %s", unit, strerror( errno ) );
    return NULL;
  }


  p = (struct shmTime *) shmat( shmid, 0, 0 );

  if ( (long) p == -1L )
  {
    mbg_log( LOG_ERR, "shmat %i failed: %s", unit, strerror( errno ) );
    return NULL;
  }

  return p;

}  // getShmTime



/*HDR*/
int ntpshm_init( struct shmTime **shmTime, int n_units )
{
  int i;
  int ret_val = 0;

  for ( i = 0; i < n_units; i++ )
  {
    struct shmTime *p = getShmTime( i );
    shmTime[i] = p;

    if ( p == NULL )
    {
      mbg_log( LOG_WARNING, "** Failed to initialize NTP SHM unit %i", i );
      ret_val = -1;
      continue;
    }

    memset( p, 0, sizeof( *p ) );

    p->mode = 1;
    p->precision = -5;  /* initially 0.5 sec */
    p->nsamples = 3;    /* stages of median filter */

    mbg_log( LOG_INFO, "NTP SHM unit %i initialized successfully", i );
  }

  return ret_val;

}  // ntpshm_init


