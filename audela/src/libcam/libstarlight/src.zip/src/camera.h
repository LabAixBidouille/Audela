/*
 * camera.h
 *
 * Adapter le contenu de ce fichier a votre camera preferee
 * notamment la structure "camprop"
 *
 */

#ifndef __CAMERA_H__
#define __CAMERA_H__

#include "tcl.h"
#include "libstruc.h"

/*
 *   structure pour les fonctions �tendues
 */


/*
 * Donnees propres a chaque camera.
 */
/* --- structure qui accueille les parametres---*/
struct camprop {
   /* --- parametres standards, ne pas changer ---*/
   COMMON_CAMSTRUCT
   /* Ajoutez ici les variables necessaires a votre camera (mode d'obturateur, etc). */
   /* --- pour Starlight ---*/
   double multdelay;
   unsigned long bd1;
   unsigned long bd2;
   unsigned long bd5;
   unsigned long bd10;
   int accelerator;
   double timescale;
};

int cam_init(struct camprop *cam, int argc, char **argv);
void cam_update_window(struct camprop *cam);
void cam_start_exp(struct camprop *cam,char *amplionoff);
void cam_stop_exp(struct camprop *cam);
void cam_read_ccd(struct camprop *cam, unsigned short *p);
void cam_shutter_on(struct camprop *cam);
void cam_shutter_off(struct camprop *cam);
void cam_measure_temperature(struct camprop *cam);
void cam_cooler_on(struct camprop *cam);
void cam_cooler_off(struct camprop *cam);
void cam_cooler_check(struct camprop *cam);
void cam_set_binning(int binx, int biny,struct camprop *cam);

void timetest(struct camprop *cam);

void wiper(struct camprop *cam);
void reader(struct camprop *cam);
void clearvert(struct camprop *cam);
void lineread_win(struct camprop *cam,unsigned short *buf);

void wiper_mx5(struct camprop *cam);
void reader_mx5(struct camprop *cam);
void vert_mx5(struct camprop *cam);
void clearvert_mx5(struct camprop *cam);
void lineread_mx5(struct camprop *cam,unsigned short *buf);
void lineread_win_mx5(struct camprop *cam,unsigned short *buf);

void fastwiper_mx5(struct camprop *cam);
void fastreader_mx5(struct camprop *cam);
void fastvert_mx5(struct camprop *cam);
void fastclearvert_mx5(struct camprop *cam);
void fastlineread_mx5(struct camprop *cam,unsigned short *buf);
void fastlineread_win_mx5(struct camprop *cam,unsigned short *buf);

void wiper_hx5(struct camprop *cam);
void reader_hx5(struct camprop *cam);
void vert_hx5(struct camprop *cam);
void clearvert_hx5(struct camprop *cam);
void lineread_hx5(struct camprop *cam,unsigned short *buf);
void lineread_win_hx5(struct camprop *cam,unsigned short *buf);

void fastwiper_hx5(struct camprop *cam);
void fastreader_hx5(struct camprop *cam);
void fastvert_hx5(struct camprop *cam);
void fastclearvert_hx5(struct camprop *cam);
void fastlineread_hx5(struct camprop *cam,unsigned short *buf);
void fastlineread_win_hx5(struct camprop *cam,unsigned short *buf);

void cam_test_out(struct camprop *cam,unsigned long nb_out);
unsigned char libcam_in2(unsigned short a);

#endif

