static struct cmditem cmdlist[] = {
   /* === Common commands for all cameras ===*/
   COMMON_CMDLIST
   /* === Specific commands for that camera ===*/
   {"outtime", cmdCamOutTime},
   {"accelerator", cmdCamAccelerator},
   {"timescale",cmdCamTimescale},
   /* === Last function terminated by NULL pointers ===*/
   {NULL, NULL}
};
