/*
 * Fonctions C-Tcl specifiques a cette camera. A programmer.
 *
 */

#ifndef __CAMTCL_H__
#define __CAMTCL_H__

 /* === Specific commands for that camera ===*/
int cmdCamAccelerator(ClientData clientData, Tcl_Interp *interp, int argc, char *argv[]);
int cmdCamOutTime(ClientData clientData, Tcl_Interp *interp, int argc, char *argv[]);
int cmdCamTimescale(ClientData clientData, Tcl_Interp *interp, int argc, char *argv[]);

#endif
