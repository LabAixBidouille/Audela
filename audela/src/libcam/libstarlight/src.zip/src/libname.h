#ifndef __LIBNAME_H__
#define __LIBNAME_H__

/*
 * Nom du point d'entree de la librairie, doit etre Xx_Init pour une librairie libxx
 * (la majuscule est importante pour permettre un chargement par load libxx).
 */
#define CAM_ENTRYPOINT Starlight_Init

/*
 * Informations sur le driver, le nom est celui qui apparait quand on fait "package names"
 * et la version apparait avec la commande Tcl "package require libxx"
 */
#define CAM_LIBNAME "libstarlight"
#define CAM_LIBVER "1.0"

/*
 * Initialisation d'informations indispensables pour la librairie xx.
 */
#define CAM_DRIVNAME "starlight"


#endif

